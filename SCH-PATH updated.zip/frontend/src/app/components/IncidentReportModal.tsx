import { useEffect, useState } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/app/components/ui/dialog';
import { Button } from '@/app/components/ui/button';
import { Input } from '@/app/components/ui/input';
import { Label } from '@/app/components/ui/label';
import { Textarea } from '@/app/components/ui/textarea';
import { Checkbox } from '@/app/components/ui/checkbox';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/app/components/ui/select';
import { request } from '@/services/api';

// "Type of Report" checkboxes, exactly as they appear on Form 08
const REPORT_TYPES = [
  'Quarrelling', 'Stealing',
  'Threatening Others', 'Runaway',
  'Accident', 'Serious Illness',
  'Discovery of substance used', 'Unusual Sexual Behavior',
];

const INTERVENTION_OPTIONS = ['Psycho-Social Activity'];

export interface IncidentReportData {
  id: string;
  violationId: string;
  residentId: string;
  reportTypes: string[];
  othersSpecify?: string | null;
  incidentDateTime: string;
  summary?: string | null;
  actionTaken?: string | null;
  result?: string | null;
  reportedBy?: string | null;
  endorsedTo?: string | null;
  checkedBy?: string | null;
  notedBy?: string | null;
  status: 'Pending Review' | 'Verified';
  interventionType?: string | null;
  interventionScheduleDate?: string | null;
  verifiedBy?: string | null;
  verifiedAt?: string | null;
}

interface Props {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  /** 'create' — Social Worker fills out a brand-new report for this violation. */
  mode: 'create' | 'view';
  violationId: string | null;
  residentId?: string;
  residentName?: string;
  currentUsername?: string;
  /** Can this user Verify the report (Psychologist / Center Head)? */
  canVerify?: boolean;
  onSaved?: () => void;
}

const emptyForm = {
  reportTypes: [] as string[],
  othersSpecify: '',
  incidentDateTime: new Date().toISOString().slice(0, 16),
  summary: '',
  actionTaken: '',
  result: '',
  reportedBy: '',
  endorsedTo: '',
  checkedBy: '',
  notedBy: '',
};

export default function IncidentReportModal({
  open, onOpenChange, mode, violationId, residentId, residentName,
  currentUsername, canVerify, onSaved,
}: Props) {
  const [form, setForm] = useState(emptyForm);
  const [report, setReport] = useState<IncidentReportData | null>(null);
  const [loading, setLoading] = useState(false);
  const [saving, setSaving] = useState(false);
  const [verifying, setVerifying] = useState(false);
  const [saveError, setSaveError] = useState<string | null>(null);
  const [verifyError, setVerifyError] = useState<string | null>(null);
  const [interventionType, setInterventionType] = useState(INTERVENTION_OPTIONS[0]);
  const [interventionDate, setInterventionDate] = useState(new Date().toISOString().split('T')[0]);

  useEffect(() => {
    if (!open) return;
    if (mode === 'create') {
      setForm({ ...emptyForm, reportedBy: currentUsername || '' });
      setReport(null);
    } else if (mode === 'view' && violationId) {
      setLoading(true);
      request(`/incident-reports/violation/${violationId}`, { method: 'GET' })
        .then((res: any) => {
          if (res?.success) setReport(res.data);
        })
        .catch(() => { /* ignore */ })
        .finally(() => setLoading(false));
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [open, mode, violationId]);

  const toggleType = (t: string) => {
    setForm((prev) => ({
      ...prev,
      reportTypes: prev.reportTypes.includes(t)
        ? prev.reportTypes.filter((x) => x !== t)
        : [...prev.reportTypes, t],
    }));
  };

  const handleSave = async () => {
    if (!violationId || !residentId) return;
    setSaving(true);
    setSaveError(null);
    try {
      // HTML datetime-local gives "YYYY-MM-DDTHH:MM" — MySQL DATETIME needs a space
      // separator and seconds, or the INSERT is rejected outright under strict SQL mode.
      const mysqlDateTime = form.incidentDateTime.replace('T', ' ') + (form.incidentDateTime.length <= 16 ? ':00' : '');

      const res: any = await request('/incident-reports', {
        method: 'POST',
        body: JSON.stringify({
          violationId,
          residentId,
          incidentDateTime: mysqlDateTime,
          reportTypes: form.reportTypes,
          othersSpecify: form.othersSpecify || null,
          summary: form.summary,
          actionTaken: form.actionTaken,
          result: form.result,
          reportedBy: form.reportedBy,
          endorsedTo: form.endorsedTo,
          checkedBy: form.checkedBy,
          notedBy: form.notedBy,
        }),
      });
      if (res?.success) {
        onOpenChange(false);
        onSaved?.();
      } else {
        setSaveError(res?.message || 'Save did not complete. Please try again.');
      }
    } catch (err) {
      setSaveError(err instanceof Error ? err.message : 'Unable to save the incident report.');
    } finally {
      setSaving(false);
    }
  };

  const handleVerify = async () => {
    if (!report) return;
    setVerifying(true);
    setVerifyError(null);
    try {
      const verifyRes: any = await request(`/incident-reports/${report.id}/verify`, {
        method: 'POST',
        body: JSON.stringify({
          interventionType,
          interventionScheduleDate: interventionDate,
          verifiedBy: currentUsername,
        }),
      });
      if (!verifyRes?.success) {
        setVerifyError(verifyRes?.message || 'Verification did not complete. Please try again.');
        return;
      }

      let activityScheduleFailed = false;

      // Only schedule an activity when the chosen intervention actually is one —
      // no automatic scheduling happens anywhere before this point.
      if (interventionType === 'Psycho-Social Activity') {
        const activityRes: any = await request('/activities', {
          method: 'POST',
          body: JSON.stringify({
            title: `Psycho-Social Activity — ${residentName || 'Resident'}`,
            date: interventionDate,
            type: 'Psycho-Social Activity',
            category: 'Intervention',
            status: 'Upcoming',
            description: `Intervention scheduled from verified Incident Report for violation ${report.violationId}.`,
            selectedResidentIds: [residentId],
            violationIds: [report.violationId],
          }),
        }).catch((err: unknown) => ({ success: false, message: err instanceof Error ? err.message : 'Unknown error' }));

        if (!activityRes?.success) {
          activityScheduleFailed = true;
          const detail = activityRes?.error || activityRes?.message || 'unknown error';
          // Verification itself already went through — don't lose that — but the
          // person needs to know scheduling didn't make it into the Activities module.
          setVerifyError(`Verified, but scheduling the activity failed: ${detail}. You can add it manually in Activities.`);
        }
      }

      // Flip the underlying violation to Reviewed so it drops off the pending queue.
      await request(`/violations/${report.violationId}/review`, {
        method: 'POST',
        body: JSON.stringify({ status: 'Reviewed', reviewedBy: currentUsername, actionTaken: report.actionTaken || '' }),
      }).catch(() => { /* non-fatal */ });

      onSaved?.();
      // Keep the dialog open if activity scheduling failed, so the warning stays visible —
      // but refresh the report data either way so the view reflects the new Verified status.
      if (activityScheduleFailed) {
        const refreshed: any = await request(`/incident-reports/violation/${violationId}`, { method: 'GET' }).catch(() => null);
        if (refreshed?.success) setReport(refreshed.data);
      } else {
        onOpenChange(false);
      }
    } catch (err) {
      setVerifyError(err instanceof Error ? err.message : 'Unable to verify this incident report.');
    } finally {
      setVerifying(false);
    }
  };

  if (mode === 'create') {
    return (
      <Dialog open={open} onOpenChange={onOpenChange}>
        <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>Incident Report — Form 08</DialogTitle>
          </DialogHeader>
          <div className="space-y-4 py-2">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div className="space-y-1">
                <Label>Name of Client</Label>
                <Input value={residentName || ''} disabled />
              </div>
              <div className="space-y-1">
                <Label>Date and Time *</Label>
                <Input
                  type="datetime-local"
                  value={form.incidentDateTime}
                  onChange={(e) => setForm({ ...form, incidentDateTime: e.target.value })}
                />
              </div>
            </div>

            <div className="space-y-2">
              <Label className="font-bold">Type of Report</Label>
              <div className="grid grid-cols-2 gap-2">
                {REPORT_TYPES.map((t) => (
                  <label key={t} className="flex items-center gap-2 text-sm">
                    <Checkbox checked={form.reportTypes.includes(t)} onCheckedChange={() => toggleType(t)} />
                    {t}
                  </label>
                ))}
              </div>
              <div className="flex items-center gap-2">
                <Label className="whitespace-nowrap text-sm">Others (specify)</Label>
                <Input value={form.othersSpecify} onChange={(e) => setForm({ ...form, othersSpecify: e.target.value })} />
              </div>
            </div>

            <div className="space-y-1">
              <Label className="font-bold">Summary of the Incident</Label>
              <Textarea rows={5} value={form.summary} onChange={(e) => setForm({ ...form, summary: e.target.value })} placeholder="What happened..." />
            </div>

            <div className="space-y-1">
              <Label className="font-bold">Action Taken</Label>
              <Textarea rows={3} value={form.actionTaken} onChange={(e) => setForm({ ...form, actionTaken: e.target.value })} />
            </div>

            <div className="space-y-1">
              <Label className="font-bold">Result</Label>
              <Textarea rows={3} value={form.result} onChange={(e) => setForm({ ...form, result: e.target.value })} />
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div className="space-y-1">
                <Label>Reported by</Label>
                <Input value={form.reportedBy} onChange={(e) => setForm({ ...form, reportedBy: e.target.value })} placeholder="Signature over printed name" />
              </div>
              <div className="space-y-1">
                <Label>Endorsed to</Label>
                <Input value={form.endorsedTo} onChange={(e) => setForm({ ...form, endorsedTo: e.target.value })} placeholder="Psychologist" />
              </div>
              <div className="space-y-1">
                <Label>Checked by</Label>
                <Input value={form.checkedBy} onChange={(e) => setForm({ ...form, checkedBy: e.target.value })} placeholder="SWO I - Case Manager" />
              </div>
              <div className="space-y-1">
                <Label>Noted by</Label>
                <Input value={form.notedBy} onChange={(e) => setForm({ ...form, notedBy: e.target.value })} placeholder="SWO II - Center Head" />
              </div>
            </div>
          </div>
          {saveError && (
            <div className="bg-red-50 border border-red-200 text-red-700 text-sm px-3 py-2 rounded-lg mx-0">
              {saveError}
            </div>
          )}
          <DialogFooter>
            <Button variant="outline" onClick={() => onOpenChange(false)}>Cancel</Button>
            <Button onClick={handleSave} disabled={saving || !form.incidentDateTime} className="bg-[#2F3E46]">
              {saving ? 'Saving...' : 'Save Incident'}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    );
  }

  // mode === 'view'
  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>Incident Report — Form 08</DialogTitle>
        </DialogHeader>

        {loading && <p className="text-sm text-gray-500 py-8 text-center">Loading incident report...</p>}

        {!loading && !report && (
          <p className="text-sm text-gray-500 py-8 text-center">No digital incident report was filed for this record yet.</p>
        )}

        {!loading && report && (
          <div className="space-y-4 py-2 text-sm">
            <div className="grid grid-cols-2 gap-4">
              <div><span className="text-gray-400 text-xs block">Date and Time</span>{new Date(report.incidentDateTime).toLocaleString()}</div>
              <div><span className="text-gray-400 text-xs block">Status</span>{report.status}</div>
            </div>

            <div>
              <span className="text-gray-400 text-xs block mb-1">Type of Report</span>
              <div className="flex flex-wrap gap-1">
                {report.reportTypes?.map((t) => (
                  <span key={t} className="px-2 py-0.5 rounded-full bg-gray-100 text-[#2F3E46] text-xs font-medium">{t}</span>
                ))}
                {report.othersSpecify && (
                  <span className="px-2 py-0.5 rounded-full bg-gray-100 text-[#2F3E46] text-xs font-medium">Other: {report.othersSpecify}</span>
                )}
              </div>
            </div>

            <div><span className="text-gray-400 text-xs block">Summary of the Incident</span><p className="whitespace-pre-wrap">{report.summary || '—'}</p></div>
            <div><span className="text-gray-400 text-xs block">Action Taken</span><p className="whitespace-pre-wrap">{report.actionTaken || '—'}</p></div>
            <div><span className="text-gray-400 text-xs block">Result</span><p className="whitespace-pre-wrap">{report.result || '—'}</p></div>

            <div className="grid grid-cols-2 gap-4">
              <div><span className="text-gray-400 text-xs block">Reported by</span>{report.reportedBy || '—'}</div>
              <div><span className="text-gray-400 text-xs block">Endorsed to</span>{report.endorsedTo || '—'}</div>
              <div><span className="text-gray-400 text-xs block">Checked by</span>{report.checkedBy || '—'}</div>
              <div><span className="text-gray-400 text-xs block">Noted by</span>{report.notedBy || '—'}</div>
            </div>

            {report.status === 'Verified' && (
              <div className="rounded-lg bg-green-50 border border-green-200 p-3">
                <p className="text-green-800 font-semibold text-xs">Verified by {report.verifiedBy} on {report.verifiedAt ? new Date(report.verifiedAt).toLocaleString() : ''}</p>
                {report.interventionType && (
                  <p className="text-green-700 text-xs mt-1">Intervention: {report.interventionType} — scheduled {report.interventionScheduleDate}</p>
                )}
              </div>
            )}

            {report.status === 'Pending Review' && canVerify && (
              <div className="rounded-lg bg-purple-50 border border-purple-200 p-3 space-y-3">
                <p className="text-purple-800 font-semibold text-xs">Verify this report and select the intervention</p>
                <div className="grid grid-cols-2 gap-3">
                  <div className="space-y-1">
                    <Label className="text-xs">Intervention</Label>
                    <Select value={interventionType} onValueChange={setInterventionType}>
                      <SelectTrigger><SelectValue /></SelectTrigger>
                      <SelectContent>
                        {INTERVENTION_OPTIONS.map((o) => <SelectItem key={o} value={o}>{o}</SelectItem>)}
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="space-y-1">
                    <Label className="text-xs">Schedule Date</Label>
                    <Input type="date" value={interventionDate} onChange={(e) => setInterventionDate(e.target.value)} />
                  </div>
                </div>
              </div>
            )}
          </div>
        )}

        {verifyError && (
          <div className="bg-red-50 border border-red-200 text-red-700 text-sm px-3 py-2 rounded-lg">
            {verifyError}
          </div>
        )}

        <DialogFooter>
          <Button variant="outline" onClick={() => onOpenChange(false)}>Close</Button>
          {report?.status === 'Pending Review' && canVerify && (
            <Button onClick={handleVerify} disabled={verifying} className="bg-purple-600 hover:bg-purple-700 text-white">
              {verifying ? 'Verifying...' : 'Verify'}
            </Button>
          )}
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
