import { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/app/components/ui/card';
import { Button } from '@/app/components/ui/button';
import { Input } from '@/app/components/ui/input';
import { Label } from '@/app/components/ui/label';
import { Badge } from '@/app/components/ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/app/components/ui/select';
import { Textarea } from '@/app/components/ui/textarea';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/app/components/ui/dialog';
import { Plus, Eye, Edit, Info } from 'lucide-react';
import { useAuth } from '../state/AuthContext';
import { request } from '@/services/api';
import { formatShortDate } from '@/utils/dateFormatter';

// Pre-defined intervention types
const INTERVENTION_TYPES = [
  { id: 'IT001', type: 'Privilege Suspension', requiresDuration: true },
  { id: 'IT002', type: 'Psychosocial Activity', requiresDuration: false },
  { id: 'IT003', type: 'Household Chores', requiresDuration: true },
  { id: 'IT004', type: 'Cleaning', requiresDuration: true },
  { id: 'IT005', type: 'Confiscation', requiresDuration: false },
  { id: 'IT006', type: 'Dialogue/Counseling', requiresDuration: false },
  { id: 'IT007', type: 'Referral', requiresDuration: false },
  { id: 'IT008', type: 'Other', requiresDuration: false },
];

const OTHER_INTERVENTION_OPTION = 'Other';

const getInterventionCustomValue = (interventionType: string | null | undefined) => {
  if (!interventionType) return '';
  return INTERVENTION_TYPES.some((item) => item.type === interventionType)
    ? ''
    : interventionType;
};

const getInterventionSelectValue = (interventionType: string | null | undefined) => {
  if (!interventionType) return '';
  return INTERVENTION_TYPES.some((item) => item.type === interventionType)
    ? interventionType
    : OTHER_INTERVENTION_OPTION;
};

const normalizeInterventionGroups = (rawInterventions?: any) => {
  const safeGroups = {
    '1st': [] as any[],
    '2nd': [] as any[],
    '3rd': [] as any[],
  };

  const normalizeLevel = (level: string | undefined) => {
    if (!level) return '1st';
    const normalized = String(level).trim();
    if (['1st', '2nd', '3rd'].includes(normalized)) return normalized;
    if (['No Resistance', 'With Resistance', 'Same as 1st', 'Same', 'Set Intervention'].includes(normalized)) return '1st';
    return '1st';
  };

  if (!rawInterventions) {
    return safeGroups;
  }

  if (Array.isArray(rawInterventions)) {
    rawInterventions.forEach((item) => {
      const level = normalizeLevel(item?.offenseLevel);
      safeGroups[level as '1st' | '2nd' | '3rd'].push(item);
    });
    return safeGroups;
  }

  Object.entries(rawInterventions).forEach(([level, items]) => {
    const normalizedLevel = normalizeLevel(level);
    if (Array.isArray(items)) {
      safeGroups[normalizedLevel as '1st' | '2nd' | '3rd'] = safeGroups[normalizedLevel as '1st' | '2nd' | '3rd'].concat(items);
    }
  });

  return safeGroups;
};

const getInterventionLabel = (item: Partial<Intervention> & { metadata?: any; customType?: string | null }) => {
  let rawMetadata: any = item.metadata;
  if (typeof rawMetadata === 'string') {
    try {
      rawMetadata = JSON.parse(rawMetadata);
    } catch {
      rawMetadata = {};
    }
  }

  const customValue = item.customType || rawMetadata?.customType || rawMetadata?.customValue || rawMetadata?.officialText || item.metadata?.officialText || item.metadata?.customType;
  const type = item.interventionType || 'Unspecified';

  if ((type === OTHER_INTERVENTION_OPTION || type === 'Other') && customValue && typeof customValue === 'string' && customValue.trim()) {
    return customValue.trim();
  }

  if (type === 'Other' && rawMetadata?.officialText && typeof rawMetadata.officialText === 'string' && rawMetadata.officialText.trim()) {
    return rawMetadata.officialText.trim();
  }

  if (item.duration && item.unit) {
    return `${type} - ${item.duration} ${item.unit}`;
  }

  return type;
};

interface Intervention {
  id: string;
  guideId: string;
  offenseLevel: '1st' | '2nd' | '3rd';
  interventionType: string;
  customType?: string | null;
  duration: number | null;
  unit: string | null;
  metadata: any;
}

interface ViolationGuide {
  id: string;
  name: string;
  category: 'Minor' | 'Major';
  description: string;
  status: 'Active' | 'Inactive';
  createdBy: string;
  createdAt: string;
  updatedAt: string;
  updatedBy: string | null;
  interventions?: {
    '1st': Intervention[];
    '2nd': Intervention[];
    '3rd': Intervention[];
  };
}

interface ViolationGuideProps {
  compact?: boolean;
}

export default function ViolationGuide({ compact = false }: ViolationGuideProps) {
  const { user } = useAuth();
  const [guides, setGuides] = useState<ViolationGuide[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState<'All' | 'Active' | 'Inactive'>('Active');
  
  const [isDialogOpen, setIsDialogOpen] = useState(false);
  const [isDetailOpen, setIsDetailOpen] = useState(false);
  const [selectedGuide, setSelectedGuide] = useState<ViolationGuide | null>(null);
  const [isEditing, setIsEditing] = useState(false);

  const [formData, setFormData] = useState({
    name: '',
    category: 'Minor' as 'Minor' | 'Major',
    description: '',
    status: 'Active' as 'Active' | 'Inactive',
    interventions: {
      '1st': [] as Intervention[],
      '2nd': [] as Intervention[],
      '3rd': [] as Intervention[],
    },
  });

  const normalizeGuide = (guide: any): ViolationGuide => ({
    ...guide,
    interventions: normalizeInterventionGroups(guide.interventions),
  });

  const canManage = ['centerhead', 'socialworker', 'psychologist'].includes(user?.role || '');

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    try {
      setLoading(true);
      const response = await request('/violation-guide', { method: 'GET' });
      if (response.success) {
        setGuides((response.data || []).map(normalizeGuide));
      }
    } catch (error) {
      console.error('Failed to load guides:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleAddGuide = () => {
    setFormData({
      name: '',
      category: 'Minor',
      description: '',
      status: 'Active',
      interventions: {
        '1st': [],
        '2nd': [],
        '3rd': [],
      },
    });
    setSelectedGuide(null);
    setIsEditing(false);
    setIsDialogOpen(true);
  };

  const handleEditGuide = (guide: ViolationGuide) => {
    const normalizedGuide = normalizeGuide(guide);
    setFormData({
      name: normalizedGuide.name,
      category: normalizedGuide.category,
      description: normalizedGuide.description,
      status: normalizedGuide.status,
      interventions: normalizeInterventionGroups(normalizedGuide.interventions),
    });
    setSelectedGuide(normalizedGuide);
    setIsEditing(true);
    setIsDialogOpen(true);
  };

  const handleSaveGuide = async () => {
    if (!formData.name.trim()) {
      alert('Please enter a violation name');
      return;
    }

    try {
      const serializeIntervention = (item: Intervention) => {
        const resolvedType = item.interventionType === OTHER_INTERVENTION_OPTION
          ? (item.customType?.trim() || 'Other')
          : item.interventionType;

        return {
          interventionType: resolvedType,
          duration: item.duration,
          unit: item.unit,
          metadata: item.metadata,
        };
      };

      const payload = {
        ...formData,
        interventions: {
          '1st': formData.interventions['1st'].map(serializeIntervention),
          '2nd': formData.interventions['2nd'].map(serializeIntervention),
          '3rd': formData.interventions['3rd'].map(serializeIntervention),
        },
      };

      const response = isEditing
        ? await request(`/violation-guide/${selectedGuide?.id}`, {
            method: 'PUT',
            body: payload,
          })
        : await request('/violation-guide', {
            method: 'POST',
            body: payload,
          });

      if (response.success) {
        await loadData();
        setIsDialogOpen(false);
        alert(isEditing ? 'Guide updated successfully' : 'Guide created successfully');
      }
    } catch (error) {
      console.error('Error saving guide:', error);
      alert('Failed to save guide');
    }
  };

  const handleAddIntervention = (offenseLevel: '1st' | '2nd' | '3rd') => {
    setFormData({
      ...formData,
      interventions: {
        ...formData.interventions,
        [offenseLevel]: [
          ...formData.interventions[offenseLevel],
          {
            id: `temp-${Date.now()}`,
            guideId: '',
            offenseLevel,
            interventionType: '',
            customType: '',
            duration: null,
            unit: 'Day(s)',
            metadata: null,
          },
        ],
      },
    });
  };

  const handleRemoveIntervention = (offenseLevel: '1st' | '2nd' | '3rd', index: number) => {
    setFormData({
      ...formData,
      interventions: {
        ...formData.interventions,
        [offenseLevel]: formData.interventions[offenseLevel].filter((_, i) => i !== index),
      },
    });
  };

  const handleInterventionChange = (
    offenseLevel: '1st' | '2nd' | '3rd',
    index: number,
    field: string,
    value: any
  ) => {
    const updated = [...formData.interventions[offenseLevel]];
    const nextValue = field === 'interventionType' && value === OTHER_INTERVENTION_OPTION
      ? { ...updated[index], [field]: value, customType: updated[index].customType || '' }
      : field === 'interventionType'
        ? { ...updated[index], [field]: value, customType: '' }
        : { ...updated[index], [field]: value };

    updated[index] = nextValue;
    setFormData({
      ...formData,
      interventions: {
        ...formData.interventions,
        [offenseLevel]: updated,
      },
    });
  };

  const filteredGuides = guides.filter(guide => {
    const matchesSearch = guide.name.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesStatus = statusFilter === 'All' || guide.status === statusFilter;
    return matchesSearch && matchesStatus;
  });

  const getInterventionDisplay = (intervention: Intervention) => getInterventionLabel(intervention);

  const getGuideInterventionCell = (guide: ViolationGuide, level: '1st' | '2nd' | '3rd') => {
    const items = normalizeInterventionGroups(guide.interventions)[level] || [];

    if (!items.length) {
      return <span className="text-slate-400 italic">—</span>;
    }

    return (
      <div className="space-y-1 text-xs text-slate-700">
        {items.map((item, index) => (
          <div key={`${guide.id}-${level}-${index}`} className="leading-relaxed">
            {getInterventionDisplay(item as Intervention)}
          </div>
        ))}
      </div>
    );
  };

  if (loading) {
    return <div className="flex items-center justify-center h-24">Loading...</div>;
  }

  return (
    <div className={compact ? '' : 'space-y-6 bg-white rounded-xl border border-slate-200 p-4 shadow-sm'}>
      {/* Header */}
      <div className="flex items-center justify-between">
        <h2 className="text-2xl font-bold text-[#2F3E46]">Manage Violations & Interventions</h2>
        {canManage && (
          <Button onClick={handleAddGuide} className="bg-[#2F3E46] hover:bg-[#1e2a30] text-white">
            <Plus className="w-4 h-4 mr-2" />
            Add Violation
          </Button>
        )}
      </div>

      {/* Filters */}
      <div className="flex gap-4">
        <div className="flex-1">
          <Input
            placeholder="Search violations..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="bg-white border-slate-300 text-slate-800 placeholder-slate-400"
          />
        </div>
        <Select value={statusFilter} onValueChange={(value) => setStatusFilter(value as any)}>
          <SelectTrigger className="w-40 bg-white border-slate-300 text-slate-800">
            <SelectValue />
          </SelectTrigger>
          <SelectContent className="bg-white border-slate-200">
            <SelectItem value="All">All Status</SelectItem>
            <SelectItem value="Active">Active</SelectItem>
            <SelectItem value="Inactive">Inactive</SelectItem>
          </SelectContent>
        </Select>
      </div>

      {/* Guides Table */}
      <Card className="bg-white border-slate-200 shadow-sm">
        <CardHeader className="border-b border-slate-200">
          <CardTitle className="text-[#2F3E46]">Configured Violations ({filteredGuides.length})</CardTitle>
        </CardHeader>
        <CardContent className="p-0">
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b border-slate-200 bg-slate-50">
                  <th className="px-4 py-3 text-left font-semibold text-slate-600">#</th>
                  <th className="px-4 py-3 text-left font-semibold text-slate-600">Violation</th>
                  <th className="px-4 py-3 text-left font-semibold text-slate-600">Category</th>
                  <th className="px-4 py-3 text-left font-semibold text-slate-600 min-w-[170px]">1st Offense</th>
                  <th className="px-4 py-3 text-left font-semibold text-slate-600 min-w-[170px]">2nd Offense</th>
                  <th className="px-4 py-3 text-left font-semibold text-slate-600 min-w-[170px]">3rd+ Offense</th>
                  <th className="px-4 py-3 text-left font-semibold text-slate-600">Status</th>
                  <th className="px-4 py-3 text-right font-semibold text-slate-600">Actions</th>
                </tr>
              </thead>
              <tbody>
                {filteredGuides.map((guide, idx) => (
                  <tr key={guide.id} className="border-b border-slate-200 align-top hover:bg-slate-50">
                    <td className="px-4 py-4 text-slate-500">{idx + 1}</td>
                    <td className="px-4 py-4 text-[#2F3E46] font-medium min-w-[180px]">
                      <div className="font-semibold">{guide.name}</div>
                    </td>
                    <td className="px-4 py-4">
                      <Badge variant={guide.category === 'Major' ? 'default' : 'secondary'}>
                        {guide.category}
                      </Badge>
                    </td>
                    <td className="px-4 py-4 align-top">{getGuideInterventionCell(guide, '1st')}</td>
                    <td className="px-4 py-4 align-top">{getGuideInterventionCell(guide, '2nd')}</td>
                    <td className="px-4 py-4 align-top">{getGuideInterventionCell(guide, '3rd')}</td>
                    <td className="px-4 py-4">
                      <Badge variant={guide.status === 'Active' ? 'default' : 'outline'}>
                        {guide.status}
                      </Badge>
                    </td>
                    <td className="px-4 py-4 text-right space-x-2">
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => {
                          setSelectedGuide(guide);
                          setIsDetailOpen(true);
                        }}
                        className="text-[#2F3E46] hover:text-[#1e2a30]"
                      >
                        <Eye className="w-4 h-4" />
                      </Button>
                      {canManage && (
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => handleEditGuide(guide)}
                          className="text-amber-600 hover:text-amber-700"
                        >
                          <Edit className="w-4 h-4" />
                        </Button>
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          {filteredGuides.length === 0 && (
            <div className="p-8 text-center">
              <Info className="w-8 h-8 text-slate-400 mx-auto mb-2" />
              <p className="text-slate-500">No violations found</p>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Detail Dialog */}
      {isDetailOpen && selectedGuide && (
        <Dialog open={isDetailOpen} onOpenChange={setIsDetailOpen}>
          <DialogContent className="max-w-2xl bg-white border-slate-200 text-slate-800">
            <DialogHeader>
              <DialogTitle className="text-slate-900">{selectedGuide.name}</DialogTitle>
            </DialogHeader>
            <div className="space-y-4 text-slate-700 max-h-[60vh] overflow-y-auto">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <p className="text-slate-500 text-sm">Category</p>
                  <Badge variant={selectedGuide.category === 'Major' ? 'default' : 'secondary'}>
                    {selectedGuide.category}
                  </Badge>
                </div>
                <div>
                  <p className="text-slate-500 text-sm">Status</p>
                  <Badge variant={selectedGuide.status === 'Active' ? 'default' : 'outline'}>
                    {selectedGuide.status}
                  </Badge>
                </div>
              </div>

              {selectedGuide.description && (
                <div>
                  <p className="text-slate-500 text-sm font-semibold mb-2">Description</p>
                  <p className="text-slate-700 text-sm">{selectedGuide.description}</p>
                </div>
              )}

              <div className="space-y-4">
                {selectedGuide.interventions &&
                  Object.entries(selectedGuide.interventions).map(([level, items]) => (
                    items.length > 0 && (
                      <div key={level}>
                        <h4 className="font-semibold text-slate-800 mb-2">{level} Offense</h4>
                        <ul className="space-y-2 ml-4">
                          {items.map((item, idx) => (
                            <li key={idx} className="text-slate-700 text-sm flex items-start">
                              <span className="text-blue-500 mr-2">•</span>
                              <span>{getInterventionDisplay(item)}</span>
                            </li>
                          ))}
                        </ul>
                      </div>
                    )
                  ))}
              </div>

              <div className="grid grid-cols-2 gap-4 pt-4 border-t border-slate-200 text-xs text-slate-500">
                <div>
                  <p>Created by: {selectedGuide.createdBy}</p>
                  <p>Date: {formatShortDate(selectedGuide.createdAt)}</p>
                </div>
                {selectedGuide.updatedBy && (
                  <div>
                    <p>Updated by: {selectedGuide.updatedBy}</p>
                    <p>Date: {formatShortDate(selectedGuide.updatedAt)}</p>
                  </div>
                )}
              </div>
            </div>

            <DialogFooter>
              {canManage && (
                <Button
                  onClick={() => {
                    handleEditGuide(selectedGuide);
                    setIsDetailOpen(false);
                  }}
                  className="bg-[#2F3E46] hover:bg-[#1e2a30]"
                >
                  Edit
                </Button>
              )}
              <Button variant="outline" onClick={() => setIsDetailOpen(false)}>
                Close
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      )}

      {/* Add/Edit Dialog */}
      <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
        <DialogContent className="max-w-2xl bg-white border-slate-200 text-slate-800 max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="text-slate-900">
              {isEditing ? 'Edit Violation' : 'Add New Violation'}
            </DialogTitle>
          </DialogHeader>

          <div className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="name" className="text-slate-700">
                Violation Name *
              </Label>
              <Input
                id="name"
                placeholder="e.g., Making noise during study time"
                value={formData.name}
                onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                className="bg-white border-slate-300 text-slate-900 placeholder-slate-400"
              />
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="category" className="text-slate-700">
                  Category
                </Label>
                <Select value={formData.category} onValueChange={(value) => setFormData({ ...formData, category: value as any })}>
                  <SelectTrigger className="bg-white border-slate-300 text-slate-900">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent className="bg-white border-slate-200">
                    <SelectItem value="Minor">Minor</SelectItem>
                    <SelectItem value="Major">Major</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label htmlFor="status" className="text-slate-700">
                  Status
                </Label>
                <Select value={formData.status} onValueChange={(value) => setFormData({ ...formData, status: value as any })}>
                  <SelectTrigger className="bg-white border-slate-300 text-slate-900">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent className="bg-white border-slate-200">
                    <SelectItem value="Active">Active</SelectItem>
                    <SelectItem value="Inactive">Inactive</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="description" className="text-slate-700">
                Description (Optional)
              </Label>
              <Textarea
                id="description"
                placeholder="Detailed description of the violation..."
                value={formData.description}
                onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                className="bg-white border-slate-300 text-slate-900 placeholder-slate-400 h-20"
              />
            </div>

            <div className="border-t border-slate-200 pt-4 space-y-4">
              <h3 className="text-lg font-semibold text-slate-900">Interventions by Offense Level</h3>

              {(['1st', '2nd', '3rd'] as const).map((level) => (
                <div key={level} className="bg-slate-50 p-4 rounded-lg space-y-3 border border-slate-200">
                  <div className="flex items-center justify-between">
                    <h4 className="font-semibold text-slate-800">{level} Offense</h4>
                    <Button
                      type="button"
                      variant="outline"
                      size="sm"
                      onClick={() => handleAddIntervention(level)}
                      className="border-slate-300 text-slate-700 hover:text-slate-900"
                    >
                      <Plus className="w-3 h-3 mr-1" />
                      Add Intervention
                    </Button>
                  </div>

                  {formData.interventions[level].length === 0 && (
                    <p className="text-slate-500 text-sm italic">No interventions added</p>
                  )}

                  {formData.interventions[level].map((intervention, idx) => {
                    const selectedType = getInterventionSelectValue(intervention.interventionType);
                    const customValue = intervention.customType ?? getInterventionCustomValue(intervention.interventionType);

                    return (
                      <div key={idx} className="bg-white p-3 rounded border border-slate-200 space-y-2">
                        <Select
                          value={selectedType}
                          onValueChange={(value) =>
                            handleInterventionChange(level, idx, 'interventionType', value)
                          }
                        >
                          <SelectTrigger className="bg-white border-slate-300 text-slate-900 text-sm">
                            <SelectValue placeholder="Select intervention type" />
                          </SelectTrigger>
                          <SelectContent className="bg-white border-slate-200">
                            {INTERVENTION_TYPES.map((type) => (
                              <SelectItem key={type.id} value={type.type}>
                                {type.type}
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>

                        {selectedType === OTHER_INTERVENTION_OPTION && (
                          <Input
                            placeholder="Specify the intervention..."
                            value={customValue}
                            onChange={(e) =>
                              handleInterventionChange(level, idx, 'customType', e.target.value)
                            }
                            className="bg-white border-slate-300 text-slate-900 placeholder-slate-400 text-sm"
                          />
                        )}

                        {intervention.interventionType === 'Privilege Suspension' && (
                          <div className="grid grid-cols-2 gap-2">
                            <Input
                              type="number"
                              min="1"
                              placeholder="Duration"
                              value={intervention.duration || ''}
                              onChange={(e) =>
                                handleInterventionChange(level, idx, 'duration', parseInt(e.target.value) || null)
                              }
                              className="bg-white border-slate-300 text-slate-900 placeholder-slate-400 text-sm"
                            />
                            <Select
                              value={intervention.unit || 'Day(s)'}
                              onValueChange={(value) =>
                                handleInterventionChange(level, idx, 'unit', value)
                              }
                            >
                              <SelectTrigger className="bg-white border-slate-300 text-slate-900 text-sm">
                                <SelectValue />
                              </SelectTrigger>
                              <SelectContent className="bg-white border-slate-200">
                                <SelectItem value="Day(s)">Day(s)</SelectItem>
                                <SelectItem value="Week(s)">Week(s)</SelectItem>
                                <SelectItem value="Month(s)">Month(s)</SelectItem>
                              </SelectContent>
                            </Select>
                          </div>
                        )}

                        {['Household Chores', 'Cleaning'].includes(intervention.interventionType) && (
                          <div className="grid grid-cols-2 gap-2">
                            <Input
                              type="number"
                              min="1"
                              placeholder="Duration"
                              value={intervention.duration || ''}
                              onChange={(e) =>
                                handleInterventionChange(level, idx, 'duration', parseInt(e.target.value) || null)
                              }
                              className="bg-white border-slate-300 text-slate-900 placeholder-slate-400 text-sm"
                            />
                            <Select
                              value={intervention.unit || 'Day(s)'}
                              onValueChange={(value) =>
                                handleInterventionChange(level, idx, 'unit', value)
                              }
                            >
                              <SelectTrigger className="bg-white border-slate-300 text-slate-900 text-sm">
                                <SelectValue />
                              </SelectTrigger>
                              <SelectContent className="bg-white border-slate-200">
                                <SelectItem value="Day(s)">Day(s)</SelectItem>
                                <SelectItem value="Hour(s)">Hour(s)</SelectItem>
                              </SelectContent>
                            </Select>
                          </div>
                        )}

                        <Button
                          type="button"
                          variant="destructive"
                          size="sm"
                          onClick={() => handleRemoveIntervention(level, idx)}
                          className="bg-red-700 hover:bg-red-800 w-full"
                        >
                          Remove
                        </Button>
                      </div>
                    );
                  })}
                </div>
              ))}
            </div>
          </div>

          <DialogFooter>
            <Button variant="outline" onClick={() => setIsDialogOpen(false)}>
              Cancel
            </Button>
            <Button onClick={handleSaveGuide} className="bg-[#2F3E46] hover:bg-[#1e2a30] text-white">
              {isEditing ? 'Update Guide' : 'Create Guide'}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

    </div>
  );
}
