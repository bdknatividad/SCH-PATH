import { useState, useRef } from 'react';
import { useData } from '@/app/state/DataContext';
import { Card, CardContent } from '@/app/components/ui/card';
import { Button } from '@/app/components/ui/button';
import { Input } from '@/app/components/ui/input';
import { Badge } from '@/app/components/ui/badge';
import { Tabs, TabsList, TabsTrigger, TabsContent } from '@/app/components/ui/tabs';
import { Label } from '@/app/components/ui/label';
import { Textarea } from '@/app/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/app/components/ui/select';
import {
  Dialog, DialogContent, DialogFooter, DialogHeader, DialogTitle,
} from '@/app/components/ui/dialog';
import {
  AlertDialog, AlertDialogContent, AlertDialogHeader, AlertDialogTitle,
  AlertDialogDescription, AlertDialogFooter, AlertDialogAction, AlertDialogCancel,
} from '@/app/components/ui/alert-dialog';
import {
  GraduationCap, Plus, Search, Upload, Eye, Edit, Trash2,
  User, FileText, BookOpen, Award, X, Download, AlertCircle,
  ChevronDown, ChevronUp, Paperclip,
} from 'lucide-react';

// ── TYPES ────────────────────────────────────────────────────────────────────

export type EducationLevel =
  | 'High School'
  | 'Senior High School'
  | 'Alternative Learning System (ALS)'
  | 'ALS - Elementary'
  | 'ALS - High School'
  | 'Calamba Manpower Development Center (CMDC)';

export interface EducationFile {
  id: string;
  name: string;
  type: string;
  size: number;
  uploadDate: string;
  category: 'Performance' | 'Evaluation' | 'Certificate' | 'Other';
  dataUrl?: string;
}

export interface Student {
  id: string;
  name: string;
  age: number;
  gender: 'Male' | 'Female';
  educationLevel: EducationLevel;
  gradeSection: string;
  school: string;
  enrollmentDate: string;
  status: 'Active' | 'Completed' | 'Dropped';
  address?: string;
  guardianName?: string;
  guardianContact?: string;
  notes?: string;
  files: EducationFile[];
}

// ── CONSTANTS ────────────────────────────────────────────────────────────────

// Progress report per student
export interface ProgressReport {
  id: string;
  studentId: string;
  month: string; // YYYY-MM
  subject: string;
  grade: number;
  result: 'Pass' | 'Fail';
  remarks: string;
  schoolVisits: number;
  createdAt: string;
}

// Monthly report
export interface MonthlyReport {
  id: string;
  month: string;
  totalLearners: number;
  schoolVisits: number;
  passCount: number;
  failCount: number;
  notes: string;
  createdAt: string;
}

export interface SchoolVisitReport {
  id: string;
  studentId: string;
  visitDate: string;
  school: string;
  purpose: string;
  findings: string;
  fileName?: string;
  fileData?: string;
  createdAt: string;
}

const STORAGE_KEY = 'educationStudents';
const VISIT_KEY = 'educationVisitReports';

const loadVisits = (): SchoolVisitReport[] => {
  try { return JSON.parse(localStorage.getItem(VISIT_KEY) || '[]'); } catch { return []; }
};
const saveVisits = (r: SchoolVisitReport[]) => {
  try { localStorage.setItem(VISIT_KEY, JSON.stringify(r)); } catch {}
};
const PROGRESS_KEY = 'educationProgressReports';
const MONTHLY_KEY  = 'educationMonthlyReports';

const loadProgress = (): ProgressReport[] => {
  try { return JSON.parse(localStorage.getItem(PROGRESS_KEY) || '[]'); } catch { return []; }
};
const saveProgress = (r: ProgressReport[]) => {
  try { localStorage.setItem(PROGRESS_KEY, JSON.stringify(r)); } catch {}
};
const loadMonthly = (): MonthlyReport[] => {
  try { return JSON.parse(localStorage.getItem(MONTHLY_KEY) || '[]'); } catch { return []; }
};
const saveMonthly = (r: MonthlyReport[]) => {
  try { localStorage.setItem(MONTHLY_KEY, JSON.stringify(r)); } catch {}
};

const EDUCATION_LEVELS: EducationLevel[] = [
  'High School',
  'Senior High School',
  'Alternative Learning System (ALS)',
  'ALS - Elementary',
  'ALS - High School',
  'Calamba Manpower Development Center (CMDC)',
];

const LEVEL_COLORS: Record<EducationLevel, { bg: string; text: string; accent: string }> = {
  'High School':                             { bg: '#DBEAFE', text: '#1E40AF', accent: '#3B82F6' },
  'Senior High School':                      { bg: '#FEF3C7', text: '#92400E', accent: '#F59E0B' },
  'Alternative Learning System (ALS)':       { bg: '#D1FAE5', text: '#065F46', accent: '#10B981' },
  'ALS - Elementary':                           { bg: '#ECFDF5', text: '#047857', accent: '#10B981' },
  'ALS - High School':                          { bg: '#F0FDF4', text: '#166534', accent: '#22C55E' },
  'Calamba Manpower Development Center (CMDC)': { bg: '#EDE9FE', text: '#5B21B6', accent: '#7C3AED' },
};

const LEVEL_SHORT: Record<EducationLevel, string> = {
  'High School': 'HS',
  'Senior High School': 'SHS',
  'Alternative Learning System (ALS)': 'ALS',
  'ALS - Elementary': 'ALS-E',
  'ALS - High School': 'ALS-HS',
  'Calamba Manpower Development Center (CMDC)': 'CMDC',
};

const EMPTY_STUDENT: Omit<Student, 'id' | 'files'> = {
  name: '',
  age: 0,
  gender: 'Male',
  educationLevel: 'High School',
  gradeSection: '',
  school: '',
  enrollmentDate: '',
  status: 'Active',
  address: '',
  guardianName: '',
  guardianContact: '',
  notes: '',
};

// ── HELPERS ──────────────────────────────────────────────────────────────────

function loadStudents(): Student[] {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    return raw ? JSON.parse(raw) : [];
  } catch { return []; }
}

function saveStudents(students: Student[]) {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(students));
}

function formatBytes(bytes: number): string {
  if (bytes < 1024) return `${bytes} B`;
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
  return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
}

// ── COMPONENT ────────────────────────────────────────────────────────────────

export function Education() {
  const [students, setStudents] = useState<Student[]>(() => loadStudents());
  const [searchTerm, setSearchTerm] = useState('');
  const [activeLevel, setActiveLevel] = useState<'all' | EducationLevel>('all');
  const { children: residents, addDocument } = useData();
  const [activeTab, setActiveTab] = useState('masterlist');

  // Student dialog
  const [isStudentDialogOpen, setIsStudentDialogOpen] = useState(false);
  const [editingStudent, setEditingStudent] = useState<Student | null>(null);
  const [studentForm, setStudentForm] = useState<Omit<Student, 'id' | 'files'>>(EMPTY_STUDENT);
  const [formError, setFormError] = useState('');

  // View/Profile dialog
  const [viewStudent, setViewStudent] = useState<Student | null>(null);
  const [isViewOpen, setIsViewOpen] = useState(false);
  const [profileTab, setProfileTab] = useState('info');

  // File upload
  const [isUploadOpen, setIsUploadOpen] = useState(false);
  const [uploadTarget, setUploadTarget] = useState<Student | null>(null);
  const [uploadCategory, setUploadCategory] = useState<EducationFile['category']>('Performance');
  const [uploadError, setUploadError] = useState('');
  const fileRef = useRef<HTMLInputElement>(null);
  const [pendingFile, setPendingFile] = useState<File | null>(null);

  // Delete
  const [deleteTarget, setDeleteTarget] = useState<Student | null>(null);

  // School Visit Reports
  const [visitReports, setVisitReports] = useState<SchoolVisitReport[]>(() => loadVisits());
  const [isVisitUploadOpen, setIsVisitUploadOpen] = useState(false);
  const [pendingVisitFile, setPendingVisitFile] = useState<File | null>(null);
  const [isVisitOpen, setIsVisitOpen] = useState(false);
  const [visitStudent, setVisitStudent] = useState<string>('');
  const [visitForm, setVisitForm] = useState({ studentId: '', visitDate: new Date().toISOString().split('T')[0], school: '', purpose: '', findings: '' });
  const [visitFile, setVisitFile] = useState<File | null>(null);
  const visitFileRef = useRef<HTMLInputElement>(null);

  const handleSaveVisit = async () => {
    if (!visitStudent) return;
    let fileData: string | undefined;
    let fileName: string | undefined;
    if (visitFile) {
      fileData = await new Promise<string>(res => {
        const reader = new FileReader();
        reader.onloadend = () => res(reader.result as string);
        reader.readAsDataURL(visitFile);
      });
      fileName = visitFile.name;
      // Save to resident's Documents module
      const student = students.find(s => s.id === visitStudent);
      const resident = residents.find(c => c.name === student?.name);
      if (resident) {
        await addDocument({
          residentId: resident.id,
          title: 'School Visit Report',
          category: 'Education',
          phase: '',
          fileName: visitFile.name,
          fileType: visitFile.type,
          fileSize: visitFile.size,
          fileData,
          uploaderRole: 'educator',
          uploadedBy: 'Educator',
          uploadedAt: new Date().toISOString(),
          status: 'Submitted',
          submittedBy: 'Educator',
          submittedAt: new Date().toISOString(),
          requiresAssessment: false,
          assessmentTriggered: false,
        } as any);
      }
    }
    const rpt: SchoolVisitReport = {
      id: Date.now().toString(),
      studentId: visitStudent,
      visitDate: visitForm.visitDate,
      school: visitForm.school,
      purpose: visitForm.purpose,
      findings: visitForm.findings,
      fileName,
      fileData,
      createdAt: new Date().toISOString(),
    };
    const updated = [...visitReports, rpt];
    setVisitReports(updated);
    saveVisits(updated);
    setIsVisitOpen(false);
    setVisitForm({ visitDate: new Date().toISOString().split('T')[0], school: '', purpose: '', findings: '' });
    setVisitFile(null);
    setVisitStudent('');
  };

  // Progress Reports
  const [progressReports, setProgressReports] = useState<ProgressReport[]>(() => loadProgress());
  const [isProgressOpen, setIsProgressOpen] = useState(false);
  const [progressStudent, setProgressStudent] = useState<Student | null>(null);
  const [progressForm, setProgressForm] = useState({ subject: '', grade: '', result: 'Pass' as 'Pass' | 'Fail', remarks: '', schoolVisits: '0', month: new Date().toISOString().substring(0, 7) });

  // Monthly Reports
  const [monthlyReports, setMonthlyReports] = useState<MonthlyReport[]>(() => loadMonthly());
  const [isMonthlyOpen, setIsMonthlyOpen] = useState(false);
  const [monthlyForm, setMonthlyForm] = useState({ month: new Date().toISOString().substring(0, 7), schoolVisits: '', notes: '' });

  // Stats
  const totalLearners = students.filter(s => s.status === 'Active').length;
  const totalVisits = visitReports.length; // each report = 1 visit


  const passCount = progressReports.filter(r => r.result === 'Pass').length;
  const failCount = progressReports.filter(r => r.result === 'Fail').length;

  const handleSaveProgress = () => {
    if (!progressStudent || !progressForm.subject.trim()) return;
    const rpt: ProgressReport = {
      id: Date.now().toString(),
      studentId: progressStudent.id,
      month: progressForm.month,
      subject: progressForm.subject,
      grade: parseFloat(progressForm.grade) || 0,
      result: progressForm.result,
      remarks: progressForm.remarks,
      schoolVisits: parseInt(progressForm.schoolVisits) || 0,
      createdAt: new Date().toISOString(),
    };
    const updated = [...progressReports, rpt];
    setProgressReports(updated);
    saveProgress(updated);
    setIsProgressOpen(false);
    setProgressForm({ subject: '', grade: '', result: 'Pass', remarks: '', schoolVisits: '0', month: new Date().toISOString().substring(0, 7) });
  };

  const handleSaveMonthly = () => {
    const activeStudents = students.filter(s => s.status === 'Active').length;
    const monthPass = progressReports.filter(r => r.month === monthlyForm.month && r.result === 'Pass').length;
    const monthFail = progressReports.filter(r => r.month === monthlyForm.month && r.result === 'Fail').length;
    const rpt: MonthlyReport = {
      id: Date.now().toString(),
      month: monthlyForm.month,
      totalLearners: activeStudents,
      schoolVisits: parseInt(monthlyForm.schoolVisits) || 0,
      passCount: monthPass,
      failCount: monthFail,
      notes: monthlyForm.notes,
      createdAt: new Date().toISOString(),
    };
    const updated = [...monthlyReports, rpt];
    setMonthlyReports(updated);
    saveMonthly(updated);
    setIsMonthlyOpen(false);
    setMonthlyForm({ month: new Date().toISOString().substring(0, 7), schoolVisits: '', notes: '' });
  };
  const [isDeleteOpen, setIsDeleteOpen] = useState(false);
  const [deleteConfirm, setDeleteConfirm] = useState('');

  // ── PERSIST ────────────────────────────────────────────────────────────────
  const persist = (updated: Student[]) => {
    setStudents(updated);
    saveStudents(updated);
  };

  // ── ADD / EDIT STUDENT ────────────────────────────────────────────────────
  const openAdd = () => {
    setEditingStudent(null);
    setStudentForm(EMPTY_STUDENT);
    setFormError('');
    setIsStudentDialogOpen(true);
  };

  const openEdit = (s: Student) => {
    setEditingStudent(s);
    setStudentForm({
      name: s.name, age: s.age, gender: s.gender,
      educationLevel: s.educationLevel, gradeSection: s.gradeSection,
      school: s.school, enrollmentDate: s.enrollmentDate,
      status: s.status, address: s.address, guardianName: s.guardianName,
      guardianContact: s.guardianContact, notes: s.notes,
    });
    setFormError('');
    setIsStudentDialogOpen(true);
  };

  const handleSaveStudent = () => {
    setFormError('');
    if (!studentForm.name.trim()) { setFormError('Name is required.'); return; }
    if (!studentForm.school.trim()) { setFormError('School is required.'); return; }
    if (!studentForm.enrollmentDate) { setFormError('Enrollment date is required.'); return; }

    if (editingStudent) {
      const updated = students.map(s =>
        s.id === editingStudent.id ? { ...s, ...studentForm } : s
      );
      persist(updated);
    } else {
      const newStudent: Student = {
        id: `STU${Date.now().toString().slice(-5)}`,
        ...studentForm,
        files: [],
      };
      persist([...students, newStudent]);
    }
    setIsStudentDialogOpen(false);
  };

  // ── FILE UPLOAD ───────────────────────────────────────────────────────────
  const openUpload = (s: Student) => {
    setUploadTarget(s);
    setUploadCategory('Performance');
    setUploadError('');
    setPendingFile(null);
    setIsUploadOpen(true);
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) setPendingFile(file);
  };

  const handleUploadConfirm = () => {
    if (!pendingFile || !uploadTarget) { setUploadError('Please select a file.'); return; }
    const reader = new FileReader();
    reader.onloadend = () => {
      const newFile: EducationFile = {
        id: `EF${Date.now()}`,
        name: pendingFile.name,
        type: pendingFile.type,
        size: pendingFile.size,
        uploadDate: new Date().toISOString().split('T')[0],
        category: uploadCategory,
        dataUrl: reader.result as string,
      };
      const updated = students.map(s =>
        s.id === uploadTarget.id
          ? { ...s, files: [...s.files, newFile] }
          : s
      );
      persist(updated);
      // also update viewStudent if open
      if (viewStudent?.id === uploadTarget.id) {
        setViewStudent(updated.find(s => s.id === uploadTarget.id) || null);
      }
      setIsUploadOpen(false);
    };
    reader.readAsDataURL(pendingFile);
  };

  const handleDeleteFile = (student: Student, fileId: string) => {
    const updated = students.map(s =>
      s.id === student.id
        ? { ...s, files: s.files.filter(f => f.id !== fileId) }
        : s
    );
    persist(updated);
    if (viewStudent?.id === student.id) {
      setViewStudent(updated.find(s => s.id === student.id) || null);
    }
  };

  // ── DELETE STUDENT ────────────────────────────────────────────────────────
  const handleDelete = () => {
    if (!deleteTarget || deleteConfirm !== deleteTarget.name) return;
    persist(students.filter(s => s.id !== deleteTarget.id));
    setIsDeleteOpen(false);
    setDeleteTarget(null);
    setDeleteConfirm('');
  };

  // ── VIEW ──────────────────────────────────────────────────────────────────
  const openView = (s: Student) => {
    setViewStudent(s);
    setProfileTab('info');
    setIsViewOpen(true);
  };

  // ── FILTER ────────────────────────────────────────────────────────────────
  const filtered = students.filter(s => {
    const matchSearch =
      s.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      s.id.toLowerCase().includes(searchTerm.toLowerCase()) ||
      s.school.toLowerCase().includes(searchTerm.toLowerCase());
    const matchLevel = activeLevel === 'all' || s.educationLevel === activeLevel;
    return matchSearch && matchLevel;
  });

  // Grouped by level for category view
  const grouped = EDUCATION_LEVELS.reduce<Record<EducationLevel, Student[]>>((acc, lvl) => {
    acc[lvl] = filtered.filter(s => s.educationLevel === lvl);
    return acc;
  }, {} as Record<EducationLevel, Student[]>);

  // ── RENDER ─────────────────────────────────────────────────────────────────
  return (
    <div className="space-y-6">

      {/* Header */}
      <div className="bg-[#2F3E46] p-6 rounded-xl shadow-md border-b-4 border-[#FFD100]">
        <div className="flex items-center gap-3">
          <div className="w-12 h-12 rounded-full bg-[#FFD100] flex items-center justify-center">
            <GraduationCap className="w-6 h-6 text-[#2F3E46]" />
          </div>
          <div>
            <h2 className="text-2xl font-bold text-white">Education Module</h2>
            <p className="text-gray-300 text-sm">Manage students, records, and educational track placements</p>
          </div>
        </div>
        {/* Stats row */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 mt-5">
          <div className="bg-white/10 rounded-xl p-3 border border-white/10">
            <p className="text-[10px] font-bold text-gray-300 uppercase tracking-wider">Total Learners</p>
            <p className="text-2xl font-black text-white mt-0.5">{totalLearners}</p>
            <p className="text-[10px] text-gray-400">Active students</p>
          </div>
          <div className="bg-white/10 rounded-xl p-3 border border-white/10">
            <p className="text-[10px] font-bold text-gray-300 uppercase tracking-wider">School Visits</p>
            <p className="text-2xl font-black text-white mt-0.5">{totalVisits}</p>
            <p className="text-[10px] text-gray-400">Total conducted</p>
          </div>
          <div className="bg-white/10 rounded-xl p-3 border border-white/10">
            <p className="text-[10px] font-bold text-[#4ade80] uppercase tracking-wider">Pass</p>
            <p className="text-2xl font-black text-white mt-0.5">{passCount}</p>
            <p className="text-[10px] text-gray-400">Passed evaluations</p>
          </div>
          <div className="bg-white/10 rounded-xl p-3 border border-white/10">
            <p className="text-[10px] font-bold text-[#f87171] uppercase tracking-wider">Fail</p>
            <p className="text-2xl font-black text-white mt-0.5">{failCount}</p>
            <p className="text-[10px] text-gray-400">Failed evaluations</p>
          </div>
        </div>
        <div className="flex gap-2 mt-4 flex-wrap">
          <button
            onClick={() => { setActiveTab('progress'); setIsProgressOpen(true); }}
            className="px-4 py-2 rounded-xl text-xs font-bold bg-[#FFD100] text-[#2F3E46] hover:bg-yellow-300 transition-all">
            Generate Education Progress Report
          </button>
          <button
            onClick={() => { setActiveTab('monthly'); setIsMonthlyOpen(true); }}
            className="px-4 py-2 rounded-xl text-xs font-bold bg-white/20 text-white border border-white/40 hover:bg-white/30 transition-all">
            Generate Monthly Report
          </button>
        </div>
      </div>

      {/* Toolbar */}
      <div className="flex flex-col sm:flex-row gap-3 justify-between items-start sm:items-center">
        <div className="flex gap-2 flex-1 w-full sm:max-w-md">
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
            <Input
              className="pl-10 rounded-xl"
              placeholder="Search by name, ID, or school..."
              value={searchTerm}
              onChange={e => setSearchTerm(e.target.value)}
            />
          </div>
        </div>
        <Button
          onClick={openAdd}
          className="gap-2 font-bold rounded-xl px-5 shrink-0"
          style={{ backgroundColor: '#FFD100', color: '#2F3E46' }}
        >
          <Plus className="w-4 h-4" /> Add Student
        </Button>
      </div>

      {/* Main Tabs */}
      <Tabs value={activeTab} onValueChange={setActiveTab}>
        <TabsList className="mb-2 w-full flex">
          <TabsTrigger value="masterlist" className="flex-1">Student Master List ({students.length})</TabsTrigger>
          <TabsTrigger value="byLevel" className="flex-1">By Educational Level</TabsTrigger>
          <TabsTrigger value="progress" className="flex-1">Progress Report</TabsTrigger>
          <TabsTrigger value="monthly" className="flex-1">Monthly Report</TabsTrigger>
          <TabsTrigger value="visits" className="flex-1">School Visits</TabsTrigger>
        </TabsList>

        {/* MASTER LIST */}
        <TabsContent value="masterlist">
          {/* Level filter pills */}
          <div className="flex flex-wrap gap-2 mb-4">
            <button
              onClick={() => setActiveLevel('all')}
              className={`px-3 py-1.5 rounded-full text-xs font-bold border transition-all ${
                activeLevel === 'all'
                  ? 'bg-[#2F3E46] text-white border-[#2F3E46]'
                  : 'border-gray-200 text-gray-600 hover:border-[#2F3E46]'
              }`}
            >
              All ({students.length})
            </button>
            {EDUCATION_LEVELS.map(lvl => {
              const c = LEVEL_COLORS[lvl];
              const count = students.filter(s => s.educationLevel === lvl).length;
              return (
                <button
                  key={lvl}
                  onClick={() => setActiveLevel(lvl)}
                  className={`px-3 py-1.5 rounded-full text-xs font-bold border transition-all ${
                    activeLevel === lvl
                      ? 'border-transparent text-white'
                      : 'border-gray-200 text-gray-600 hover:border-gray-400'
                  }`}
                  style={activeLevel === lvl ? { backgroundColor: c.accent } : {}}
                >
                  {LEVEL_SHORT[lvl]} ({count})
                </button>
              );
            })}
          </div>

          {filtered.length === 0 ? (
            <div className="text-center py-16 text-gray-400">
              <GraduationCap className="w-10 h-10 mx-auto mb-2 opacity-20" />
              <p className="text-sm italic">No students found.</p>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {filtered.map(student => <StudentCard key={student.id} student={student} onView={openView} onEdit={openEdit} onUpload={openUpload} onDelete={s => { setDeleteTarget(s); setDeleteConfirm(''); setIsDeleteOpen(true); }} />)}
            </div>
          )}
        </TabsContent>

        {/* BY LEVEL */}
        <TabsContent value="byLevel">
          <div className="space-y-6">
            {EDUCATION_LEVELS.map(lvl => {
              const c = LEVEL_COLORS[lvl];
              const list = grouped[lvl];
              return (
                <div key={lvl}>
                  <div className="flex items-center gap-3 mb-3 pb-2 border-b-2" style={{ borderColor: c.accent }}>
                    <div className="w-8 h-8 rounded-full flex items-center justify-center font-black text-xs" style={{ backgroundColor: c.bg, color: c.text }}>
                      {LEVEL_SHORT[lvl]}
                    </div>
                    <div>
                      <h3 className="font-bold text-[#2F3E46]">{lvl}</h3>
                      <p className="text-xs text-gray-400">{list.length} student{list.length !== 1 ? 's' : ''}</p>
                    </div>
                  </div>
                  {list.length === 0 ? (
                    <p className="text-sm text-gray-400 italic pl-11">No students enrolled in this track.</p>
                  ) : (
                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                      {list.map(s => <StudentCard key={s.id} student={s} onView={openView} onEdit={openEdit} onUpload={openUpload} onDelete={s => { setDeleteTarget(s); setDeleteConfirm(''); setIsDeleteOpen(true); }} />)}
                    </div>
                  )}
                </div>
              );
            })}
          </div>
        </TabsContent>

        {/* ── SCHOOL VISIT REPORTS TAB ── */}
        <TabsContent value="visits" className="space-y-4">
          <div className="flex justify-between items-center">
            <div>
              <h3 className="font-bold text-[#2F3E46]">School Visit Reports</h3>
              <p className="text-xs text-gray-400 mt-0.5">Each uploaded report = 1 school visit counted</p>
            </div>
            <Button className="bg-[#2F3E46] text-white" onClick={() => setIsVisitUploadOpen(true)}>
              <Plus className="w-4 h-4 mr-1" /> Upload Visit Report
            </Button>
          </div>

          {/* Per-student visit count */}
          {students.filter(s => s.status === 'Active').length > 0 && (
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
              {students.filter(s => s.status === 'Active').map(s => {
                const count = visitReports.filter(v => v.studentId === s.id).length;
                return (
                  <div key={s.id} className="p-3 border border-gray-200 rounded-xl bg-white flex items-center gap-3">
                    <div className="w-9 h-9 rounded-full bg-[#2F3E46] text-white flex items-center justify-center font-bold text-sm shrink-0">
                      {s.name.charAt(0)}
                    </div>
                    <div className="min-w-0">
                      <p className="text-xs font-bold text-[#2F3E46] truncate">{s.name}</p>
                      <p className="text-[10px] text-gray-400">{count} school visit{count !== 1 ? 's' : ''} recorded</p>
                    </div>
                  </div>
                );
              })}
            </div>
          )}

          {visitReports.length === 0 ? (
            <div className="text-center py-12 text-gray-400">
              <FileText className="w-10 h-10 mx-auto mb-2 opacity-30" />
              <p>No school visit reports uploaded yet.</p>
            </div>
          ) : (
            <div className="space-y-2">
              {visitReports.sort((a,b) => b.createdAt.localeCompare(a.createdAt)).map(r => {
                const student = students.find(s => s.id === r.studentId);
                return (
                  <div key={r.id} className="border border-gray-200 rounded-xl p-3 bg-white flex items-start gap-3">
                    <div className="w-8 h-8 rounded-lg bg-blue-100 flex items-center justify-center shrink-0">
                      <FileText className="w-4 h-4 text-blue-600" />
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2 flex-wrap">
                        <p className="text-sm font-bold text-[#2F3E46]">{student?.name || '—'}</p>
                        <span className="text-[10px] text-gray-400">{r.visitDate}</span>
                      </div>
                      <p className="text-xs text-gray-600">{r.school}{r.purpose ? ` — ${r.purpose}` : ''}</p>
                      {r.findings && <p className="text-xs text-gray-400 italic mt-0.5">{r.findings}</p>}
                      {r.fileName && (
                        <p className="text-[10px] text-blue-600 mt-1 flex items-center gap-1">
                          <Paperclip className="w-3 h-3" /> {r.fileName}
                        </p>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </TabsContent>

      </Tabs>

      {/* ── ADD / EDIT STUDENT DIALOG ── */}
      <Dialog open={isStudentDialogOpen} onOpenChange={open => { if (!open) setIsStudentDialogOpen(false); }}>
        <DialogContent className="max-w-lg max-h-[90vh] overflow-y-auto rounded-2xl">
          <DialogHeader>
            <DialogTitle className="text-[#2F3E46] font-bold">
              {editingStudent ? 'Edit Student' : 'Add New Student'}
            </DialogTitle>
          </DialogHeader>

          <div className="space-y-4 py-2">
            {formError && (
              <div className="bg-red-50 border border-red-200 rounded-xl p-3 text-sm text-red-700 flex items-center gap-2">
                <AlertCircle className="w-4 h-4 shrink-0" /> {formError}
              </div>
            )}

            <div className="grid grid-cols-2 gap-3">
              <div className="col-span-2 space-y-1.5">
                <Label className="font-bold text-[#2F3E46]">Resident / Learner *</Label>
                <Select value={studentForm.name} onValueChange={v => {
                  const res = residents.find(r => r.name === v);
                  setStudentForm(p => ({
                    ...p,
                    name: v,
                    gender: (res?.gender as 'Male' | 'Female') || 'Male',
                    age: res?.age || p.age,
                  }));
                }}>
                  <SelectTrigger className="rounded-xl"><SelectValue placeholder="Select resident..." /></SelectTrigger>
                  <SelectContent>
                    {residents.filter(r => r.status !== 'Discharged').map(r => (
                      <SelectItem key={r.id} value={r.name}>{r.name} ({r.id})</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-1.5">
                <Label className="font-bold text-[#2F3E46]">Age *</Label>
                <Input type="number" min={1} max={30} value={studentForm.age || ''} onChange={e => setStudentForm(p => ({ ...p, age: Number(e.target.value) }))} className="rounded-xl" />
              </div>
              <div className="space-y-1.5">
                <Label className="font-bold text-[#2F3E46]">Gender</Label>
                <div className="rounded-xl border bg-gray-50 px-3 py-2 text-sm text-[#2F3E46] font-semibold">Male</div>
              </div>
              <div className="col-span-2 space-y-1.5">
                <Label className="font-bold text-[#2F3E46]">Educational Level *</Label>
                <Select value={studentForm.educationLevel} onValueChange={v => setStudentForm(p => ({ ...p, educationLevel: v as EducationLevel }))}>
                  <SelectTrigger className="rounded-xl"><SelectValue /></SelectTrigger>
                  <SelectContent>
                    {EDUCATION_LEVELS.map(l => <SelectItem key={l} value={l}>{l}</SelectItem>)}
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-1.5">
                <Label className="font-bold text-[#2F3E46]">Grade / Section</Label>
                <Input value={studentForm.gradeSection} onChange={e => setStudentForm(p => ({ ...p, gradeSection: e.target.value }))} placeholder="e.g. Grade 9 - Amity" className="rounded-xl" />
              </div>
              <div className="space-y-1.5">
                <Label className="font-bold text-[#2F3E46]">Status</Label>
                <Select value={studentForm.status} onValueChange={v => setStudentForm(p => ({ ...p, status: v as Student['status'] }))}>
                  <SelectTrigger className="rounded-xl"><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="Active">Active</SelectItem>
                    <SelectItem value="Completed">Completed</SelectItem>
                    <SelectItem value="Dropped">Dropped</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="col-span-2 space-y-1.5">
                <Label className="font-bold text-[#2F3E46]">School / Institution *</Label>
                <Input value={studentForm.school} onChange={e => setStudentForm(p => ({ ...p, school: e.target.value }))} placeholder="School name" className="rounded-xl" />
              </div>
              <div className="col-span-2 space-y-1.5">
                <Label className="font-bold text-[#2F3E46]">Enrollment Date *</Label>
                <Input type="date" value={studentForm.enrollmentDate} onChange={e => setStudentForm(p => ({ ...p, enrollmentDate: e.target.value }))} className="rounded-xl" />
              </div>
              <div className="col-span-2 space-y-1.5">
                <Label className="font-bold text-[#2F3E46]">Address</Label>
                <Input value={studentForm.address} onChange={e => setStudentForm(p => ({ ...p, address: e.target.value }))} placeholder="Home address" className="rounded-xl" />
              </div>
              <div className="space-y-1.5">
                <Label className="font-bold text-[#2F3E46]">Guardian Name</Label>
                <Input value={studentForm.guardianName} onChange={e => setStudentForm(p => ({ ...p, guardianName: e.target.value }))} className="rounded-xl" />
              </div>
              <div className="space-y-1.5">
                <Label className="font-bold text-[#2F3E46]">Guardian Contact</Label>
                <Input value={studentForm.guardianContact} onChange={e => setStudentForm(p => ({ ...p, guardianContact: e.target.value }))} className="rounded-xl" />
              </div>
              <div className="col-span-2 space-y-1.5">
                <Label className="font-bold text-[#2F3E46]">Notes</Label>
                <Textarea value={studentForm.notes} onChange={e => setStudentForm(p => ({ ...p, notes: e.target.value }))} className="rounded-xl min-h-[80px]" placeholder="Additional notes..." />
              </div>
            </div>
          </div>

          <DialogFooter className="gap-2">
            <Button variant="outline" className="rounded-xl" onClick={() => setIsStudentDialogOpen(false)}>Cancel</Button>
            <Button className="rounded-xl px-6 font-bold" style={{ backgroundColor: '#2F3E46', color: 'white' }} onClick={handleSaveStudent}>
              {editingStudent ? 'Save Changes' : 'Add Student'}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* ── VIEW / PROFILE DIALOG ── */}
      <Dialog open={isViewOpen} onOpenChange={open => { if (!open) setIsViewOpen(false); }}>
        <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto rounded-2xl p-0">
          {viewStudent && (() => {
            const c = LEVEL_COLORS[viewStudent.educationLevel];
            return (
              <>
                <div className="p-6 border-b" style={{ backgroundColor: c.bg }}>
                  <div className="flex items-center gap-4">
                    <div className="w-14 h-14 rounded-full flex items-center justify-center font-black text-lg" style={{ backgroundColor: c.accent, color: 'white' }}>
                      {viewStudent.name.charAt(0)}
                    </div>
                    <div>
                      <h2 className="text-xl font-bold" style={{ color: c.text }}>{viewStudent.name}</h2>
                      <div className="flex items-center gap-2 mt-1 flex-wrap">
                        <Badge style={{ backgroundColor: c.accent, color: 'white', border: 'none' }} className="text-xs">{LEVEL_SHORT[viewStudent.educationLevel]}</Badge>
                        <span className="text-xs font-medium" style={{ color: c.text }}>{viewStudent.educationLevel}</span>
                        <span className="text-xs text-gray-500">· {viewStudent.id}</span>
                      </div>
                    </div>
                  </div>
                </div>

                <div className="p-6">
                  <Tabs value={profileTab} onValueChange={setProfileTab}>
                    <TabsList className="mb-4">
                      <TabsTrigger value="info">Personal Info</TabsTrigger>
                      <TabsTrigger value="evaluation">Pass / Fail</TabsTrigger>
                      <TabsTrigger value="files">
                        Files ({viewStudent.files.length})
                      </TabsTrigger>
                    </TabsList>

                    <TabsContent value="info">
                      <div className="grid grid-cols-2 gap-4 text-sm">
                        {[
                          ['Age', viewStudent.age],
                          ['Gender', viewStudent.gender],
                          ['Grade / Section', viewStudent.gradeSection || '—'],
                          ['School', viewStudent.school],
                          ['Enrollment Date', viewStudent.enrollmentDate],
                          ['Status', viewStudent.status],
                          ['Address', viewStudent.address || '—'],
                          ['Guardian', viewStudent.guardianName || '—'],
                          ['Guardian Contact', viewStudent.guardianContact || '—'],
                        ].map(([label, val]) => (
                          <div key={String(label)} className={label === 'Address' || label === 'School' ? 'col-span-2' : ''}>
                            <p className="text-[10px] font-bold text-gray-400 uppercase tracking-wider">{label}</p>
                            <p className="font-semibold text-[#2F3E46] mt-0.5">{String(val)}</p>
                          </div>
                        ))}
                        {viewStudent.notes && (
                          <div className="col-span-2">
                            <p className="text-[10px] font-bold text-gray-400 uppercase tracking-wider">Notes</p>
                            <p className="text-gray-600 mt-0.5 text-sm italic">{viewStudent.notes}</p>
                          </div>
                        )}
                      </div>
                    </TabsContent>

                    <TabsContent value="evaluation" className="space-y-4 py-2">
                      <p className="text-sm text-gray-600 font-semibold">Evaluate educational progress for <strong>{viewStudent.name}</strong>:</p>
                      <div className="flex gap-3">
                        {(['Pass', 'Fail'] as const).map(result => (
                          <button key={result} onClick={() => {
                            const rpt: ProgressReport = {
                              id: Date.now().toString(),
                              studentId: viewStudent.id,
                              month: new Date().toISOString().substring(0, 7),
                              subject: 'General Evaluation',
                              grade: result === 'Pass' ? 75 : 60,
                              result,
                              remarks: `Marked ${result} by Educator on ${new Date().toLocaleDateString()}`,
                              schoolVisits: 0,
                              createdAt: new Date().toISOString(),
                            };
                            const updated = [...progressReports, rpt];
                            setProgressReports(updated);
                            saveProgress(updated);
                          }}
                          className={`flex-1 py-4 rounded-xl border-2 text-lg font-black transition-all ${
                            result === 'Pass'
                              ? 'border-green-500 bg-green-50 text-green-700 hover:bg-green-100'
                              : 'border-red-500 bg-red-50 text-red-700 hover:bg-red-100'
                          }`}>
                            {result === 'Pass' ? '✓ Pass' : '✕ Fail'}
                          </button>
                        ))}
                      </div>
                      <div className="border-t pt-3">
                        <p className="text-xs font-bold text-gray-500 uppercase mb-2">Evaluation History</p>
                        {progressReports.filter(r => r.studentId === viewStudent.id).length === 0
                          ? <p className="text-xs text-gray-400 italic">No evaluations yet.</p>
                          : progressReports.filter(r => r.studentId === viewStudent.id).map(r => (
                            <div key={r.id} className="flex items-center justify-between py-1.5 border-b border-gray-50 text-xs">
                              <span className="text-gray-600">{r.subject} — {r.month}</span>
                              <span className={`font-bold px-2 py-0.5 rounded-full ${r.result === 'Pass' ? 'bg-green-100 text-green-700' : 'bg-red-100 text-red-700'}`}>{r.result}</span>
                            </div>
                          ))
                        }
                      </div>
                    </TabsContent>
                    <TabsContent value="files">
                      <div className="flex justify-between items-center mb-3">
                        <p className="text-sm font-bold text-[#2F3E46]">Uploaded Documents</p>
                        <Button size="sm" className="rounded-lg gap-1.5 font-bold" style={{ backgroundColor: '#FFD100', color: '#2F3E46' }} onClick={() => { openUpload(viewStudent); }}>
                          <Upload className="w-3.5 h-3.5" /> Upload
                        </Button>
                      </div>

                      {viewStudent.files.length === 0 ? (
                        <div className="text-center py-10 bg-gray-50 rounded-xl border border-dashed border-gray-200">
                          <Paperclip className="w-8 h-8 mx-auto mb-2 text-gray-300" />
                          <p className="text-sm text-gray-400 italic">No files uploaded yet.</p>
                        </div>
                      ) : (
                        <div className="space-y-2">
                          {viewStudent.files.map(f => (
                            <div key={f.id} className="flex items-center gap-3 p-3 bg-gray-50 rounded-xl border border-gray-100 hover:border-gray-300 transition-colors">
                              <div className="w-8 h-8 rounded-lg bg-[#2F3E46]/10 flex items-center justify-center shrink-0">
                                <FileText className="w-4 h-4 text-[#2F3E46]" />
                              </div>
                              <div className="flex-1 min-w-0">
                                <p className="text-sm font-semibold text-[#2F3E46] truncate">{f.name}</p>
                                <p className="text-[10px] text-gray-400">{f.category} · {formatBytes(f.size)} · {f.uploadDate}</p>
                              </div>
                              <div className="flex gap-1 shrink-0">
                                {f.dataUrl && (
                                  <a href={f.dataUrl} download={f.name}>
                                    <Button size="icon" variant="ghost" className="h-7 w-7 hover:bg-blue-50">
                                      <Download className="w-3.5 h-3.5 text-blue-500" />
                                    </Button>
                                  </a>
                                )}
                                <Button size="icon" variant="ghost" className="h-7 w-7 hover:bg-red-50 text-red-400" onClick={() => handleDeleteFile(viewStudent, f.id)}>
                                  <Trash2 className="w-3.5 h-3.5" />
                                </Button>
                              </div>
                            </div>
                          ))}
                        </div>
                      )}
                    </TabsContent>
                  </Tabs>
                </div>
              </>
            );
          })()}
        </DialogContent>
      </Dialog>

      {/* ── FILE UPLOAD DIALOG ── */}
      <Dialog open={isUploadOpen} onOpenChange={open => { if (!open) setIsUploadOpen(false); }}>
        <DialogContent className="max-w-sm rounded-2xl">
          <DialogHeader>
            <DialogTitle className="text-[#2F3E46] font-bold flex items-center gap-2">
              <Upload className="w-5 h-5" /> Upload File
            </DialogTitle>
          </DialogHeader>
          <div className="space-y-4 py-2">
            {uploadError && (
              <div className="bg-red-50 border border-red-200 rounded-xl p-3 text-sm text-red-700 flex items-center gap-2">
                <AlertCircle className="w-4 h-4 shrink-0" /> {uploadError}
              </div>
            )}
            <div className="space-y-1.5">
              <Label className="font-bold text-[#2F3E46]">Student</Label>
              <p className="text-sm font-semibold text-gray-600">{uploadTarget?.name}</p>
            </div>
            <div className="space-y-1.5">
              <Label className="font-bold text-[#2F3E46]">Category *</Label>
              <Select value={uploadCategory} onValueChange={v => setUploadCategory(v as EducationFile['category'])}>
                <SelectTrigger className="rounded-xl"><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="Performance">Performance</SelectItem>
                  <SelectItem value="Evaluation">Evaluation</SelectItem>
                  <SelectItem value="Certificate">Certificate</SelectItem>
                  <SelectItem value="Other">Other</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-1.5">
              <Label className="font-bold text-[#2F3E46]">File *</Label>
              <div
                className="border-2 border-dashed border-gray-200 rounded-xl p-6 text-center cursor-pointer hover:border-[#FFD100] transition-colors"
                onClick={() => fileRef.current?.click()}
              >
                {pendingFile ? (
                  <div className="flex items-center gap-2 justify-center">
                    <FileText className="w-5 h-5 text-[#2F3E46]" />
                    <span className="text-sm font-semibold text-[#2F3E46] truncate max-w-[180px]">{pendingFile.name}</span>
                    <button onClick={e => { e.stopPropagation(); setPendingFile(null); }} className="text-red-400 hover:text-red-600">
                      <X className="w-4 h-4" />
                    </button>
                  </div>
                ) : (
                  <>
                    <Upload className="w-8 h-8 mx-auto mb-2 text-gray-300" />
                    <p className="text-sm text-gray-400">Click to select a file</p>
                  </>
                )}
              </div>
              <input ref={fileRef} type="file" className="hidden" onChange={handleFileChange} />
            </div>
          </div>
          <DialogFooter className="gap-2">
            <Button variant="outline" className="rounded-xl" onClick={() => setIsUploadOpen(false)}>Cancel</Button>
            <Button className="rounded-xl font-bold" style={{ backgroundColor: '#2F3E46', color: 'white' }} onClick={handleUploadConfirm}>
              Upload
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* ── DELETE DIALOG ── */}
      <AlertDialog open={isDeleteOpen} onOpenChange={setIsDeleteOpen}>
        <AlertDialogContent className="rounded-2xl bg-white">
          <AlertDialogHeader>
            <AlertDialogTitle className="flex items-center gap-2 text-red-600">
              <AlertCircle className="w-5 h-5" /> Confirm Delete
            </AlertDialogTitle>
            <AlertDialogDescription className="space-y-3">
              <span>This will permanently remove <strong>{deleteTarget?.name}</strong> from the master list.</span>
              <div className="pt-2 space-y-1.5">
                <Label className="text-xs text-gray-600">Type <strong>{deleteTarget?.name}</strong> to confirm:</Label>
                <Input value={deleteConfirm} onChange={e => setDeleteConfirm(e.target.value)} placeholder="Student name" className="rounded-xl" />
              </div>
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel onClick={() => setDeleteConfirm('')}>Cancel</AlertDialogCancel>
            <AlertDialogAction
              onClick={handleDelete}
              disabled={deleteConfirm !== deleteTarget?.name}
              className="bg-red-600 hover:bg-red-700 text-white"
            >
              Delete Student
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
      {/* ── SCHOOL VISIT REPORT DIALOG ── */}
      <Dialog open={isVisitOpen} onOpenChange={setIsVisitOpen}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle className="text-[#2F3E46]">Upload School Visit Report</DialogTitle>
          </DialogHeader>
          <div className="space-y-3 py-2">
            <div className="space-y-1">
              <Label className="text-sm font-bold">Learner *</Label>
              <Select value={visitStudent} onValueChange={setVisitStudent}>
                <SelectTrigger><SelectValue placeholder="Select learner..." /></SelectTrigger>
                <SelectContent>
                  {students.filter(s => s.status === 'Active').map(s => (
                    <SelectItem key={s.id} value={s.id}>{s.name}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-1">
                <Label className="text-sm font-bold">Visit Date *</Label>
                <Input type="date" value={visitForm.visitDate} onChange={e => setVisitForm({...visitForm, visitDate: e.target.value})} />
              </div>
              <div className="space-y-1">
                <Label className="text-sm font-bold">School Name</Label>
                <Input value={visitForm.school} onChange={e => setVisitForm({...visitForm, school: e.target.value})} placeholder="School name..." />
              </div>
            </div>
            <div className="space-y-1">
              <Label className="text-sm font-bold">Purpose of Visit</Label>
              <Input value={visitForm.purpose} onChange={e => setVisitForm({...visitForm, purpose: e.target.value})} placeholder="e.g. Academic monitoring, coordination..." />
            </div>
            <div className="space-y-1">
              <Label className="text-sm font-bold">Findings / Observations</Label>
              <Textarea value={visitForm.findings} onChange={e => setVisitForm({...visitForm, findings: e.target.value})} rows={2} placeholder="Notes from the visit..." />
            </div>
            <div className="space-y-1">
              <Label className="text-sm font-bold">Upload Report File (optional)</Label>
              <input type="file" ref={visitFileRef} className="hidden" onChange={e => setPendingVisitFile(e.target.files?.[0] || null)} />
              <Button type="button" variant="outline" className="w-full" onClick={() => visitFileRef.current?.click()}>
                <Upload className="w-4 h-4 mr-2" /> {visitFile ? visitFile.name : 'Choose file...'}
              </Button>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => { setIsVisitOpen(false); setVisitFile(null); }}>Cancel</Button>
            <Button onClick={handleSaveVisit} disabled={!visitStudent} className="bg-[#2F3E46] text-white">Save Visit Report</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* ── ADD PROGRESS REPORT DIALOG ── */}
      <Dialog open={isProgressOpen} onOpenChange={setIsProgressOpen}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle className="text-[#2F3E46]">Add Education Progress Report</DialogTitle>
          </DialogHeader>
          <div className="space-y-3 py-2">
            <div className="space-y-1">
              <Label className="text-sm font-bold">Learner *</Label>
              <Select value={progressStudent?.id || ''} onValueChange={id => setProgressStudent(students.find(s => s.id === id) || null)}>
                <SelectTrigger><SelectValue placeholder="Select learner..." /></SelectTrigger>
                <SelectContent>
                  {students.filter(s => s.status === 'Active').map(s => (
                    <SelectItem key={s.id} value={s.id}>{s.name}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-1">
                <Label className="text-sm font-bold">Month *</Label>
                <Input type="month" value={progressForm.month} onChange={e => setProgressForm({...progressForm, month: e.target.value})} />
              </div>
              <div className="space-y-1">
                <Label className="text-sm font-bold">School Visits</Label>
                <Input type="number" min="0" value={progressForm.schoolVisits} onChange={e => setProgressForm({...progressForm, schoolVisits: e.target.value})} placeholder="0" />
              </div>
            </div>
            <div className="space-y-1">
              <Label className="text-sm font-bold">Subject / Area *</Label>
              <Input value={progressForm.subject} onChange={e => setProgressForm({...progressForm, subject: e.target.value})} placeholder="e.g. Mathematics, Science, ALS Module..." />
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-1">
                <Label className="text-sm font-bold">Grade / Score</Label>
                <Input type="number" min="0" max="100" value={progressForm.grade} onChange={e => setProgressForm({...progressForm, grade: e.target.value})} placeholder="e.g. 85" />
              </div>
              <div className="space-y-1">
                <Label className="text-sm font-bold">Result *</Label>
                <div className="flex gap-2 mt-1">
                  {(['Pass', 'Fail'] as const).map(r => (
                    <button key={r} onClick={() => setProgressForm({...progressForm, result: r})}
                      className={`flex-1 py-2 rounded-xl border-2 text-sm font-bold transition-all ${
                        progressForm.result === r
                          ? r === 'Pass' ? 'border-green-500 bg-green-50 text-green-700' : 'border-red-500 bg-red-50 text-red-700'
                          : 'border-gray-200 text-gray-400 hover:border-gray-300'
                      }`}>{r}</button>
                  ))}
                </div>
              </div>
            </div>
            <div className="space-y-1">
              <Label className="text-sm font-bold">Remarks</Label>
              <Textarea value={progressForm.remarks} onChange={e => setProgressForm({...progressForm, remarks: e.target.value})} placeholder="Additional observations..." rows={2} />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setIsProgressOpen(false)}>Cancel</Button>
            <Button onClick={handleSaveProgress} disabled={!progressStudent || !progressForm.subject.trim()} className="bg-[#2F3E46] text-white">
              Save Report
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* ── MONTHLY REPORT DIALOG ── */}
      <Dialog open={isMonthlyOpen} onOpenChange={setIsMonthlyOpen}>
        <DialogContent className="max-w-sm">
          <DialogHeader>
            <DialogTitle className="text-[#2F3E46]">Generate Monthly Report</DialogTitle>
          </DialogHeader>
          <div className="space-y-3 py-2">
            <p className="text-xs text-gray-500">The report will automatically count learners, and pass/fail results for the selected month.</p>
            <div className="space-y-1">
              <Label className="text-sm font-bold">Month *</Label>
              <Input type="month" value={monthlyForm.month} onChange={e => setMonthlyForm({...monthlyForm, month: e.target.value})} />
            </div>
            <div className="space-y-1">
              <Label className="text-sm font-bold">School Visits Conducted</Label>
              <Input type="number" min="0" value={monthlyForm.schoolVisits} onChange={e => setMonthlyForm({...monthlyForm, schoolVisits: e.target.value})} placeholder="Enter number of school visits" />
            </div>
            <div className="space-y-1">
              <Label className="text-sm font-bold">Notes / Summary</Label>
              <Textarea value={monthlyForm.notes} onChange={e => setMonthlyForm({...monthlyForm, notes: e.target.value})} placeholder="Summary of the month's education activities..." rows={3} />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setIsMonthlyOpen(false)}>Cancel</Button>
            <Button onClick={handleSaveMonthly} className="bg-[#2F3E46] text-white">Generate Report</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* ── SCHOOL VISIT UPLOAD DIALOG ── */}
      <Dialog open={isVisitUploadOpen} onOpenChange={setIsVisitUploadOpen}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle className="text-[#2F3E46]">Upload School Visit Report</DialogTitle>
          </DialogHeader>
          <div className="space-y-3 py-2">
            <div className="space-y-1">
              <Label className="text-sm font-bold">Resident / Learner *</Label>
              <Select value={visitForm.studentId} onValueChange={v => setVisitForm(p => ({...p, studentId: v}))}>
                <SelectTrigger><SelectValue placeholder="Select learner..." /></SelectTrigger>
                <SelectContent>
                  {students.filter(s => s.status === 'Active').map(s => (
                    <SelectItem key={s.id} value={s.id}>{s.name}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-1">
                <Label className="text-sm font-bold">Visit Date *</Label>
                <Input type="date" value={visitForm.visitDate} onChange={e => setVisitForm(p => ({...p, visitDate: e.target.value}))} />
              </div>
              <div className="space-y-1">
                <Label className="text-sm font-bold">School *</Label>
                <Input value={visitForm.school} onChange={e => setVisitForm(p => ({...p, school: e.target.value}))} placeholder="School name" />
              </div>
            </div>
            <div className="space-y-1">
              <Label className="text-sm font-bold">Purpose of Visit</Label>
              <Input value={visitForm.purpose} onChange={e => setVisitForm(p => ({...p, purpose: e.target.value}))} placeholder="e.g. Academic monitoring, enrollment..." />
            </div>
            <div className="space-y-1">
              <Label className="text-sm font-bold">Findings / Notes</Label>
              <Textarea value={visitForm.findings} onChange={e => setVisitForm(p => ({...p, findings: e.target.value}))} rows={2} placeholder="Summary of visit findings..." />
            </div>
            <div className="space-y-1">
              <Label className="text-sm font-bold">Attach Report File (optional)</Label>
              <div className="flex items-center gap-2">
                <Button variant="outline" size="sm" onClick={() => visitFileRef.current?.click()}>
                  <Upload className="w-4 h-4 mr-1" /> Choose File
                </Button>
                {pendingVisitFile && <span className="text-xs text-gray-500 truncate">{pendingVisitFile.name}</span>}
              </div>
              <input ref={visitFileRef} type="file" className="hidden"
                onChange={e => setPendingVisitFile(e.target.files?.[0] || null)} />
              <p className="text-[10px] text-gray-400">File will also be saved to the resident's Documents folder.</p>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => { setIsVisitUploadOpen(false); setPendingVisitFile(null); }}>Cancel</Button>
            <Button onClick={handleSaveVisit} disabled={!visitForm.studentId || !visitForm.school} className="bg-[#2F3E46] text-white">
              Save Visit Report
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

    </div>
  );
}

// ── STUDENT CARD ──────────────────────────────────────────────────────────────

function StudentCard({
  student, onView, onEdit, onUpload, onDelete,
}: {
  student: Student;
  onView: (s: Student) => void;
  onEdit: (s: Student) => void;
  onUpload: (s: Student) => void;
  onDelete: (s: Student) => void;
}) {
  const c = LEVEL_COLORS[student.educationLevel];
  const statusColor = student.status === 'Active' ? '#10B981' : student.status === 'Completed' ? '#3B82F6' : '#EF4444';

  return (
    <Card className="overflow-hidden border-none shadow-md hover:shadow-lg transition-shadow rounded-2xl">
      <div className="h-1.5" style={{ backgroundColor: c.accent }} />
      <CardContent className="p-5">
        <div className="flex justify-between items-start mb-3">
          <div className="flex items-center gap-2.5">
            <div className="w-10 h-10 rounded-full flex items-center justify-center font-black text-sm" style={{ backgroundColor: c.bg, color: c.text }}>
              {student.name.charAt(0)}
            </div>
            <div>
              <p className="font-bold text-[#2F3E46] leading-tight">{student.name}</p>
              <p className="text-[10px] text-gray-400 font-mono">{student.id}</p>
            </div>
          </div>
          <div className="flex flex-col items-end gap-1">
            <Badge className="border-none text-[10px] font-bold" style={{ backgroundColor: c.bg, color: c.text }}>
              {LEVEL_SHORT[student.educationLevel]}
            </Badge>
            <span className="text-[10px] font-bold" style={{ color: statusColor }}>{student.status}</span>
          </div>
        </div>

        <div className="space-y-1 text-xs text-gray-500 mb-3">
          <p><span className="font-semibold text-gray-600">School:</span> {student.school}</p>
          {student.gradeSection && <p><span className="font-semibold text-gray-600">Grade:</span> {student.gradeSection}</p>}
          <p><span className="font-semibold text-gray-600">Enrolled:</span> {student.enrollmentDate}</p>
          <p><span className="font-semibold text-gray-600">Files:</span> {student.files.length} document{student.files.length !== 1 ? 's' : ''}</p>
        </div>

        <div className="flex justify-between items-center pt-2 border-t border-gray-100 gap-1">
          <Button size="icon" variant="ghost" className="h-8 w-8 hover:bg-blue-50" onClick={() => onView(student)} title="View Profile">
            <Eye className="w-3.5 h-3.5 text-blue-500" />
          </Button>
          <Button size="icon" variant="ghost" className="h-8 w-8 hover:bg-[#FFD100]/20" onClick={() => onEdit(student)} title="Edit">
            <Edit className="w-3.5 h-3.5 text-[#2F3E46]" />
          </Button>
          <Button size="icon" variant="ghost" className="h-8 w-8 hover:bg-green-50" onClick={() => onUpload(student)} title="Upload File">
            <Upload className="w-3.5 h-3.5 text-green-600" />
          </Button>
          <Button size="icon" variant="ghost" className="h-8 w-8 hover:bg-red-50" onClick={() => onDelete(student)} title="Delete">
            <Trash2 className="w-3.5 h-3.5 text-red-400" />
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}
