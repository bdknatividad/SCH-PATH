import { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Card, CardContent, CardHeader, CardTitle } from '@/app/components/ui/card';
import { Button } from '@/app/components/ui/button';
import { Input } from '@/app/components/ui/input';
import { Label } from '@/app/components/ui/label';
import { Badge } from '@/app/components/ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/app/components/ui/select';
import { Textarea } from '@/app/components/ui/textarea';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/app/components/ui/dialog';
import { AlertDialog, AlertDialogContent, AlertDialogHeader, AlertDialogTitle, AlertDialogDescription, AlertDialogFooter, AlertDialogAction, AlertDialogCancel } from '@/app/components/ui/alert-dialog';
import { Search, Plus, Eye, Edit, Trash2, ChevronDown, ShieldAlert, AlertTriangle, AlertCircle, User } from 'lucide-react';
import { useData, Violation } from '../state/DataContext';
import { useAuth } from '../state/AuthContext';
import { formatShortDate } from '@/utils/dateFormatter';
import { request } from '@/services/api';
import ViolationGuide from './ViolationGuide';
import IncidentReportModal from './IncidentReportModal';

// SCH Violation Matrix — from official shelter guidelines
const SCH_VIOLATION_MATRIX = [
  // ══════════════════════════════════════════════════════
  // MAJOR OFFENSES
  // ══════════════════════════════════════════════════════
  {
    id: 'MJ01', category: 'Major', severity: 'Major' as const, points: 3,
    label: 'Pagtangkang Tumakas / Pagtakas (Escape Attempt)',
    tagalog: 'Pagpaplano at pagyayakag sa Pagtakas',
    intervention: 'No resistance: 1 meal HHC + Privilege suspension + Psychosocial activity + 3 days isolation\nWith resistance: 1 day household chores + Privilege suspension + Psychosocial activity + 3 days isolation\n1st Offense: Same as above\n2nd Offense: Blotter + Case filing + Guardian notification + Court notification',
    assessor: 'Psychologist',
  },
  {
    id: 'MJ02a', category: 'Major', severity: 'Major' as const, points: 3,
    label: 'Pagpasok ng Pera at Phone',
    tagalog: 'Pag gamit at pagpasok ng Pera at Phone',
    intervention: '1st Offense: 2 weeks Privilege Suspension + Psychosocial activity\n2nd Offense: 2 weeks Privilege Suspension + 2 days household chores + Psychosocial activity\n3rd Offense and succeeding: 2 weeks Privilege Suspension + 2 days household chores + Laundry of bedsheets & towels + Psychosocial activity',
    assessor: 'Social Worker',
  },
  {
    id: 'MJ02b', category: 'Major', severity: 'Major' as const, points: 3,
    label: 'Pagpasok ng Alak at Sigarilyo',
    tagalog: 'Pag gamit at pagpasok ng Alak at Sigarilyo',
    intervention: '1st Offense: 2 weeks Privilege Suspension + 1 day household chores + Psychosocial activity\n2nd Offense: 2 weeks Privilege Suspension + 3 days household chores + Psychosocial activity\n3rd Offense and succeeding: 2 weeks Privilege Suspension + 3 days household chores + Laundry of bedsheets & towels + Psychosocial activity',
    assessor: 'Nurse',
  },
  {
    id: 'MJ03', category: 'Major', severity: 'Critical' as const, points: 5,
    label: 'Paggamit ng Droga sa Shelter',
    tagalog: 'Pag gamit at pagpasok ng Droga sa shelter',
    intervention: 'Drug test + Blotter + Case filing (all offenses)',
    assessor: 'Nurse',
  },
  {
    id: 'MJ04', category: 'Major', severity: 'Major' as const, points: 3,
    label: 'Paggamit ng Tablet (Hindi Ayon sa Rules / Social Media)',
    tagalog: 'Pag gamit ng tablet na hindi naaayon; pag log in sa social media accounts',
    intervention: '1st Offense: 2 weeks Privilege Suspension + 2 weeks no tablet use + Psychosocial activities\n2nd Offense: 2 weeks Privilege Suspension + 2 days household chores + 3 weeks no use of tablet + Psychosocial activities\n3rd Offense and succeeding: 3 weeks Privilege Suspension + 3 days household chores + 1 month no use of tablet + Psychosocial activity',
    assessor: 'Social Worker',
  },
  {
    id: 'MJ05', category: 'Major', severity: 'Major' as const, points: 3,
    label: 'Pakikipag-away / Pananakit / Pakikipagsuntukan (Fighting)',
    tagalog: 'Halimbawa: sparring, pengkoy, pitikan, sapukan, pang-uulok na nagresulta sa away at iba pa',
    intervention: '1st Offense: 1 day household chores + Laundry of bedsheets and towels + 1 week privilege suspension + Psychosocial activity\n2nd Offense: 1 day isolation + 2 days household chores + 3 weeks privilege suspension + Psychosocial activity\n3rd Offense and succeeding: 2 days isolation + 2 weeks Privilege Suspension + 3 days household chores + Psychosocial activity\n(*Referral to psychologist or social worker; *Court filing and shoulder the medical expenses)',
    assessor: 'Psychologist',
  },
  {
    id: 'MJ06', category: 'Major', severity: 'Major' as const, points: 3,
    label: 'Pagsira ng Anumang Uri ng Gamit sa Shelter (Property Damage)',
    tagalog: 'Pagsira ng anumang uri ng gamit sa shelter',
    intervention: '1st Offense: Pagpalit/Pagbayad ng nasirang gamit & character building + counseling\nIf repeated: Privilege suspension\n2nd Offense: Pagpalit/Pagbayad ng nasirang gamit + 2 days isolation + privilege suspension + psychosocial activity\n3rd Offense and succeeding: Pagpalit/Pagbayad ng nasirang gamit + 1 week Privilege Suspension + psychosocial activity',
    assessor: 'Social Worker',
  },
  {
    id: 'MJ07', category: 'Major', severity: 'Critical' as const, points: 5,
    label: 'Pagbasag ng Salamin / Paggawa ng Sandata (Dangerous Object)',
    tagalog: 'Pagbasag ng salamin at pagputol ng toothbrush na maaring gamiting panaksak at panganib na matutulis na bagay sa loob ng shelter',
    intervention: '1st Offense: Pagpalit/Pagbayad ng nasirang gamit & 1 day isolation + privilege suspension + psychosocial activity\n2nd Offense: Pagpalit/Pagbayad ng nasirang gamit + 2 days isolation + privilege suspension + psychosocial activity\n3rd Offense and succeeding: Pagpalit/Pagbayad + 3 days isolation + 2 weeks Privilege Suspension + psychosocial activity\n(*Family will shoulder all the required treatment/medication)',
    assessor: 'Psychologist',
  },
  {
    id: 'MJ08', category: 'Major', severity: 'Major' as const, points: 3,
    label: 'Paglalagay ng Tattoo / Piercing / Bulitas',
    tagalog: 'Paglalagay ng tattoo at piercing o bulitas sa anumang bahagi ng katawan',
    intervention: '1st Offense: Laundry of Bedsheets and towels + psychosocial activity\n2nd Offense: Laundry of Bedsheets and towels + 1 week privilege suspension + psychosocial activity\n3rd Offense and succeeding: Laundry of Bedsheets and towels + 2 weeks Privilege suspension + psychosocial activity\n(*SCH will not be liable for the treatment/medication)',
    assessor: 'Nurse',
  },
  {
    id: 'MJ09a', category: 'Major', severity: 'Major' as const, points: 3,
    label: 'Pagkuha ng Supplies ng Shelter (Food/Kubyertos/Appliance)',
    tagalog: 'Pagkuha ng supplies ng shelter gaya ng pagkain, kubyertos, parte ng appliance (bullpen, pentelpen)',
    intervention: '1st Offense: 1 day household chores + Laundry of bedsheets and towels + psychosocial activity\n2nd Offense: 2 days household chores + Laundry of bedsheets and towels + psychosocial activity\n3rd Offense and succeeding: 3 days household chores + Laundry of bedsheets and towels + privilege suspension + psychosocial activity',
    assessor: 'Social Worker',
  },
  {
    id: 'MJ09b', category: 'Major', severity: 'Major' as const, points: 3,
    label: 'Pagkuha ng Gamit ng Kapwa Residente (Meryenda/Damit)',
    tagalog: 'Pagkuha ng kagamitan ng kapwa residente tulad ng meryenda, damit o ibang gamit',
    intervention: '1st Offense: 2 days household chores + Laundry of bedsheets and towels + psychosocial activity\n2nd Offense: 3 days household chores + Laundry of bedsheets and towels + psychosocial activity\n3rd Offense and succeeding: 4 days household + Laundry of bedsheets and towels + privilege suspension + psychosocial activity',
    assessor: 'Social Worker',
  },
  {
    id: 'MJ10', category: 'Major', severity: 'Major' as const, points: 3,
    label: 'Kawalang Respeto sa Kapwa Residente/Staff/Bisita (Pagmumura/Panlalait)',
    tagalog: 'Pagmumura, panlalait at pambabastos',
    intervention: '1st Offense: 1 day household chores + 1 week privilege suspension + character building + counseling\n2nd Offense: 2 days household chores + 2 weeks privilege suspension + character building + counseling\n3rd Offense and succeeding: 3 days household chores + 1 month privilege suspension + character building + counseling + 1 day isolation',
    assessor: 'Social Worker',
  },
  {
    id: 'MJ11', category: 'Major', severity: 'Critical' as const, points: 5,
    label: 'Sexually Deviant Behavior',
    tagalog: 'Pagmamasturbate in public, pagpapakita ng ari, pakikiapid, oral and anal contact',
    intervention: 'Subject for medical and/or psychological check-up / treatment\nSubject for case conference\nThe offended party might seek legal advice or take legal action against the offender.\n(*Referral to psychologist or social worker)',
    assessor: 'Psychologist',
  },
  {
    id: 'MJ12', category: 'Major', severity: 'Major' as const, points: 3,
    label: 'Pagtanggi na Pumirma at Gawin ang Intervention',
    tagalog: 'Pagtanggi na gumawa ng itinakdang intervention',
    intervention: '1st Offense: Verbal warning (still required to do the intervention) + psychosocial activity\n2nd Offense: 1 week no video call/visitation (still required to do the intervention)\n3rd Offense and succeeding: 2 weeks no video call/visitation (still required to do the intervention)',
    assessor: 'Social Worker',
  },
  // ══════════════════════════════════════════════════════
  // MINOR OFFENSES
  // ══════════════════════════════════════════════════════
  {
    id: 'MN01', category: 'Minor', severity: 'Minor' as const, points: 1,
    label: 'Pagsuwway sa Schedule at di Pagsali sa Activities',
    tagalog: 'Pagsuwway sa schedule ng mga activities tulad ng tutorials, exercise at psychosocial activities',
    intervention: '1st Offense: 2 days no watching tv (no involvement in music activity) + psychosocial activity\n2nd Offense: 4 days no watching tv (no involvement in music activity) + 3 mins video call/phone call + psychosocial activity\n3rd Offense and succeeding: 1 week privilege suspension + psychosocial activity',
    assessor: 'Social Worker',
  },
  {
    id: 'MN02', category: 'Minor', severity: 'Minor' as const, points: 1,
    label: 'Pagbubukas ng Appliances sa mga Kwarto (Walang Pahintulot)',
    tagalog: 'Pagpasok sa storage room at office walang pahintulot; pagpasok sa CR habang may tao',
    intervention: '1st Offense: 1 day CR cleaning (down) + psychosocial activity\n2nd Offense: 2 days CR cleaning (up and down) + psychosocial activity\n3rd Offense and succeeding: 3 days CR cleaning (up and down) + psychosocial activity',
    assessor: 'Social Worker',
  },
  {
    id: 'MN03', category: 'Minor', severity: 'Minor' as const, points: 1,
    label: 'Pagsusuot ng Anumang Uri ng Alahas/Palamuti',
    tagalog: 'Pagsusuot ng relo, kwintas, anklet, singsing, sombrero at iba pa',
    intervention: '1st Offense: Confiscate at ipapauwi sa magulang + psychosocial activity\n2nd Offense: Confiscate and safe keeping + psychosocial activity\n3rd Offense and succeeding: Confiscate and safe keeping + laundry of bedsheets and towels + psychosocial activity',
    assessor: 'Social Worker',
  },
  {
    id: 'MN04', category: 'Minor', severity: 'Minor' as const, points: 1,
    label: 'Paghingi ng Pansariling Interest sa Kapwa Residente / Pakikipagpalit ng Gamit',
    tagalog: 'Hindi ito pwedeng dalhan ng nagirang gamit',
    intervention: 'Pawiin sa pamilitan o in-arbor sa kapwa residente. (*Referral to psychologist or social worker)',
    assessor: 'Social Worker',
  },
  {
    id: 'MN05a', category: 'Minor', severity: 'Minor' as const, points: 1,
    label: 'Pag-iingay sa Oras ng Pag-aaral',
    tagalog: 'Pag-aaral',
    intervention: '1st Offense: 1 day no using of tablet during study time + psychosocial activity + 1 day household chores\n2nd Offense: 2 days no using of tablet during study time + psychosocial activity + 2 days household chores\n3rd Offense and succeeding: 3 days no using of tablet during study time + psychosocial activity + 3 days household chores',
    assessor: 'Social Worker',
  },
  {
    id: 'MN05b', category: 'Minor', severity: 'Minor' as const, points: 1,
    label: 'Pag-iingay sa Oras ng Panonood ng TV',
    tagalog: 'Panonood ng tv',
    intervention: '1st Offense: 1 day no watching tv (no involvement in music activity) + psychosocial activity\n2nd Offense: 2 days no watching tv (no involvement in music activity) + psychosocial activity\n3rd Offense and succeeding: 3 days no watching tv (no involvement in music activity) + privilege suspension + psychosocial activity',
    assessor: 'Social Worker',
  },
  {
    id: 'MN05c', category: 'Minor', severity: 'Minor' as const, points: 1,
    label: 'Pag-iingay sa Oras ng Pagtulog',
    tagalog: 'Pagtulog',
    intervention: '1st Offense: 1 day no nap time + psychosocial activity\n2nd Offense: 2 days no nap time + psychosocial activity\n3rd Offense and succeeding: 3 days no nap time + privilege suspension + psychosocial activity',
    assessor: 'Social Worker',
  },
  {
    id: 'MN06', category: 'Minor', severity: 'Minor' as const, points: 1,
    label: 'Pagtago ng Pagkain sa Kwarto',
    tagalog: 'Pagtago ng pagkain sa kwarto',
    intervention: '1st Offense: No merienda sa susunod na araw at huling kakain\n2nd Offense: 1 week no merienda + privilege suspension\n3rd Offense and succeeding: 1 month privilege suspension during last Wednesday',
    assessor: 'Social Worker',
  },
  {
    id: 'MN07', category: 'Minor', severity: 'Minor' as const, points: 1,
    label: 'Late Gumising / Pagligo ng Sabay at Pagligo ng Wala sa Oras',
    tagalog: 'Late gumising, pagligo ng sabay o wala sa oras',
    intervention: 'Huling kalain at 1 day household chores',
    assessor: 'Social Worker',
  },
  {
    id: 'MN08', category: 'Minor', severity: 'Minor' as const, points: 1,
    label: 'Hindi Pagkain sa Takdang Oras (not unless sick)',
    tagalog: 'Hindi pagkain sa takdang oras maliban sa sakit',
    intervention: 'Ipakainin ang kanyang pagkain sa mga kapwa residente',
    assessor: 'Social Worker',
  },
  {
    id: 'MN09', category: 'Minor', severity: 'Minor' as const, points: 1,
    label: 'Kawalang Respeto sa Hapag-Kainan',
    tagalog: 'Pag-aayos ng hapag-kainan, paglalaro habang nag-aalmusal, pag-aaksa sa Pagkatapon ng Pagkain',
    intervention: '1st Offense: Half rice and half ulam on a current meal and on the following meals, huling kakain at cleaning of dining area\n2nd Offense: Half rice and half ulam on the following meals, huling kakain at cleaning of dining area\n3rd Offense and succeeding: Half rice and half ulam on the following meals, huling kakain at 2days household chores',
    assessor: 'Social Worker',
  },
  {
    id: 'MN10', category: 'Minor', severity: 'Minor' as const, points: 1,
    label: 'Vandalism',
    tagalog: 'Pagsulat/pagkuha ng mga sulat sa pader at pagbili ng 1 litro ng puting pintura',
    intervention: 'Pagsulat/pagkuha ng mga sulat sa pader at pagbili ng 1 Litro ng puting pintura',
    assessor: 'Social Worker',
  },
  {
    id: 'MN11', category: 'Minor', severity: 'Minor' as const, points: 1,
    label: 'Paglalagi sa Baba ng Hindi Naman Toka sa Paglalaba / Hindi Naman Oras ng Panonood',
    tagalog: 'Paglalagi sa viewing area ng hindi naman oras ng panonood',
    intervention: '1st Offense: Verbal warning + dialogue\n2nd Offense: 1 day cleaning of receiving area + psychosocial activity\n3rd Offense and succeeding: 3 days cleaning of receiving area + psychosocial activity',
    assessor: 'Social Worker',
  },
  {
    id: 'MN12', category: 'Minor', severity: 'Minor' as const, points: 1,
    label: 'Walang Pantaas na Damit / Pag Hubo at Nakaboxer Shorts (except nap time or bed time at washing dishes)',
    tagalog: 'Maliban sa nap time, bed time at washing dishes at laundry area',
    intervention: '1st Offense: Verbal warning + dialogue\n2nd Offense: 1 day cleaning of laundry area + psychosocial activity\n3rd Offense and succeeding: 3 days cleaning of laundry area + psychosocial activity',
    assessor: 'Social Worker',
  },
  {
    id: 'MN13', category: 'Minor', severity: 'Minor' as const, points: 1,
    label: 'Hindi Pag-ayos ng Higaan / Pagsalansan ng mga Gamit sa Kusina',
    tagalog: 'Hindi pag-ayos ng higaan o pagsalansan ng gamit sa kusina pagkatapos ng nap time or bed time (not unless sick)',
    intervention: '1st Offense: Pagsasamom ng unan\n2nd Offense: Pagsasamom ng kutson\n3rd Offense and succeeding: Pagsasamom ng unan at kutson',
    assessor: 'Social Worker',
  },
  {
    id: 'MN14', category: 'Minor', severity: 'Minor' as const, points: 1,
    label: 'Pagsabit ng Kung Anu-ano sa Bintana ng Bawat Room',
    tagalog: 'Pagsabit ng kung anu-ano sa bintana ng bawat room',
    intervention: 'Pagsasamom ng nagpapauwi kung anumang gamit na nakasabit',
    assessor: 'Social Worker',
  },
  {
    id: 'MN15', category: 'Minor', severity: 'Minor' as const, points: 1,
    label: 'Pagsilip at Pakikipag-usap sa Kapwa Residente sa Ibang Silid',
    tagalog: 'Pagsilip at pakikipag-usap sa kapwa residente sa ibang silid',
    intervention: '1st Offense: No phone call / video call\n2nd Offense: Psychosocial activity\n3rd Offense and succeeding: Pagsasamom ng unan at kutson',
    assessor: 'Social Worker',
  },
];

const SEVERITY_OPTIONS = [
  { value: 'Minor', label: 'Minor (1 point)', points: 1 },
  { value: 'Major', label: 'Major (3 points)', points: 3 },
  { value: 'Critical', label: 'Critical (5 points)', points: 5 },
];

// ── Violation matrix item type ──────────────────────────────────────────────
interface ViolationItem {
  id: string;
  category: 'Major' | 'Minor';
  severity: 'Minor' | 'Major' | 'Critical';
  points: number;
  label: string;
  tagalog?: string;
  intervention?: string;
  assessor?: string;
  assessmentType?: string;
}

const MANAGE_KEY = 'sch_custom_violation_matrix';
const getActiveMatrix = (): ViolationItem[] => {
  try {
    const saved = localStorage.getItem(MANAGE_KEY);
    if (saved) return JSON.parse(saved) as ViolationItem[];
  } catch {}
  return SCH_VIOLATION_MATRIX as ViolationItem[];
};
const persistMatrix = (m: ViolationItem[]) => {
  try { localStorage.setItem(MANAGE_KEY, JSON.stringify(m)); } catch {}
};

const guideToViolationMatrix = (guides: any[] = []): ViolationItem[] =>
  guides
    .filter((guide) => guide && guide.name && guide.status !== 'Inactive')
    .map((guide, index) => {
      const rawInterventions = Array.isArray(guide.interventions)
        ? guide.interventions
        : Object.values(guide.interventions || {}).flat();

      const interventionText = rawInterventions
        .map((item: any) => {
          const type = item?.interventionType || item?.type || '';
          const customText = item?.metadata?.customType || item?.customType || item?.metadata?.officialText || null;
          if (type === 'Other' && customText) return customText;
          return type;
        })
        .filter(Boolean)
        .join('; ');

      return {
        id: guide.id || `guide-${index}`,
        category: guide.category === 'Major' ? 'Major' : 'Minor',
        severity: guide.category === 'Major' ? 'Major' : 'Minor',
        points: guide.category === 'Major' ? 3 : 1,
        label: guide.name,
        tagalog: guide.description || '',
        intervention: interventionText,
        assessor: 'Social Worker',
        assessmentType: 'Behavioral Assessment',
      };
    });

export function Violations() {
  const navigate = useNavigate();
  const { children, staff, violations, addViolation, updateViolation, deleteViolation, refreshData, addAssessment } = useData();
  const { user } = useAuth();
  const isSocialWorker = ['socialworker', 'centerhead', 'admin'].includes(user?.role?.toLowerCase() || '');
  const isPsychologist = user?.role === 'psychologist';
  const isCenterHead = user?.role === 'centerhead';

  const [searchTerm, setSearchTerm] = useState('');
  const [filterStatus, setFilterStatus] = useState('all');
  const [filterSeverity, setFilterSeverity] = useState('all');

  const [isAddDialogOpen, setIsAddDialogOpen] = useState(false);
  const [isIncidentReportOpen, setIsIncidentReportOpen] = useState(false);
  const [incidentReportMode, setIncidentReportMode] = useState<'create' | 'view'>('create');
  const [activeIncidentViolationId, setActiveIncidentViolationId] = useState<string | null>(null);
  const [activeIncidentResidentId, setActiveIncidentResidentId] = useState<string>('');
  const [creatingIncident, setCreatingIncident] = useState(false);
  const [isViewDialogOpen, setIsViewDialogOpen] = useState(false);
  const [isEditDialogOpen, setIsEditDialogOpen] = useState(false);
  const [isDeleteDialogOpen, setIsDeleteDialogOpen] = useState(false);
  const [isReviewDialogOpen, setIsReviewDialogOpen] = useState(false);

  const [selectedViolation, setSelectedViolation] = useState<Violation | null>(null);
  const [violationToDelete, setViolationToDelete] = useState<Violation | null>(null);


  const [reviewForm, setReviewForm] = useState({ severity: 'Minor' as 'Minor' | 'Major' | 'Critical', actionTaken: '', status: 'Reviewed' as string });

  const staffNames = staff.filter(s => s.status === 'Active').map(s => s.name);

  const defaultReportedBy = user?.username || '';

  const [formData, setFormData] = useState({
    residentId: '',
    date: new Date().toISOString().split('T')[0],
    type: '',
    description: '',
    severity: 'Minor' as 'Minor' | 'Major' | 'Critical',
    points: 1,
    location: '',
    witnesses: '',
    reportedBy: defaultReportedBy,
    actionTaken: '',
    status: 'Pending Review' as 'Pending Review' | 'Under Investigation' | 'Reviewed' | 'Resolved' | 'Escalated',
    offenseNumber: '1st Offense' as '1st Offense' | '2nd Offense' | '3rd Offense' | '4th Offense+',
    interventionStartDate: new Date().toISOString().split('T')[0],
    interventionMonth: new Date().toISOString().substring(0, 7),
  });
  const [showClearConfirm, setShowClearConfirm] = useState(false);
  const [clearingMonth, setClearingMonth] = useState(new Date().toISOString().substring(0, 7));
  const [activeTab, setActiveTab] = useState<'list' | 'verification' | 'performance' | 'manage'>('list');

  // Violation matrix management (Center Head only)
  const [activeMatrix, setActiveMatrix] = useState<ViolationItem[]>(getActiveMatrix);
  const [isViolationDialogOpen, setIsViolationDialogOpen] = useState(false);
  const [editingViolation, setEditingViolation] = useState<ViolationItem | null>(null);
  const [guideMatrixReady, setGuideMatrixReady] = useState(false);
  const emptyVForm = { label: '', category: 'Major' as const, severity: 'Major' as const, points: 3, intervention: '', assessor: 'Social Worker', assessmentType: 'Behavioral Assessment', tagalog: '' };
  const [violationForm, setViolationForm] = useState(emptyVForm);
  const [deleteViolationId, setDeleteViolationId] = useState<string | null>(null);
  const [actionMenuOpen, setActionMenuOpen] = useState<string | null>(null); // violation id with open menu
  const [manageMenuOpen, setManageMenuOpen] = useState<string | null>(null); // manage tab action menu
  const [viewManageViolation, setViewManageViolation] = useState<ViolationItem | null>(null);

  const loadGuideMatrix = async () => {
    try {
      const response = await request('/violation-guide', { method: 'GET' });
      if (response?.success) {
        const mapped = guideToViolationMatrix(response.data || []);
        setActiveMatrix(mapped);
        setGuideMatrixReady(true);
        return;
      }
    } catch (error) {
      console.warn('Falling back to local violation matrix:', error);
    }

    if (!guideMatrixReady) {
      setActiveMatrix(getActiveMatrix());
      setGuideMatrixReady(true);
    }
  };

  useEffect(() => {
    loadGuideMatrix();
  }, []);

  const saveMatrix = (m: ViolationItem[]) => {
    persistMatrix(m);
    setActiveMatrix(m);
  };

  const handleSaveViolation = () => {
    if (!violationForm.label.trim()) return;
    const updated = editingViolation
      ? activeMatrix.map(v => v.id === editingViolation.id ? { ...v, ...violationForm } : v)
      : [...activeMatrix, { id: 'CU' + Date.now(), ...violationForm }];
    saveMatrix(updated);
    setIsViolationDialogOpen(false);
    setEditingViolation(null);
    setViolationForm(emptyVForm);
  };

  const handleDeleteViolation = (id: string) => {
    saveMatrix(activeMatrix.filter(v => v.id !== id));
    setDeleteViolationId(null);
  };

  const openEditViolation = (v: ViolationItem) => {
    setEditingViolation(v);
    setViolationForm({
      label: v.label, category: v.category, severity: v.severity,
      points: v.points, intervention: v.intervention || '',
      assessor: v.assessor || 'Social Worker',
      assessmentType: v.assessmentType || 'Behavioral Assessment',
      tagalog: v.tagalog || '',
    });
    setIsViolationDialogOpen(true);
  };

  const filteredViolations = violations.filter((v) => {
    const resident = children.find((c) => c.id === v.residentId);
    const residentName = resident?.name || '';
    const matchesSearch = 
      residentName.toLowerCase().includes(searchTerm.toLowerCase()) ||
      (v.type || '').toLowerCase().includes(searchTerm.toLowerCase()) ||
      v.id.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesStatus = filterStatus === 'all' || v.status === filterStatus;
    const matchesSeverity = filterSeverity === 'all' || v.severity === filterSeverity;
    return matchesSearch && matchesStatus && matchesSeverity;
  });

  // Incident Reports submitted via Log Incident are created with status 'Pending Review'
  // and stay there until the Psychologist verifies them — this is the single source of
  // truth shared by both the "For Verification" card and its tab, so they can never drift.
  const forVerificationList = violations.filter((v) => v.status === 'Pending Review');

  const handleSeverityChange = (severity: 'Minor' | 'Major' | 'Critical') => {
    const points = SEVERITY_OPTIONS.find((s) => s.value === severity)?.points || 1;
    setFormData((prev) => ({ ...prev, severity, points }));
  };

  const resetForm = () => {
    setFormData({
      residentId: '',
      date: new Date().toISOString().split('T')[0],
      type: '',
      description: '',
      severity: 'Minor',
      points: 1,
      location: '',
      witnesses: '',
      reportedBy: user?.username || '',
      actionTaken: '',
      status: 'Pending Review',
      offenseNumber: '1st Offense',
      interventionStartDate: new Date().toISOString().split('T')[0],
      interventionMonth: new Date().toISOString().substring(0, 7),
    });
  };

  // Auto-determine offense number for a resident based on their violation history
  const getAutoOffenseNumber = (residentId: string): '1st Offense' | '2nd Offense' | '3rd Offense' | '4th Offense+' => {
    // Count same violation type occurrences for this resident
    const sameType = formData.type
      ? violations.filter(v => v.residentId === residentId && v.type === formData.type).length
      : violations.filter(v => v.residentId === residentId).length;
    if (sameType === 0) return '1st Offense';
    if (sameType === 1) return '2nd Offense';
    if (sameType === 2) return '3rd Offense';
    return '4th Offense+';
  };

  // Clear interventions for a month (Social Worker only)
  const handleClearMonth = async () => {
    const toResolve = violations.filter(v => {
      const vm = ((v as any).interventionMonth || v.date?.substring(0, 7) || '');
      return vm === clearingMonth && v.status !== 'Resolved';
    });
    for (const v of toResolve) {
      await updateViolation(v.id, {
        status: 'Resolved',
        points: 0,  // Clear points for the month
        clearedBy: user?.username || 'Social Worker',
        clearedAt: new Date().toISOString(),
      } as any);
    }
    setShowClearConfirm(false);
    alert("Cleared " + toResolve.length + " intervention(s) and reset points for " + clearingMonth + ".");
  };

  const handleSubmit = async () => {
    if (!formData.residentId || !formData.type) return;
    const payload = {
      ...formData,
      reportedBy: formData.reportedBy,
      witnesses: formData.witnesses,
      status: 'Pending Review' as const,
    };
    const result = await addViolation(payload);
    setIsAddDialogOpen(false);
    if (result) {
      setTimeout(() => refreshData(), 500);
    }
    resetForm();
  };

  // Creates the underlying violation record (resident + date + type only), then
  // opens the digital Incident Report form for the Social Worker to fill out.
  const handleOpenIncidentReport = async () => {
    if (!formData.residentId || !formData.type) return;
    setCreatingIncident(true);
    try {
      const result = await addViolation({
        residentId: formData.residentId,
        date: formData.date,
        type: formData.type,
        severity: formData.severity,
        points: formData.points,
        status: 'Pending Review',
      } as any);
      if (result?.id) {
        setActiveIncidentViolationId(result.id);
        setActiveIncidentResidentId(formData.residentId);
        setIncidentReportMode('create');
        setIsAddDialogOpen(false);
        setIsIncidentReportOpen(true);
      }
    } finally {
      setCreatingIncident(false);
    }
  };

  // Opens the digital Incident Report (read-only, with Verify for Psychologist/Center Head)
  // for an existing violation record.
  const openIncidentReportView = (violation: Violation) => {
    setActiveIncidentViolationId(violation.id);
    setActiveIncidentResidentId(violation.residentId);
    setIncidentReportMode('view');
    setIsIncidentReportOpen(true);
  };

  const handleReview = async () => {
    if (!selectedViolation) return;
    try {
      await request(`/violations/${selectedViolation.id}/review`, {
        method: 'POST',
        body: JSON.stringify(reviewForm),
      });
      setIsReviewDialogOpen(false);
      setSelectedViolation(null);
      setTimeout(() => refreshData(), 300);
    } catch { /* ignore */ }
  };

  const handleUpdate = async () => {
    if (!selectedViolation) return;
    await updateViolation(selectedViolation.id, formData);
    setIsEditDialogOpen(false);
    setSelectedViolation(null);
  };

  const handleDelete = async () => {
    if (!violationToDelete) return;
    await deleteViolation(violationToDelete.id);
    setIsDeleteDialogOpen(false);
    setViolationToDelete(null);
  };

  const openViewDialog = (violation: Violation) => {
    setSelectedViolation(violation);
    setIsViewDialogOpen(true);
  };

  const openEditDialog = (violation: Violation) => {
    setSelectedViolation(violation);
    setFormData({
      residentId: violation.residentId,
      date: violation.date,
      type: violation.type,
      description: violation.description || '',
      severity: violation.severity,
      points: violation.points,
      location: violation.location || '',
      witnesses: violation.witnesses || '',
      reportedBy: violation.reportedBy || '',
      actionTaken: violation.actionTaken || '',
      status: violation.status,
    });
    setIsEditDialogOpen(true);
  };

  const openDeleteDialog = (violation: Violation) => {
    setViolationToDelete(violation);
    setIsDeleteDialogOpen(true);
  };

  const getSeverityColor = (severity: string) => {
    switch (severity) {
      case 'Critical': return 'bg-red-100 text-red-800 border-red-200';
      case 'Major': return 'bg-orange-100 text-orange-800 border-orange-200';
      default: return 'bg-yellow-100 text-yellow-800 border-yellow-200';
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'Resolved': return 'bg-green-100 text-green-800';
      case 'Reviewed': return 'bg-purple-100 text-purple-800';
      case 'Under Investigation': return 'bg-blue-100 text-blue-800';
      case 'Escalated': return 'bg-red-100 text-red-800';
      case 'Pending Review': return 'bg-yellow-100 text-yellow-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const getViolationPointsForResident = (residentId: string) => {
    return violations
      .filter((v) => v.residentId === residentId && v.status !== 'Resolved')
      .reduce((sum, v) => sum + v.points, 0);
  };



  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h2 className="text-2xl font-semibold text-[#2F3E46]">Incident Records</h2>
          <p className="text-gray-600">Track resident infractions and behavioral incidents</p>
        </div>
        <Button className="flex items-center gap-2 bg-[#2F3E46]" onClick={() => setIsAddDialogOpen(true)}>
          <Plus className="w-4 h-4" />
          <span>Log Incident</span>
        </Button>
      </div>

      {/* Summary Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-4 gap-4">
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center gap-3">
              <ShieldAlert className="w-8 h-8 text-red-500" />
              <div>
                <p className="text-sm text-gray-500">Total Violations</p>
                <p className="text-2xl font-bold">{violations.length}</p>
              </div>
            </div>
          </CardContent>
        </Card>
        <Card className="cursor-pointer hover:shadow-md transition-shadow" onClick={() => setActiveTab('verification')}>
          <CardContent className="p-4">
            <div className="flex items-center gap-3">
              <AlertTriangle className="w-8 h-8 text-orange-500" />
              <div>
                <p className="text-sm text-gray-500">For Verification</p>
                <p className="text-2xl font-bold">{forVerificationList.length}</p>
              </div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center gap-3">
              <AlertCircle className="w-8 h-8 text-yellow-500" />
              <div>
                <p className="text-sm text-gray-500">Under Investigation</p>
                <p className="text-2xl font-bold">{violations.filter((v) => v.status === 'Under Investigation').length}</p>
              </div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center gap-3">
              <User className="w-8 h-8 text-blue-500" />
              <div>
                <p className="text-sm text-gray-500">Residents with Violations</p>
                <p className="text-2xl font-bold">{new Set(violations.map((v) => v.residentId)).size}</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Filters */}
      <Card>
        <CardContent className="p-4">
          <div className="flex flex-col sm:flex-row gap-4">
            <div className="flex-1 relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-gray-400" />
              <Input
                placeholder="Search by resident name or violation type..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10"
              />
            </div>
            <Select value={filterStatus} onValueChange={setFilterStatus}>
              <SelectTrigger className="w-full sm:w-48">
                <SelectValue placeholder="Filter by status" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Status</SelectItem>
                <SelectItem value="Pending Review">Pending Review</SelectItem>
                <SelectItem value="Under Investigation">Under Investigation</SelectItem>
                <SelectItem value="Reviewed">Reviewed</SelectItem>
                <SelectItem value="Resolved">Resolved</SelectItem>
                <SelectItem value="Escalated">Escalated</SelectItem>
              </SelectContent>
            </Select>
            <Select value={filterSeverity} onValueChange={setFilterSeverity}>
              <SelectTrigger className="w-full sm:w-48">
                <SelectValue placeholder="Filter by severity" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Severity</SelectItem>
                <SelectItem value="Minor">Minor</SelectItem>
                <SelectItem value="Major">Major</SelectItem>
                <SelectItem value="Critical">Critical</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </CardContent>
      </Card>

      {/* Tabs: List | Overall Performance */}
      <div className="flex items-center gap-1 border-b border-gray-200 mb-4">
        {([
          { key: 'list', label: 'Violation List' },
          { key: 'verification', label: 'For Verification' },
          { key: 'performance', label: 'Overall Performance' },
          ...(isCenterHead ? [{ key: 'manage', label: 'Manage Violations & Interventions' }] : []),
        ] as const).map(t => (
          <button key={t.key} onClick={() => setActiveTab(t.key)}
            className={`px-4 py-2.5 text-sm font-semibold border-b-2 -mb-px transition-all ${
              activeTab === t.key ? 'border-[#FFD100] text-[#2F3E46]' : 'border-transparent text-gray-400 hover:text-gray-600'
            }`}>
            {t.label}
          </button>
        ))}
        {isSocialWorker && (
          <div className="ml-auto flex items-center gap-2 pb-1">
            <input type="month" value={clearingMonth} onChange={e => setClearingMonth(e.target.value)}
              className="text-xs border border-gray-200 rounded-lg px-2 py-1 focus:outline-none focus:ring-2 focus:ring-[#FFD100]" />
            <Button size="sm" variant="outline" className="text-xs h-7 border-red-300 text-red-600 hover:bg-red-50"
              onClick={() => setShowClearConfirm(true)}>
              Reset Month
            </Button>
          </div>
        )}
      </div>

      {/* Overall Performance Tab */}
      {activeTab === 'performance' && (
        <Card className="border-none shadow-sm">
          <CardHeader className="pb-2 border-b border-gray-100">
            <CardTitle className="text-sm font-bold text-[#2F3E46]">Overall Resident Performance — Violation & Intervention Monitoring</CardTitle>
          </CardHeader>
          <CardContent className="pt-3 overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b border-gray-100 text-xs text-gray-500 uppercase">
                  <th className="text-left pb-2 pr-4">Resident</th>
                  <th className="text-left pb-2 pr-4">Total</th>
                  <th className="text-left pb-2 pr-4">Active</th>
                  <th className="text-left pb-2 pr-4">Resolved</th>
                  <th className="text-left pb-2 pr-4">Highest Offense</th>
                  <th className="text-left pb-2 pr-4">Points</th>
                  <th className="text-left pb-2">Performance</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-50">
                {children.filter(c => c.status !== 'Discharged').map(child => {
                  const cv = violations.filter(v => v.residentId === child.id);
                  const active = cv.filter(v => v.status !== 'Resolved');
                  const resolved = cv.filter(v => v.status === 'Resolved');
                  const pts = active.reduce((s, v) => s + (v.points || 0), 0);
                  const offenses = cv.map(v => (v as any).offenseNumber).filter(Boolean);
                  const highestOffense =
                    offenses.includes('4th Offense+') ? '4th Offense+' :
                    offenses.includes('3rd Offense')  ? '3rd Offense'  :
                    offenses.includes('2nd Offense')  ? '2nd Offense'  :
                    offenses.includes('1st Offense')  ? '1st Offense'  : '—';
                  const perf =
                    pts >= 10 ? { label: 'Critical',  color: 'bg-red-100 text-red-700'       } :
                    pts >= 6  ? { label: 'Severe',    color: 'bg-orange-100 text-orange-700'  } :
                    pts >= 3  ? { label: 'Moderate',  color: 'bg-yellow-100 text-yellow-700'  } :
                                { label: 'Good',      color: 'bg-green-100 text-green-700'    };
                  return (
                    <tr key={child.id} className="hover:bg-gray-50 text-xs">
                      <td className="py-2.5 pr-4 font-semibold text-[#2F3E46]">{child.name}</td>
                      <td className="py-2.5 pr-4">{cv.length}</td>
                      <td className="py-2.5 pr-4 text-orange-600 font-bold">{active.length}</td>
                      <td className="py-2.5 pr-4 text-green-600">{resolved.length}</td>
                      <td className="py-2.5 pr-4">
                        <span className={`px-2 py-0.5 rounded-full font-bold text-[10px] ${
                          highestOffense === '4th Offense+' ? 'bg-red-100 text-red-700' :
                          highestOffense === '3rd Offense'  ? 'bg-orange-100 text-orange-700' :
                          highestOffense === '2nd Offense'  ? 'bg-yellow-100 text-yellow-700' :
                          highestOffense === '1st Offense'  ? 'bg-blue-100 text-blue-700' :
                          'bg-gray-100 text-gray-500'
                        }`}>{highestOffense}</span>
                      </td>
                      <td className="py-2.5 pr-4 font-bold">{pts}</td>
                      <td className="py-2.5">
                        <span className={`px-2 py-0.5 rounded-full font-bold text-[10px] ${perf.color}`}>{perf.label}</span>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </CardContent>
        </Card>
      )}

      {/* ── MANAGE VIOLATIONS TAB — Center Head only ── */}
      {activeTab === 'manage' && isCenterHead && (
        <div onClick={() => setManageMenuOpen(null)}>
          <ViolationGuide />
        </div>
      )}
      {/* Violation List Tab — Table Format */}
      {activeTab === 'list' && (
        <div onClick={() => setActionMenuOpen(null)}>
          <Card className="border border-gray-200 shadow-sm overflow-hidden">
            {filteredViolations.length === 0 ? (
              <CardContent className="p-12 text-center">
                <ShieldAlert className="w-12 h-12 mx-auto mb-4 text-gray-300" />
                <p className="text-gray-500">No violations found matching your criteria.</p>
              </CardContent>
            ) : (
              <div className="overflow-x-auto">
                <table className="w-full text-sm">
                  <thead>
                    <tr className="bg-gray-50 border-b border-gray-200">
                      <th className="px-4 py-3 text-left text-xs font-bold text-gray-500 uppercase tracking-wide w-10">#</th>
                      <th className="px-4 py-3 text-left text-xs font-bold text-gray-500 uppercase tracking-wide">Resident</th>
                      <th className="px-4 py-3 text-left text-xs font-bold text-gray-500 uppercase tracking-wide">Violation Type</th>
                      <th className="px-4 py-3 text-left text-xs font-bold text-gray-500 uppercase tracking-wide w-24">Severity</th>
                      <th className="px-4 py-3 text-left text-xs font-bold text-gray-500 uppercase tracking-wide w-16">Points</th>
                      <th className="px-4 py-3 text-left text-xs font-bold text-gray-500 uppercase tracking-wide w-24">Date</th>
                      <th className="px-4 py-3 text-left text-xs font-bold text-gray-500 uppercase tracking-wide w-24">Status</th>
                      <th className="px-4 py-3 text-left text-xs font-bold text-gray-500 uppercase tracking-wide w-28">Action</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-gray-100">
                    {filteredViolations.map((violation, idx) => {
                      const resident = children.find(c => c.id === violation.residentId);
                      const menuKey = violation.id || String(idx);
                      const isMenuOpen = actionMenuOpen === menuKey;
                      const canManage = isCenterHead || isSocialWorker;
                      return (
                        <tr key={violation.id} className={idx % 2 === 0 ? 'bg-white hover:bg-gray-50' : 'bg-gray-50 hover:bg-gray-100'}>
                          <td className="px-4 py-3 text-gray-400 text-xs">{idx + 1}</td>
                          <td className="px-4 py-3">
                            <p className="font-semibold text-[#2F3E46] text-xs">{resident?.name || '—'}</p>
                            {(violation as any).offenseNumber && (
                              <span className="text-[10px] text-gray-400">{(violation as any).offenseNumber}</span>
                            )}
                            {(violation as any).assessmentTriggered && (
                              <span className={`block text-[10px] font-semibold mt-0.5 ${
                                (violation as any).assessmentCompleted ? 'text-green-600' : 'text-amber-600'
                              }`}>
                                {(violation as any).assessmentCompleted ? '✓ Assessment done' : 'Assessment pending'}
                              </span>
                            )}
                          </td>
                          <td className="px-4 py-3">
                            <p className="text-xs text-[#2F3E46] font-medium leading-tight">{violation.type}</p>
                          </td>
                          <td className="px-4 py-3">
                            <span className={`inline-flex px-2 py-0.5 rounded-full text-[10px] font-bold ${
                              violation.severity === 'Critical' ? 'bg-red-100 text-red-700' :
                              violation.severity === 'Major'    ? 'bg-orange-100 text-orange-700' :
                                                                  'bg-yellow-100 text-yellow-700'
                            }`}>{violation.severity}</span>
                          </td>
                          <td className="px-4 py-3 text-xs font-bold text-[#2F3E46] text-center">{violation.points}</td>
                          <td className="px-4 py-3 text-xs text-gray-500">{formatShortDate(violation.date)}</td>
                          <td className="px-4 py-3">
                            <button
                              type="button"
                              onClick={(e) => { e.stopPropagation(); openIncidentReportView(violation); }}
                              className={`inline-flex px-2 py-0.5 rounded-full text-[10px] font-bold cursor-pointer hover:opacity-75 transition-opacity ${
                                violation.status === 'Resolved'  ? 'bg-green-100 text-green-700' :
                                violation.status === 'Reviewed'  ? 'bg-blue-100 text-blue-700'   :
                                violation.status === 'Escalated' ? 'bg-red-100 text-red-700'     :
                                                                   'bg-amber-100 text-amber-700'
                              }`}
                              title="View Incident Report"
                            >
                              {violation.status === 'Pending Review' ? 'Active' : violation.status}
                            </button>
                          </td>
                          <td className="px-4 py-3">
                            <div className="relative" onClick={e => e.stopPropagation()}>
                              <button
                                onClick={() => setActionMenuOpen(isMenuOpen ? null : (violation.id || String(idx)))}
                                className="flex items-center gap-1 px-3 py-1.5 text-xs font-semibold text-[#2F3E46] border border-gray-300 rounded-lg hover:bg-gray-100 transition-all"
                              >
                                Action <ChevronDown className="w-3 h-3" />
                              </button>
                              {isMenuOpen && (
                                <div className="absolute right-0 top-8 z-50 bg-white border border-gray-200 rounded-xl shadow-lg py-1 w-36">
                                  <button
                                    onClick={() => { openViewDialog(violation); setActionMenuOpen(null); }}
                                    className="w-full flex items-center gap-2 px-3 py-2 text-xs hover:bg-gray-50 text-[#2F3E46]"
                                  >
                                    <Eye className="w-3.5 h-3.5" /> View
                                  </button>
                                  {canManage && (
                                    <>
                                      <button
                                        onClick={() => { openEditDialog(violation); setActionMenuOpen(null); }}
                                        className="w-full flex items-center gap-2 px-3 py-2 text-xs hover:bg-gray-50 text-blue-600"
                                      >
                                        <Edit className="w-3.5 h-3.5" /> Edit
                                      </button>
                                      <button
                                        onClick={() => { openDeleteDialog(violation); setActionMenuOpen(null); }}
                                        className="w-full flex items-center gap-2 px-3 py-2 text-xs hover:bg-red-50 text-red-600"
                                      >
                                        <Trash2 className="w-3.5 h-3.5" /> Delete
                                      </button>
                                    </>
                                  )}
                                </div>
                              )}
                            </div>
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            )}
            <div className="px-4 py-2 bg-gray-50 border-t border-gray-200">
              <p className="text-xs text-gray-400">Showing 1 to {filteredViolations.length} of {filteredViolations.length} entries</p>
            </div>
          </Card>
        </div>
      )}

      {/* For Verification Tab — Incident Reports awaiting Psychologist verification */}
      {activeTab === 'verification' && (
        <div>
          <Card className="border border-gray-200 shadow-sm overflow-hidden">
            {forVerificationList.length === 0 ? (
              <CardContent className="p-12 text-center">
                <AlertTriangle className="w-12 h-12 mx-auto mb-4 text-gray-300" />
                <p className="text-gray-500">No incident reports awaiting verification.</p>
              </CardContent>
            ) : (
              <div className="overflow-x-auto">
                <table className="w-full text-sm">
                  <thead>
                    <tr className="bg-gray-50 border-b border-gray-200">
                      <th className="px-4 py-3 text-left text-xs font-bold text-gray-500 uppercase tracking-wide w-10">#</th>
                      <th className="px-4 py-3 text-left text-xs font-bold text-gray-500 uppercase tracking-wide">Resident</th>
                      <th className="px-4 py-3 text-left text-xs font-bold text-gray-500 uppercase tracking-wide">Incident Type</th>
                      <th className="px-4 py-3 text-left text-xs font-bold text-gray-500 uppercase tracking-wide w-24">Date</th>
                      <th className="px-4 py-3 text-left text-xs font-bold text-gray-500 uppercase tracking-wide w-40">Action</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-gray-100">
                    {forVerificationList.map((violation, idx) => {
                      const resident = children.find(c => c.id === violation.residentId);
                      return (
                        <tr key={violation.id} className={idx % 2 === 0 ? 'bg-white hover:bg-gray-50' : 'bg-gray-50 hover:bg-gray-100'}>
                          <td className="px-4 py-3 text-gray-400 text-xs">{idx + 1}</td>
                          <td className="px-4 py-3">
                            <p className="font-semibold text-[#2F3E46] text-xs">{resident?.name || '—'}</p>
                          </td>
                          <td className="px-4 py-3">
                            <p className="text-xs text-[#2F3E46] font-medium leading-tight">{violation.type}</p>
                          </td>
                          <td className="px-4 py-3 text-xs text-gray-500">{formatShortDate(violation.date)}</td>
                          <td className="px-4 py-3">
                            <Button
                              size="sm"
                              onClick={() => openIncidentReportView(violation)}
                              className="bg-purple-600 hover:bg-purple-700 text-white text-xs h-7"
                            >
                              {isPsychologist || isCenterHead ? 'Review & Verify' : 'View Report'}
                            </Button>
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            )}
            <div className="px-4 py-2 bg-gray-50 border-t border-gray-200">
              <p className="text-xs text-gray-400">Showing {forVerificationList.length} incident report{forVerificationList.length !== 1 ? 's' : ''} awaiting verification</p>
            </div>
          </Card>
        </div>
      )}

      {/* Add Incident Dialog */}
      <Dialog open={isAddDialogOpen} onOpenChange={setIsAddDialogOpen}>
        <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>Log New Incident</DialogTitle>
          </DialogHeader>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 py-4">
            <div className="space-y-2">
              <Label>Resident *</Label>
              <Select value={formData.residentId} onValueChange={(value) => {
                const autoOffense = getAutoOffenseNumber(value);
                setFormData({ ...formData, residentId: value, offenseNumber: autoOffense });
              }}>
                <SelectTrigger>
                  <SelectValue placeholder="Select resident" />
                </SelectTrigger>
                <SelectContent>
                  {children.map((child) => (
                    <SelectItem key={child.id} value={child.id}>
                      {child.name} ({getViolationPointsForResident(child.id)} points)
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label>Date *</Label>
              <Input type="date" value={formData.date} onChange={(e) => setFormData({ ...formData, date: e.target.value })} />
            </div>
            <div className="space-y-2">
              <Label>Incident Type *</Label>
              <Select
                value={formData.type}
                onValueChange={(v) => {
                  const found = activeMatrix.find(m => m.label === v);
                  if (found) {
                    setFormData(prev => ({
                      ...prev,
                      type: found.label,
                      severity: found.severity,
                      points: found.points,
                    }));
                  }
                }}
              >
                <SelectTrigger><SelectValue placeholder="Select incident type..." /></SelectTrigger>
                <SelectContent className="max-h-80">
                  <div className="px-2 py-1 text-[10px] font-black uppercase text-red-500 tracking-wider">⚠ Major Offenses (3–5 pts)</div>
                  {activeMatrix.filter(m => m.category === "Major").map(m => (
                    <SelectItem key={m.id} value={m.label}>
                      <div className="flex items-center gap-2">
                        <span className={m.severity === "Critical" ? "w-2 h-2 rounded-full bg-red-600" : "w-2 h-2 rounded-full bg-orange-500"} />
                        <span className="text-sm">{m.label}</span>
                        <span className="text-[10px] text-gray-400">{m.points}pts</span>
                      </div>
                    </SelectItem>
                  ))}
                  <div className="px-2 py-1 text-[10px] font-black uppercase text-yellow-600 tracking-wider border-t">Minor Offenses (1 pt)</div>
                  {activeMatrix.filter(m => m.category === "Minor").map(m => (
                    <SelectItem key={m.id} value={m.label}>
                      <div className="flex items-center gap-2">
                        <span className="w-2 h-2 rounded-full bg-yellow-400" />
                        <span className="text-sm">{m.label}</span>
                      </div>
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
              {formData.type && (
                <div className={"flex items-center gap-2 px-3 py-1.5 rounded-lg text-xs font-semibold " + (
                  formData.severity === "Critical" ? "bg-red-50 text-red-700 border border-red-200" :
                  formData.severity === "Major" ? "bg-orange-50 text-orange-700 border border-orange-200" :
                  "bg-yellow-50 text-yellow-700 border border-yellow-200"
                )}>
                  <span>{formData.severity} — {formData.points} point{formData.points !== 1 ? "s" : ""}</span>
                  <span className="text-gray-400 font-normal">· auto-detected from matrix</span>
                </div>
              )}
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => { setIsAddDialogOpen(false); resetForm(); }}>Cancel</Button>
            <Button
              onClick={handleOpenIncidentReport}
              disabled={!formData.residentId || !formData.type || creatingIncident}
              className="bg-[#2F3E46]"
            >
              {creatingIncident ? 'Loading...' : 'Fill Out Incident Report'}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <IncidentReportModal
        open={isIncidentReportOpen}
        onOpenChange={setIsIncidentReportOpen}
        mode={incidentReportMode}
        violationId={activeIncidentViolationId}
        residentId={activeIncidentResidentId}
        residentName={children.find(c => c.id === activeIncidentResidentId)?.name}
        currentUsername={user?.username}
        canVerify={isPsychologist || isCenterHead}
        onSaved={() => { resetForm(); setTimeout(() => refreshData(), 300); }}
      />

      {/* View Incident Dialog */}
      <Dialog open={isViewDialogOpen} onOpenChange={setIsViewDialogOpen}>
        <DialogContent className="max-w-xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="text-[#2F3E46] flex items-center gap-2">
              <ShieldAlert className="w-5 h-5 text-orange-500" /> Violation Record
            </DialogTitle>
          </DialogHeader>
          {selectedViolation && (() => {
            const resident = children.find(c => c.id === selectedViolation.residentId);
            const matrix = activeMatrix.find(m => m.label === selectedViolation.type);
            const interventionRaw = matrix?.intervention || '';
            const interventionLines = interventionRaw.split(String.fromCharCode(10)).filter((l: string) => l.trim());
            return (
              <div className="space-y-4 py-2">
                <div className="grid grid-cols-2 gap-3 text-sm">
                  <div>
                    <p className="text-[10px] font-bold text-gray-400 uppercase">Resident</p>
                    <p className="font-bold text-[#2F3E46]">{resident?.name || '—'}</p>
                  </div>
                  <div>
                    <p className="text-[10px] font-bold text-gray-400 uppercase">Date</p>
                    <p className="font-semibold text-[#2F3E46]">{formatShortDate(selectedViolation.date)}</p>
                  </div>
                  <div>
                    <p className="text-[10px] font-bold text-gray-400 uppercase">Offense Classification</p>
                    <p className="font-semibold text-[#2F3E46]">{(selectedViolation as any).offenseNumber || '—'}</p>
                  </div>
                  <div>
                    <p className="text-[10px] font-bold text-gray-400 uppercase">Points / Severity</p>
                    <div className="flex items-center gap-2">
                      <span className="font-bold text-[#2F3E46]">{selectedViolation.points} pts</span>
                      <span className={`px-2 py-0.5 rounded-full text-[10px] font-bold ${
                        selectedViolation.severity === 'Critical' ? 'bg-red-100 text-red-700' :
                        selectedViolation.severity === 'Major'    ? 'bg-orange-100 text-orange-700' :
                                                                    'bg-yellow-100 text-yellow-700'
                      }`}>{selectedViolation.severity}</span>
                    </div>
                  </div>
                  {selectedViolation.reportedBy && (
                    <div>
                      <p className="text-[10px] font-bold text-gray-400 uppercase">Reported By</p>
                      <p className="font-semibold text-[#2F3E46]">{selectedViolation.reportedBy}</p>
                    </div>
                  )}
                  {selectedViolation.location && (
                    <div>
                      <p className="text-[10px] font-bold text-gray-400 uppercase">Location</p>
                      <p className="font-semibold text-[#2F3E46]">{selectedViolation.location}</p>
                    </div>
                  )}
                </div>

                <div className="p-3 bg-gray-50 rounded-xl border border-gray-200">
                  <p className="text-[10px] font-bold text-gray-400 uppercase mb-1">Violation</p>
                  <p className="font-semibold text-[#2F3E46] text-sm">{selectedViolation.type}</p>
                  {matrix?.tagalog && <p className="text-xs text-gray-400 italic mt-0.5">{matrix.tagalog}</p>}
                </div>

                <div className="border border-gray-200 rounded-xl overflow-hidden">
                  <div className="bg-[#2F3E46] px-4 py-2.5 flex items-center justify-between">
                    <p className="text-xs font-bold text-white uppercase tracking-wide">Prescribed Interventions</p>
                    {matrix?.assessor && <span className="text-[10px] text-gray-300">Assessor: {matrix.assessor}</span>}
                  </div>
                  {interventionLines.length > 0 ? (
                    <div className="divide-y divide-gray-100">
                      {interventionLines.map((line: string, i: number) => {
                        const colonIdx = line.indexOf(':');
                        const hasLabel = colonIdx > 0 && colonIdx < 30;
                        const label = hasLabel ? line.substring(0, colonIdx).trim() : null;
                        const text  = hasLabel ? line.substring(colonIdx + 1).trim() : line.trim();
                        const colors = ['bg-blue-50 border-blue-200 text-blue-700','bg-yellow-50 border-yellow-200 text-yellow-700','bg-orange-50 border-orange-200 text-orange-700','bg-red-50 border-red-200 text-red-700'];
                        return (
                          <div key={i} className="flex items-start gap-3 p-3">
                            {label ? (
                              <span className={`shrink-0 text-[10px] font-bold px-2 py-1 rounded-lg border whitespace-nowrap ${colors[Math.min(i, colors.length-1)]}`}>
                                {label}
                              </span>
                            ) : (
                              <span className="shrink-0 w-2 h-2 rounded-full bg-gray-300 mt-2" />
                            )}
                            <p className="text-sm text-gray-700 flex-1">{text}</p>
                          </div>
                        );
                      })}
                    </div>
                  ) : (
                    <p className="p-3 text-sm text-gray-500">No prescribed interventions on record.</p>
                  )}
                </div>
              </div>
            );
          })()}
          <DialogFooter>
            <Button variant="outline" onClick={() => setIsViewDialogOpen(false)}>Close</Button>
            {selectedViolation && (isCenterHead || isSocialWorker) && (
              <Button onClick={() => { setIsViewDialogOpen(false); openEditDialog(selectedViolation); }} className="bg-[#2F3E46] text-white">
                <Edit className="w-4 h-4 mr-1" /> Edit
              </Button>
            )}
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Edit Incident Dialog */}
      <Dialog open={isEditDialogOpen} onOpenChange={setIsEditDialogOpen}>
        <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>Edit Incident</DialogTitle>
          </DialogHeader>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 py-4">
            <div className="space-y-2">
              <Label>Resident *</Label>
              <Select value={formData.residentId} onValueChange={(value) => {
                const autoOffense = getAutoOffenseNumber(value);
                setFormData({ ...formData, residentId: value, offenseNumber: autoOffense });
              }}>
                <SelectTrigger>
                  <SelectValue placeholder="Select resident" />
                </SelectTrigger>
                <SelectContent>
                  {children.map((child) => (
                    <SelectItem key={child.id} value={child.id}>
                      {child.name} ({getViolationPointsForResident(child.id)} points)
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label>Date *</Label>
              <Input type="date" value={formData.date} onChange={(e) => setFormData({ ...formData, date: e.target.value })} />
            </div>
            <div className="space-y-2">
              <Label>Incident Type *</Label>
              <Select
                value={formData.type}
                onValueChange={(v) => {
                  const found = activeMatrix.find(m => m.label === v);
                  if (found) {
                    setFormData(prev => ({
                      ...prev,
                      type: found.label,
                      severity: found.severity,
                      points: found.points,
                    }));
                  }
                }}
              >
                <SelectTrigger><SelectValue placeholder="Select incident type..." /></SelectTrigger>
                <SelectContent className="max-h-80">
                  <div className="px-2 py-1 text-[10px] font-black uppercase text-red-500 tracking-wider">⚠ Major Offenses (3–5 pts)</div>
                  {activeMatrix.filter(m => m.category === "Major").map(m => (
                    <SelectItem key={m.id} value={m.label}>
                      <div className="flex items-center gap-2">
                        <span className={m.severity === "Critical" ? "w-2 h-2 rounded-full bg-red-600" : "w-2 h-2 rounded-full bg-orange-500"} />
                        <span className="text-sm">{m.label}</span>
                        <span className="text-[10px] text-gray-400">{m.points}pts</span>
                      </div>
                    </SelectItem>
                  ))}
                  <div className="px-2 py-1 text-[10px] font-black uppercase text-yellow-600 tracking-wider border-t">Minor Offenses (1 pt)</div>
                  {activeMatrix.filter(m => m.category === "Minor").map(m => (
                    <SelectItem key={m.id} value={m.label}>
                      <div className="flex items-center gap-2">
                        <span className="w-2 h-2 rounded-full bg-yellow-400" />
                        <span className="text-sm">{m.label}</span>
                      </div>
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
              {formData.type && (
                <div className={"flex items-center gap-2 px-3 py-1.5 rounded-lg text-xs font-semibold " + (
                  formData.severity === "Critical" ? "bg-red-50 text-red-700 border border-red-200" :
                  formData.severity === "Major" ? "bg-orange-50 text-orange-700 border border-orange-200" :
                  "bg-yellow-50 text-yellow-700 border border-yellow-200"
                )}>
                  <span>{formData.severity} — {formData.points} point{formData.points !== 1 ? "s" : ""}</span>
                  <span className="text-gray-400 font-normal">· auto-detected from matrix</span>
                </div>
              )}
            </div>
            <div className="space-y-2">
              <Label>Severity *</Label>
              <Select value={formData.severity} onValueChange={(value) => handleSeverityChange(value as 'Minor' | 'Major' | 'Critical')}>
                <SelectTrigger>
                  <SelectValue placeholder="Select severity" />
                </SelectTrigger>
                <SelectContent>
                  {SEVERITY_OPTIONS.map((opt) => (
                    <SelectItem key={opt.value} value={opt.value}>{opt.label}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2 sm:col-span-2">
              <Label>Description</Label>
              <Textarea
                value={formData.description}
                onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                placeholder="Describe the incident..."
                rows={3}
              />
            </div>
            <div className="space-y-2">
              <Label>Location</Label>
              <Input value={formData.location} onChange={(e) => setFormData({ ...formData, location: e.target.value })} placeholder="Where did it occur?" />
            </div>
            <div className="space-y-2">
              <Label>Witnesses</Label>
              <Input value={formData.witnesses} onChange={(e) => setFormData({ ...formData, witnesses: e.target.value })} placeholder="Names of witnesses" />
            </div>
            <div className="space-y-2">
              <Label>Reported By</Label>
              <Input value={formData.reportedBy} onChange={(e) => setFormData({ ...formData, reportedBy: e.target.value })} placeholder="Your name" />
            </div>
            <div className="space-y-2">
              <Label>Action Taken</Label>
              <Input value={formData.actionTaken} onChange={(e) => setFormData({ ...formData, actionTaken: e.target.value })} placeholder="Immediate action taken" />
            </div>
            <div className="space-y-2">
              <Label>Status *</Label>
              <Select value={formData.status} onValueChange={(value) => setFormData({ ...formData, status: value as Violation['status'] })}>
                <SelectTrigger>
                  <SelectValue placeholder="Select status" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="Pending Review">Pending Review</SelectItem>
                  <SelectItem value="Under Investigation">Under Investigation</SelectItem>
                  <SelectItem value="Reviewed">Reviewed</SelectItem>
                  <SelectItem value="Resolved">Resolved</SelectItem>
                  <SelectItem value="Escalated">Escalated</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setIsEditDialogOpen(false)}>Cancel</Button>
            <Button onClick={handleUpdate} className="bg-[#2F3E46]">Update Incident</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Delete Dialog */}
      {/* ── VIEW MANAGE VIOLATION DIALOG ── */}
      <Dialog open={!!viewManageViolation} onOpenChange={open => { if (!open) setViewManageViolation(null); }}>
        <DialogContent className="max-w-lg max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="text-[#2F3E46] flex items-center gap-2">
              <ShieldAlert className="w-5 h-5 text-orange-500" /> Violation Details
            </DialogTitle>
          </DialogHeader>
          {viewManageViolation && (
            <div className="space-y-4 py-2">
              <div className="p-4 bg-gray-50 rounded-xl space-y-2">
                <p className="font-bold text-[#2F3E46] text-base">{viewManageViolation.label}</p>
                {viewManageViolation.tagalog && (
                  <p className="text-sm text-gray-500 italic">{viewManageViolation.tagalog}</p>
                )}
                <div className="flex items-center gap-2 flex-wrap pt-1">
                  <span className={`px-2.5 py-1 rounded-full text-xs font-bold ${
                    viewManageViolation.severity === 'Critical' ? 'bg-red-100 text-red-700' :
                    viewManageViolation.severity === 'Major'    ? 'bg-orange-100 text-orange-700' :
                                                                  'bg-yellow-100 text-yellow-700'
                  }`}>{viewManageViolation.severity}</span>
                  <span className="px-2.5 py-1 rounded-full text-xs font-bold bg-gray-200 text-gray-600">{viewManageViolation.category}</span>
                  <span className="px-2.5 py-1 rounded-full text-xs font-bold bg-blue-100 text-blue-700">{viewManageViolation.points} pts</span>
                  <span className="px-2.5 py-1 rounded-full text-xs font-bold bg-purple-100 text-purple-700">Assessor: {viewManageViolation.assessor}</span>
                </div>
              </div>
              <div className="border border-gray-200 rounded-xl overflow-hidden">
                <div className="bg-[#2F3E46] px-4 py-2.5">
                  <p className="text-xs font-bold text-white uppercase tracking-wide">Interventions by Offense Level</p>
                </div>
                <div className="divide-y divide-gray-100">
                  {([
                    { offense: '1st Offense',              color: 'bg-blue-50 border-blue-200 text-blue-700'      },
                    { offense: '2nd Offense',              color: 'bg-yellow-50 border-yellow-200 text-yellow-700' },
                    { offense: '3rd Offense & Succeeding', color: 'bg-orange-50 border-orange-200 text-orange-700' },
                  ] as const).map(({ offense, color }) => (
                    <div key={offense} className="flex items-start gap-3 p-3">
                      <span className={`shrink-0 text-[10px] font-bold px-2 py-1 rounded-lg border whitespace-nowrap ${color}`}>
                        {offense}
                      </span>
                      <p className="text-sm text-gray-700 flex-1">
                        {viewManageViolation.intervention || 'No intervention specified.'}
                      </p>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          )}
          <DialogFooter>
            <Button variant="outline" onClick={() => setViewManageViolation(null)}>Close</Button>
            <Button className="bg-[#2F3E46] text-white"
              onClick={() => { if (viewManageViolation) { openEditViolation(viewManageViolation); setViewManageViolation(null); } }}>
              <Edit className="w-4 h-4 mr-1" /> Edit
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* ── ADD / EDIT VIOLATION DIALOG (Center Head only) ── */}
      <Dialog open={isViolationDialogOpen} onOpenChange={setIsViolationDialogOpen}>
        <DialogContent className="max-w-lg max-h-[90vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="text-[#2F3E46]">
              {editingViolation ? 'Edit Violation' : 'Add New Violation'}
            </DialogTitle>
          </DialogHeader>
          <div className="space-y-3 py-2">
            <div className="space-y-1">
              <Label className="text-sm font-bold">Violation Name *</Label>
              <Input value={violationForm.label} onChange={e => setViolationForm(p => ({...p, label: e.target.value}))} placeholder="e.g. Pagtangkang Tumakas" />
            </div>
            <div className="space-y-1">
              <Label className="text-sm font-bold">Tagalog Description</Label>
              <Input value={violationForm.tagalog} onChange={e => setViolationForm(p => ({...p, tagalog: e.target.value}))} placeholder="Tagalog description..." />
            </div>
            <div className="grid grid-cols-3 gap-3">
              <div className="space-y-1">
                <Label className="text-sm font-bold">Category</Label>
                <Select value={violationForm.category} onValueChange={v => setViolationForm(p => ({...p, category: v as any}))}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="Major">Major</SelectItem>
                    <SelectItem value="Minor">Minor</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-1">
                <Label className="text-sm font-bold">Severity</Label>
                <Select value={violationForm.severity} onValueChange={v => setViolationForm(p => ({...p, severity: v as any}))}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="Minor">Minor</SelectItem>
                    <SelectItem value="Major">Major</SelectItem>
                    <SelectItem value="Critical">Critical</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-1">
                <Label className="text-sm font-bold">Points</Label>
                <Input type="number" min={1} max={10} value={violationForm.points} onChange={e => setViolationForm(p => ({...p, points: parseInt(e.target.value) || 1}))} />
              </div>
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-1">
                <Label className="text-sm font-bold">Assessor</Label>
                <Select value={violationForm.assessor} onValueChange={v => setViolationForm(p => ({...p, assessor: v}))}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="Social Worker">Social Worker</SelectItem>
                    <SelectItem value="Psychologist">Psychologist</SelectItem>
                    <SelectItem value="Nurse">Nurse</SelectItem>
                    <SelectItem value="Center Head">Center Head</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-1">
                <Label className="text-sm font-bold">Assessment Type</Label>
                <Input value={violationForm.assessmentType} onChange={e => setViolationForm(p => ({...p, assessmentType: e.target.value}))} placeholder="e.g. Behavioral Assessment" />
              </div>
            </div>
            <div className="space-y-1">
              <Label className="text-sm font-bold">Intervention Steps *</Label>
              <Textarea value={violationForm.intervention} onChange={e => setViolationForm(p => ({...p, intervention: e.target.value}))} rows={4} placeholder="Describe the intervention steps..." />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setIsViolationDialogOpen(false)}>Cancel</Button>
            <Button onClick={handleSaveViolation} disabled={!violationForm.label.trim()} className="bg-[#2F3E46] text-white">
              {editingViolation ? 'Save Changes' : 'Add Violation'}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* ── DELETE VIOLATION CONFIRM ── */}
      <AlertDialog open={!!deleteViolationId} onOpenChange={open => { if (!open) setDeleteViolationId(null); }}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Remove this violation?</AlertDialogTitle>
            <AlertDialogDescription>
              This will remove the violation from the list. Existing incident records are not affected.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction className="bg-red-600 hover:bg-red-700"
              onClick={() => deleteViolationId && handleDeleteViolation(deleteViolationId)}>
              Remove
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      <AlertDialog open={showClearConfirm} onOpenChange={setShowClearConfirm}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Reset Intervention Records?</AlertDialogTitle>
            <AlertDialogDescription>
              This will mark all active violations for <strong>{clearingMonth}</strong> as Resolved.
              Only Social Workers can perform this action.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction className="bg-red-600 hover:bg-red-700" onClick={handleClearMonth}>
              Yes, Reset Month
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      <AlertDialog open={isDeleteDialogOpen} onOpenChange={setIsDeleteDialogOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Delete Incident Record</AlertDialogTitle>
            <AlertDialogDescription>
              Are you sure you want to delete this violation record? This action cannot be undone.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel onClick={() => setIsDeleteDialogOpen(false)}>Cancel</AlertDialogCancel>
            <AlertDialogAction onClick={handleDelete} className="bg-red-600">Delete</AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      {/* Psychologist Review Dialog */}
      <Dialog open={isReviewDialogOpen} onOpenChange={setIsReviewDialogOpen}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <ShieldAlert className="w-5 h-5 text-purple-600" />
              Review Incident
            </DialogTitle>
          </DialogHeader>
          {selectedViolation && (
            <div className="space-y-4 py-2">
              <div className="p-3 bg-gray-50 rounded-lg text-sm space-y-1">
                <p><span className="font-medium">Resident:</span> {children.find(c => c.id === selectedViolation.residentId)?.name || 'Unknown'}</p>
                <p><span className="font-medium">Type:</span> {selectedViolation.type}</p>
                <p><span className="font-medium">Reported on:</span> {formatShortDate(selectedViolation.date)}</p>
                <p><span className="font-medium">Reported by:</span> {selectedViolation.reportedBy || 'N/A'}</p>
                <p className="text-gray-600">{selectedViolation.description}</p>
              </div>
              <div className="space-y-2">
                <Label>Confirm / Adjust Severity</Label>
                <Select value={reviewForm.severity} onValueChange={(v) => setReviewForm(p => ({ ...p, severity: v as 'Minor' | 'Major' | 'Critical' }))}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>
                    {SEVERITY_OPTIONS.map(o => <SelectItem key={o.value} value={o.value}>{o.label}</SelectItem>)}
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label>Review Status</Label>
                <Select value={reviewForm.status} onValueChange={(v) => setReviewForm(p => ({ ...p, status: v }))}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="Reviewed">Reviewed</SelectItem>
                    <SelectItem value="Under Investigation">Under Investigation</SelectItem>
                    <SelectItem value="Escalated">Escalated</SelectItem>
                    <SelectItem value="Resolved">Resolved</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label>Recommended Action / Notes</Label>
                <Textarea
                  value={reviewForm.actionTaken}
                  onChange={(e) => setReviewForm(p => ({ ...p, actionTaken: e.target.value }))}
                  placeholder="Describe recommended intervention or action..."
                  rows={3}
                />
              </div>
            </div>
          )}
          <DialogFooter>
            <Button variant="outline" onClick={() => setIsReviewDialogOpen(false)}>Cancel</Button>
            <Button onClick={handleReview} className="bg-purple-600 hover:bg-purple-700 text-white">
              <ShieldAlert className="w-4 h-4 mr-1" /> Submit Review
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
