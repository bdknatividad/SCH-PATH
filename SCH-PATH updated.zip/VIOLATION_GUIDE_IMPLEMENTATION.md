# Violation & Intervention Guide Implementation

## Overview

The Violation & Intervention Guide module has been successfully implemented as per the design document. This system provides a structured, master list that controls violation and intervention data throughout SCH-PATH.

## Architecture

### Database Layer

Four new tables have been created:

#### 1. **violation_guide**
Stores violation definitions with their metadata.

```sql
- id (VARCHAR(40), PRIMARY KEY)
- name (VARCHAR(150)) - Violation name
- category (ENUM: 'Minor', 'Major')
- description (TEXT) - Optional detailed description
- status (ENUM: 'Active', 'Inactive')
- createdBy (VARCHAR(100))
- updatedBy (VARCHAR(100))
- createdAt (TIMESTAMP)
- updatedAt (TIMESTAMP)
```

**Index**: status, category

#### 2. **intervention_types**
Reference table for all available intervention types.

```sql
- id (VARCHAR(40), PRIMARY KEY)
- type (VARCHAR(100)) - Intervention type name (UNIQUE)
- description (TEXT)
- requiresDuration (BOOLEAN) - Whether this type requires a duration field
- createdAt (TIMESTAMP)
```

**Pre-populated intervention types**:
- Privilege Suspension (requires duration)
- Psychosocial Activity (no duration)
- Household Chores (requires duration)
- Cleaning (requires duration)
- Confiscation (no duration)
- Dialogue/Counseling (no duration)
- Referral (no duration)
- Other (no duration)

#### 3. **guide_interventions**
Maps interventions to violation guides by offense level.

```sql
- id (VARCHAR(40), PRIMARY KEY)
- guideId (VARCHAR(40), FOREIGN KEY → violation_guide.id)
- offenseLevel (ENUM: '1st', '2nd', '3rd')
- interventionType (VARCHAR(100))
- duration (INT) - Optional duration value
- unit (VARCHAR(50)) - Optional unit (Day(s), Week(s), Month(s), Hour(s))
- metadata (JSON) - Optional metadata for future expansion
- createdAt (TIMESTAMP)
- updatedAt (TIMESTAMP)
```

**Indexes**: guideId, offenseLevel

#### 4. **intervention_tracker**
Tracks interventions assigned to individual residents.

```sql
- id (VARCHAR(40), PRIMARY KEY)
- residentId (VARCHAR(40), FOREIGN KEY → children.id)
- violationId (VARCHAR(40), FOREIGN KEY → violations.id)
- guideId (VARCHAR(40), FOREIGN KEY → violation_guide.id)
- offenseLevel (ENUM: '1st', '2nd', '3rd')
- interventionType (VARCHAR(100))
- duration (INT)
- unit (VARCHAR(50))
- status (ENUM: 'Pending', 'In Progress', 'Completed')
- startDate (DATE)
- completionDate (DATE)
- notes (TEXT)
- completedBy (VARCHAR(100))
- createdAt (TIMESTAMP)
- updatedAt (TIMESTAMP)
```

**Indexes**: residentId, status, violationId

### Backend Layer

#### Controllers

**File**: `backend/src/controllers/violationGuideController.js`

Endpoints:
- `getAll()` - Retrieve all violation guides with optional status filtering
- `getById(id)` - Get single guide with all interventions grouped by offense level
- `create(body)` - Create new violation guide with interventions
- `update(id, body)` - Update guide and its interventions
- `delete(id)` - Mark guide as inactive (soft delete)
- `getInterventionTypes()` - Retrieve all intervention types
- `assignInterventions(body)` - Assign interventions to a resident
- `getResidentInterventions(residentId)` - Get intervention tracker for resident
- `updateInterventionStatus(id, body)` - Update intervention completion status

#### Routes

**File**: `backend/src/routes/violationGuideRoutes.js`

```
GET  /api/violation-guide                              - Get all guides
GET  /api/violation-guide/intervention-types           - Get intervention types
GET  /api/violation-guide/:id                          - Get guide details
GET  /api/violation-guide/resident/:residentId/interventions - Get resident interventions
POST /api/violation-guide                              - Create guide (auth required)
POST /api/violation-guide/assign-interventions         - Assign interventions (auth required)
PUT  /api/violation-guide/:id                          - Update guide (auth required)
PUT  /api/violation-guide/intervention-tracker/:id     - Update intervention status (auth required)
DELETE /api/violation-guide/:id                        - Mark as inactive (auth required)
```

**Authorization**: Routes require one of: centerhead, socialworker, psychologist

#### Helper Utilities

**File**: `backend/src/utils/violationGuideHelper.js`

Functions for integration with violation logging:
- `findGuideByViolationType(violationType)` - Find guide by violation name
- `determineOffenseLevel(residentId, guideId)` - Calculate offense number
- `assignInterventions(residentId, violationId, guideId, offenseLevel)` - Auto-assign interventions
- `getResidentInterventions(residentId)` - Get intervention tracker
- `getInterventionDisplay(intervention)` - Format intervention for display
- `formatInterventionsByLevel(interventions)` - Group interventions by offense level

### Frontend Layer

#### Components

**File**: `frontend/src/app/components/ViolationGuide.tsx`

Main component for managing Violation & Intervention Guide.

**Features**:
- View all violations in a structured table
- Filter by status (Active/Inactive) and search by name
- View detailed violation configuration
- Add new violations (authorized users)
- Edit existing violations (authorized users)
- Mark violations as inactive (authorized users)
- Multi-level intervention management (1st, 2nd, 3rd offense)
- Dynamic intervention form fields based on type

**UI Components Used**:
- Card, Badge, Button, Input, Label, Select, Textarea
- Dialog for add/edit forms
- AlertDialog for delete confirmation
- Icons from lucide-react

**Permissions**:
- View: All authenticated users
- Manage (Create/Edit/Delete): centerhead, socialworker, psychologist

#### Navigation

**File**: `frontend/src/app/components/Layout.tsx`

Added menu item:
- Label: "Violation Guide"
- Path: "/violation-guide"
- Icon: FileText
- Position: After Violations

#### Routing

**File**: `frontend/src/app/App.tsx`

Added route:
```tsx
<Route path="/violation-guide" element={
  <ProtectedRoute moduleName="Violations">
    <Layout><ViolationGuide /></Layout>
  </ProtectedRoute>
} />
```

## Data Flow

### 1. Creating a Violation Guide

**User** → **Frontend (ViolationGuide.tsx)** → **POST /violation-guide** → **Controller** → **Database**

1. User fills in violation name, category, description
2. User adds interventions for each offense level
3. Form validates data
4. POST request sends to backend with structured intervention data
5. Controller creates violation_guide record and guide_interventions records in transaction
6. Response includes created guide with all interventions grouped by level

### 2. Logging a Violation (Integration Point)

When a Social Worker logs a violation in the Violations module:

1. Violation is created in violations table
2. System can look up the corresponding violation_guide
3. System determines offense level (1st, 2nd, or 3rd)
4. System calls assignInterventions() to create intervention_tracker records
5. Required interventions are now visible to the Psychologist

### 3. Tracking Intervention Completion

**Psychologist/Social Worker** → **Update Intervention Status** → **PUT /violation-guide/intervention-tracker/:id**

1. Staff member marks intervention as In Progress or Completed
2. Completion date and completed-by fields are populated
3. Intervention Tracker reflects current status

## Key Design Features

### 1. Structured Data vs. Free Text

**Before**: Interventions stored as free text strings
**After**: Each intervention is a structured record with:
- Intervention type (enum)
- Duration (number)
- Unit (enum: days, weeks, months, hours)
- Metadata (JSON for extensibility)

**Benefit**: System can now understand and respond to specific intervention types (e.g., trigger Psychosocial Activity in Assessments module)

### 2. Soft Delete Pattern

Violations are marked as "Inactive" rather than deleted:
- Historical records remain intact
- No broken foreign key references
- Audit trail preserved
- Violations can be reactivated if needed

### 3. Offense Level Tracking

System tracks the number of times a child has violated the same rule:
- 1st Offense → applies 1st level interventions
- 2nd Offense → applies 2nd level interventions
- 3rd+ Offense → applies 3rd level interventions

### 4. Role-Based Access

Managed through authorization middleware:
- **View**: All authenticated users
- **Manage**: centerhead, socialworker, psychologist
- Nurse, educator, and other roles can view but not modify

### 5. Audit Trail

All guide modifications are tracked:
- createdBy / createdAt - Initial creation
- updatedBy / updatedAt - Last modification
- View page displays this information

## Usage Examples

### Creating a Violation Guide

```json
POST /api/violation-guide
{
  "name": "Making noise during study time",
  "category": "Minor",
  "description": "Student creating disturbance during designated quiet hours",
  "status": "Active",
  "interventions": {
    "1st": [
      {
        "interventionType": "Privilege Suspension",
        "duration": 1,
        "unit": "Day(s)"
      },
      {
        "interventionType": "Psychosocial Activity"
      }
    ],
    "2nd": [
      {
        "interventionType": "Privilege Suspension",
        "duration": 2,
        "unit": "Day(s)"
      },
      {
        "interventionType": "Psychosocial Activity"
      }
    ],
    "3rd": [
      {
        "interventionType": "Privilege Suspension",
        "duration": 3,
        "unit": "Day(s)"
      },
      {
        "interventionType": "Psychosocial Activity"
      },
      {
        "interventionType": "Household Chores",
        "duration": 3,
        "unit": "Day(s)"
      }
    ]
  }
}
```

### Assigning Interventions to a Resident

```json
POST /api/violation-guide/assign-interventions
{
  "residentId": "CHILD-001",
  "violationId": "VIO-12345",
  "guideId": "VG-001",
  "offenseLevel": "2nd"
}
```

Response:
```json
{
  "success": true,
  "data": [
    {
      "id": "IT-001",
      "interventionType": "Privilege Suspension",
      "duration": 2,
      "unit": "Day(s)"
    },
    {
      "id": "IT-002",
      "interventionType": "Psychosocial Activity"
    }
  ]
}
```

### Updating Intervention Status

```json
PUT /api/violation-guide/intervention-tracker/IT-001
{
  "status": "Completed",
  "notes": "Resident completed intervention on schedule"
}
```

## Integration with Other Modules

### Violations Module

**Enhancement**: When logging a violation, the system can:
1. Look up the corresponding violation guide
2. Display recommended interventions to the Social Worker
3. Automatically assign interventions upon violation verification
4. Link to this guide for reference

### Assessments Module

**Enhancement**: Psychologist can see:
1. List of pending Psychosocial Activity interventions
2. Source violation that triggered the requirement
3. Offense level and related interventions
4. Schedule activity directly from the tracker

### Child Records

**Enhancement**: Care staff can view:
1. Complete intervention history
2. Pending interventions for the child
3. Completion status and dates
4. Notes and completing staff member

## Database Migration

A migration file has been created:
**File**: `backend/migrations/add-violation-guide.mjs`

To apply the migration:
```bash
cd backend
node migrations/add-violation-guide.mjs up
```

To rollback:
```bash
node migrations/add-violation-guide.mjs down
```

## Error Handling

The implementation includes:
- Validation of required fields
- Transaction rollback on error
- Detailed error messages
- Foreign key constraint checks
- Authorization checks on protected endpoints

## Testing Recommendations

1. **Create Operations**
   - Add violation with multiple interventions
   - Verify all records created correctly
   - Test with missing required fields

2. **Read Operations**
   - Retrieve guide with all interventions
   - Verify interventions grouped by offense level
   - Test filtering and search

3. **Update Operations**
   - Modify violation details
   - Add/remove interventions
   - Verify audit trail updated

4. **Integration**
   - Log violation and verify guide lookup
   - Assign interventions and verify tracker
   - Update intervention status and verify completion

5. **Authorization**
   - Test access by different roles
   - Verify unauthorized users cannot modify
   - Test view-only permissions

## Future Enhancements

1. **Batch Operations**: Upload multiple violations from CSV
2. **Template Library**: Pre-built violation templates
3. **Version Control**: Track changes to violation definitions
4. **Analytics**: Reports on intervention compliance rates
5. **Custom Fields**: Allow facilities to add custom metadata
6. **Linking to Phases**: Tie interventions to phase progression
7. **Staff Assignment**: Auto-assign staff to interventions
8. **Notifications**: Alert relevant staff when interventions are due

## Files Created/Modified

### Created Files
- `backend/src/controllers/violationGuideController.js`
- `backend/src/routes/violationGuideRoutes.js`
- `backend/src/utils/violationGuideHelper.js`
- `backend/migrations/add-violation-guide.mjs`
- `frontend/src/app/components/ViolationGuide.tsx`

### Modified Files
- `backend/src/database/schema.sql` - Added 4 new tables
- `backend/src/routes/index.js` - Registered violation guide routes
- `frontend/src/app/App.tsx` - Added route and import
- `frontend/src/app/components/Layout.tsx` - Added navigation link

## Summary

The Violation & Intervention Guide module has been successfully implemented with:
- ✅ Structured database tables for violations and interventions
- ✅ Complete backend API with CRUD operations
- ✅ Frontend UI for managing guides
- ✅ Integration points for other modules
- ✅ Role-based access control
- ✅ Helper utilities for system integration
- ✅ Soft delete pattern for data integrity
- ✅ Audit trail and tracking

The system is now ready to:
1. Define violations with structured interventions
2. Track interventions assigned to residents
3. Monitor intervention completion
4. Serve as the master data source for the Violations and Assessments modules
