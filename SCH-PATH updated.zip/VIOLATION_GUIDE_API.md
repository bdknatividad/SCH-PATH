# Violation & Intervention Guide - API Reference

## Base URL
```
/api/violation-guide
```

## Endpoints

### 1. Get All Violation Guides
```
GET /api/violation-guide
```

**Query Parameters**:
- `status` (optional): Filter by 'Active' or 'Inactive'

**Response**:
```json
{
  "success": true,
  "data": [
    {
      "id": "VG-001",
      "name": "Making noise during study time",
      "category": "Minor",
      "description": "...",
      "status": "Active",
      "createdBy": "socialworker",
      "createdAt": "2026-09-01T10:00:00Z",
      "updatedAt": "2026-09-01T10:00:00Z",
      "updatedBy": null,
      "interventions": [
        {
          "id": "GI-001",
          "offenseLevel": "1st",
          "interventionType": "Privilege Suspension",
          "duration": 1,
          "unit": "Day(s)"
        }
      ]
    }
  ],
  "count": 1
}
```

### 2. Get Violation Guide by ID
```
GET /api/violation-guide/:id
```

**Response**:
```json
{
  "success": true,
  "data": {
    "id": "VG-001",
    "name": "Making noise during study time",
    "category": "Minor",
    "description": "...",
    "status": "Active",
    "createdBy": "socialworker",
    "createdAt": "2026-09-01T10:00:00Z",
    "updatedAt": "2026-09-01T10:00:00Z",
    "updatedBy": null,
    "interventions": {
      "1st": [...],
      "2nd": [...],
      "3rd": [...]
    }
  }
}
```

### 3. Create Violation Guide
```
POST /api/violation-guide
Authorization: Bearer token
Content-Type: application/json
```

**Required Authorization**: centerhead, socialworker, psychologist

**Request Body**:
```json
{
  "name": "Making noise during study time",
  "category": "Minor",
  "description": "Optional description",
  "status": "Active",
  "interventions": {
    "1st": [
      {
        "interventionType": "Privilege Suspension",
        "duration": 1,
        "unit": "Day(s)"
      },
      {
        "interventionType": "Psychosocial Activity"
      }
    ],
    "2nd": [
      {
        "interventionType": "Privilege Suspension",
        "duration": 2,
        "unit": "Day(s)"
      },
      {
        "interventionType": "Psychosocial Activity"
      }
    ],
    "3rd": [
      {
        "interventionType": "Privilege Suspension",
        "duration": 3,
        "unit": "Day(s)"
      },
      {
        "interventionType": "Psychosocial Activity"
      },
      {
        "interventionType": "Household Chores",
        "duration": 3,
        "unit": "Day(s)"
      }
    ]
  }
}
```

**Response**: (201 Created)
```json
{
  "success": true,
  "data": {
    "id": "VG-001",
    "name": "Making noise during study time",
    ...
  }
}
```

### 4. Update Violation Guide
```
PUT /api/violation-guide/:id
Authorization: Bearer token
Content-Type: application/json
```

**Required Authorization**: centerhead, socialworker, psychologist

**Request Body**: (all fields optional)
```json
{
  "name": "Updated name",
  "category": "Major",
  "description": "Updated description",
  "status": "Inactive",
  "interventions": { ... }
}
```

**Response**: (200 OK)
```json
{
  "success": true,
  "data": { ... }
}
```

### 5. Delete Violation Guide (Soft Delete)
```
DELETE /api/violation-guide/:id
Authorization: Bearer token
```

**Required Authorization**: centerhead, socialworker, psychologist

**Response**: (200 OK)
```json
{
  "success": true,
  "message": "Violation guide marked as inactive"
}
```

### 6. Get All Intervention Types
```
GET /api/violation-guide/intervention-types
```

**Response**:
```json
{
  "success": true,
  "data": [
    {
      "id": "IT001",
      "type": "Privilege Suspension",
      "description": "Suspension of privileges such as tablet, TV, or music",
      "requiresDuration": true
    },
    {
      "id": "IT002",
      "type": "Psychosocial Activity",
      "description": "Psychosocial intervention and counseling sessions",
      "requiresDuration": false
    },
    ...
  ],
  "count": 8
}
```

### 7. Assign Interventions to Resident
```
POST /api/violation-guide/assign-interventions
Authorization: Bearer token
Content-Type: application/json
```

**Required Authorization**: centerhead, socialworker, psychologist

**Request Body**:
```json
{
  "residentId": "CHILD-001",
  "violationId": "VIO-12345",
  "guideId": "VG-001",
  "offenseLevel": "1st"
}
```

**Response**: (201 Created)
```json
{
  "success": true,
  "data": [
    {
      "id": "IT-001",
      "interventionType": "Privilege Suspension",
      "duration": 1,
      "unit": "Day(s)"
    },
    {
      "id": "IT-002",
      "interventionType": "Psychosocial Activity"
    }
  ],
  "message": "Interventions assigned to resident"
}
```

### 8. Get Resident Interventions
```
GET /api/violation-guide/resident/:residentId/interventions
```

**Query Parameters**:
- `status` (optional): Filter by 'Pending', 'In Progress', or 'Completed'

**Response**:
```json
{
  "success": true,
  "data": [
    {
      "id": "IT-001",
      "residentId": "CHILD-001",
      "violationId": "VIO-12345",
      "guideId": "VG-001",
      "offenseLevel": "1st",
      "interventionType": "Privilege Suspension",
      "duration": 1,
      "unit": "Day(s)",
      "status": "Pending",
      "startDate": null,
      "completionDate": null,
      "notes": null,
      "completedBy": null,
      "createdAt": "2026-09-01T10:00:00Z",
      "updatedAt": "2026-09-01T10:00:00Z"
    }
  ],
  "count": 2
}
```

### 9. Update Intervention Status
```
PUT /api/violation-guide/intervention-tracker/:id
Authorization: Bearer token
Content-Type: application/json
```

**Required Authorization**: centerhead, socialworker, psychologist

**Request Body**:
```json
{
  "status": "In Progress",
  "notes": "Started on schedule"
}
```

Or mark as completed:
```json
{
  "status": "Completed",
  "notes": "Completed successfully"
}
```

**Response**: (200 OK)
```json
{
  "success": true,
  "data": {
    "id": "IT-001",
    "status": "Completed",
    "completionDate": "2026-09-02T15:30:00Z",
    "completedBy": "psychologist",
    "notes": "Completed successfully",
    ...
  }
}
```

## Error Responses

### 400 Bad Request
```json
{
  "success": false,
  "message": "Violation name is required"
}
```

### 401 Unauthorized
```json
{
  "success": false,
  "message": "Unauthorized"
}
```

### 403 Forbidden
```json
{
  "success": false,
  "message": "Insufficient permissions"
}
```

### 404 Not Found
```json
{
  "success": false,
  "message": "Violation guide not found"
}
```

### 500 Internal Server Error
```json
{
  "success": false,
  "message": "Internal server error"
}
```

## Data Models

### Violation Guide
```typescript
interface ViolationGuide {
  id: string;
  name: string;
  category: 'Minor' | 'Major';
  description?: string;
  status: 'Active' | 'Inactive';
  createdBy: string;
  updatedBy?: string;
  createdAt: DateTime;
  updatedAt: DateTime;
  interventions?: {
    '1st': Intervention[];
    '2nd': Intervention[];
    '3rd': Intervention[];
  };
}
```

### Intervention (in Guide)
```typescript
interface Intervention {
  id: string;
  guideId: string;
  offenseLevel: '1st' | '2nd' | '3rd';
  interventionType: string;
  duration?: number;
  unit?: string; // 'Day(s)', 'Week(s)', 'Month(s)', 'Hour(s)'
  metadata?: Record<string, any>;
  createdAt: DateTime;
  updatedAt: DateTime;
}
```

### Intervention Tracker
```typescript
interface InterventionTracker {
  id: string;
  residentId: string;
  violationId: string;
  guideId: string;
  offenseLevel: '1st' | '2nd' | '3rd';
  interventionType: string;
  duration?: number;
  unit?: string;
  status: 'Pending' | 'In Progress' | 'Completed';
  startDate?: Date;
  completionDate?: Date;
  notes?: string;
  completedBy?: string;
  createdAt: DateTime;
  updatedAt: DateTime;
}
```

### Intervention Type
```typescript
interface InterventionType {
  id: string;
  type: string;
  description?: string;
  requiresDuration: boolean;
  createdAt: DateTime;
}
```

## Usage Examples

### Create a Violation Guide with cURL
```bash
curl -X POST http://localhost:5000/api/violation-guide \
  -H "Authorization: Bearer your_token" \
  -H "Content-Type: application/json" \
  -d '{
    "name": "Making noise during study time",
    "category": "Minor",
    "description": "Creating disturbance during quiet hours",
    "status": "Active",
    "interventions": {
      "1st": [
        {"interventionType": "Privilege Suspension", "duration": 1, "unit": "Day(s)"},
        {"interventionType": "Psychosocial Activity"}
      ],
      "2nd": [
        {"interventionType": "Privilege Suspension", "duration": 2, "unit": "Day(s)"},
        {"interventionType": "Psychosocial Activity"}
      ],
      "3rd": [
        {"interventionType": "Privilege Suspension", "duration": 3, "unit": "Day(s)"},
        {"interventionType": "Psychosocial Activity"},
        {"interventionType": "Household Chores", "duration": 3, "unit": "Day(s)"}
      ]
    }
  }'
```

### Get All Guides
```bash
curl -X GET http://localhost:5000/api/violation-guide \
  -H "Authorization: Bearer your_token"
```

### Get Specific Guide
```bash
curl -X GET http://localhost:5000/api/violation-guide/VG-001 \
  -H "Authorization: Bearer your_token"
```

### Assign Interventions to Resident
```bash
curl -X POST http://localhost:5000/api/violation-guide/assign-interventions \
  -H "Authorization: Bearer your_token" \
  -H "Content-Type: application/json" \
  -d '{
    "residentId": "CHILD-001",
    "violationId": "VIO-12345",
    "guideId": "VG-001",
    "offenseLevel": "2nd"
  }'
```

### Get Resident Interventions
```bash
curl -X GET "http://localhost:5000/api/violation-guide/resident/CHILD-001/interventions?status=Pending" \
  -H "Authorization: Bearer your_token"
```

### Update Intervention Status
```bash
curl -X PUT http://localhost:5000/api/violation-guide/intervention-tracker/IT-001 \
  -H "Authorization: Bearer your_token" \
  -H "Content-Type: application/json" \
  -d '{
    "status": "Completed",
    "notes": "Completed on schedule"
  }'
```
