/**
 * Database Seeding Script
 * @description Creates default users if they don't exist
 */

const bcrypt = require('bcrypt');
const { pool } = require('../config/database');

const DEFAULT_USERS = [
  { id: 'U001', username: 'centerhead', password: 'centerhead123', role: 'centerhead', status: 'Active' },
  { id: 'U002', username: 'socialworker', password: 'social123', role: 'socialworker', status: 'Active' },
  { id: 'U003', username: 'psychologist', password: 'psych123', role: 'psychologist', status: 'Active' },
  { id: 'U004', username: 'nurse', password: 'nurse123', role: 'nurse', status: 'Active' },
  { id: 'U005', username: 'educator', password: 'educator123', role: 'educator', status: 'Active' },
];

async function ensureViolationGuideTables() {
  await pool.query(`
    CREATE TABLE IF NOT EXISTS violation_guide (
      id VARCHAR(40) PRIMARY KEY,
      name VARCHAR(150) NOT NULL,
      category ENUM('Minor', 'Major') NOT NULL DEFAULT 'Minor',
      description TEXT NULL,
      status ENUM('Active', 'Inactive') NOT NULL DEFAULT 'Active',
      createdBy VARCHAR(100) NOT NULL,
      createdAt TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
      updatedAt TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
      updatedBy VARCHAR(100) NULL,
      INDEX idx_status (status),
      INDEX idx_category (category)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
  `);

  await pool.query(`
    CREATE TABLE IF NOT EXISTS intervention_types (
      id VARCHAR(40) PRIMARY KEY,
      type VARCHAR(100) NOT NULL UNIQUE,
      description TEXT NULL,
      requiresDuration BOOLEAN NOT NULL DEFAULT TRUE,
      createdAt TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
  `);

  await pool.query(`
    CREATE TABLE IF NOT EXISTS guide_interventions (
      id VARCHAR(40) PRIMARY KEY,
      guideId VARCHAR(40) NOT NULL,
      offenseLevel VARCHAR(50) NOT NULL,
      interventionType VARCHAR(100) NOT NULL,
      duration INT NULL,
      unit VARCHAR(50) NULL,
      metadata JSON NULL,
      createdAt TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
      updatedAt TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
      FOREIGN KEY (guideId) REFERENCES violation_guide(id) ON DELETE CASCADE,
      INDEX idx_guideId (guideId),
      INDEX idx_offenseLevel (offenseLevel)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
  `);
  await pool.query(`ALTER TABLE guide_interventions MODIFY COLUMN offenseLevel VARCHAR(50) NOT NULL`);

  await pool.query(`
    INSERT INTO intervention_types (id, type, description, requiresDuration)
    VALUES
      ('IT001', 'Privilege Suspension', 'Suspension of privileges such as tablet, TV, or music', TRUE),
      ('IT002', 'Psychosocial Activity', 'Psychosocial intervention and counseling sessions', FALSE),
      ('IT003', 'Household Chores', 'Assignment of household chores', TRUE),
      ('IT004', 'Cleaning', 'Cleaning assignment for specific areas', TRUE),
      ('IT005', 'Confiscation', 'Confiscation of items with return/safekeeping options', FALSE),
      ('IT006', 'Dialogue/Counseling', 'Dialogue or counseling session', FALSE),
      ('IT007', 'Referral', 'Referral to specialist or staff member', FALSE),
      ('IT008', 'Other', 'Other interventions', FALSE)
    ON DUPLICATE KEY UPDATE
      description = VALUES(description),
      requiresDuration = VALUES(requiresDuration)
  `);
}

const OFFICIAL_VIOLATION_GUIDE = [
  {
    id: 'VG001',
    name: 'Pagtangkang Tumakas / Pagtakas (Escape Attempt)',
    category: 'Major',
    description: 'Pagpaplano at pagyayakag sa Pagtakas',
    interventions: {
      '1st': ['No resistance: 1 meal HHC + Privilege suspension + Psychosocial activity + 3 days isolation', 'With resistance: 1 day household chores + Privilege suspension + Psychosocial activity + 3 days isolation'],
      '2nd': ['Blotter + Case filing + Guardian notification + Court notification'],
      '3rd': ['Blotter + Case filing + Guardian notification + Court notification'],
    },
  },
  {
    id: 'VG002',
    name: 'Pagpasok ng Pera at Phone',
    category: 'Major',
    description: 'Pag gamit at pagpasok ng Pera at Phone',
    interventions: {
      '1st': ['2 weeks Privilege Suspension + Psychosocial activity'],
      '2nd': ['2 weeks Privilege Suspension + 2 days household chores + Psychosocial activity'],
      '3rd': ['2 weeks Privilege Suspension + 2 days household chores + Laundry of bedsheets & towels + Psychosocial activity'],
    },
  },
  {
    id: 'VG003',
    name: 'Pagpasok ng Alak at Sigarilyo',
    category: 'Major',
    description: 'Pag gamit at pagpasok ng Alak at Sigarilyo',
    interventions: {
      '1st': ['2 weeks Privilege Suspension + 1 day household chores + Psychosocial activity'],
      '2nd': ['2 weeks Privilege Suspension + 3 days household chores + Psychosocial activity'],
      '3rd': ['2 weeks Privilege Suspension + 3 days household chores + Laundry of bedsheets & towels + Psychosocial activity'],
    },
  },
  {
    id: 'VG004',
    name: 'Paggamit ng Droga sa Shelter',
    category: 'Major',
    description: 'Pag gamit at pagpasok ng Droga sa shelter',
    interventions: {
      '1st': ['Drug test + Blotter + Case filing'],
      '2nd': ['Drug test + Blotter + Case filing'],
      '3rd': ['Drug test + Blotter + Case filing'],
    },
  },
  {
    id: 'VG005',
    name: 'Paggamit ng Tablet (Hindi Ayon sa Rules / Social Media)',
    category: 'Major',
    description: 'Pag gamit ng tablet na hindi naaayon; pag log in sa social media accounts',
    interventions: {
      '1st': ['2 weeks Privilege Suspension + 2 weeks no tablet use + Psychosocial activities'],
      '2nd': ['2 weeks Privilege Suspension + 2 days household chores + 3 weeks no use of tablet + Psychosocial activities'],
      '3rd': ['3 weeks Privilege Suspension + 3 days household chores + 1 month no use of tablet + Psychosocial activity'],
    },
  },
  {
    id: 'VG006',
    name: 'Pakikipag-away / Pananakit / Pakikipagsuntukan (Fighting)',
    category: 'Major',
    description: 'Halimbawa: sparring, pengkoy, pitikan, sapukan, pang-uulok na nagresulta sa away at iba pa',
    interventions: {
      '1st': ['1 day household chores + Laundry of bedsheets and towels + 1 week privilege suspension + Psychosocial activity'],
      '2nd': ['1 day isolation + 2 days household chores + 3 weeks privilege suspension + Psychosocial activity'],
      '3rd': ['2 days isolation + 2 weeks Privilege Suspension + 3 days household chores + Psychosocial activity (*Referral to psychologist or social worker; *Court filing and shoulder the medical expenses)'],
    },
  },
  {
    id: 'VG007',
    name: 'Pagsira ng Anumang Uri ng Gamit sa Shelter (Property Damage)',
    category: 'Major',
    description: 'Pagsira ng anumang uri ng gamit sa shelter',
    interventions: {
      '1st': ['Pagpalit/Pagbayad ng nasirang gamit & character building + counseling'],
      '2nd': ['Pagpalit/Pagbayad ng nasirang gamit + 2 days isolation + privilege suspension + psychosocial activity'],
      '3rd': ['Pagpalit/Pagbayad ng nasirang gamit + 1 week Privilege Suspension + psychosocial activity'],
    },
  },
  {
    id: 'VG008',
    name: 'Pagbasag ng Salamin / Paggawa ng Sandata (Dangerous Object)',
    category: 'Major',
    description: 'Pagbasag ng salamin at pagputol ng toothbrush na maaring gamiting panaksak at panganib na matutulis na bagay sa loob ng shelter',
    interventions: {
      '1st': ['Pagpalit/Pagbayad ng nasirang gamit & 1 day isolation + privilege suspension + psychosocial activity'],
      '2nd': ['Pagpalit/Pagbayad ng nasirang gamit + 2 days isolation + privilege suspension + psychosocial activity'],
      '3rd': ['Pagpalit/Pagbayad + 3 days isolation + 2 weeks Privilege Suspension + psychosocial activity (*Family will shoulder all the required treatment/medication)'],
    },
  },
  {
    id: 'VG009',
    name: 'Paglalagay ng Tattoo / Piercing / Bulitas',
    category: 'Major',
    description: 'Paglalagay ng tattoo at piercing o bulitas sa anumang bahagi ng katawan',
    interventions: {
      '1st': ['Laundry of Bedsheets and towels + psychosocial activity'],
      '2nd': ['Laundry of Bedsheets and towels + 1 week privilege suspension + psychosocial activity'],
      '3rd': ['Laundry of Bedsheets and towels + 2 weeks Privilege suspension + psychosocial activity (*SCH will not be liable for the treatment/medication)'],
    },
  },
  {
    id: 'VG010',
    name: 'Pagkuha ng Supplies ng Shelter (Food/Kubyertos/Appliance)',
    category: 'Major',
    description: 'Pagkuha ng supplies ng shelter gaya ng pagkain, kubyertos, parte ng appliance (bullpen, pentelpen)',
    interventions: {
      '1st': ['1 day household chores + Laundry of bedsheets and towels + psychosocial activity'],
      '2nd': ['2 days household chores + Laundry of bedsheets and towels + psychosocial activity'],
      '3rd': ['3 days household chores + Laundry of bedsheets and towels + privilege suspension + psychosocial activity'],
    },
  },
  {
    id: 'VG011',
    name: 'Pagkuha ng Gamit ng Kapwa Residente (Meryenda/Damit)',
    category: 'Major',
    description: 'Pagkuha ng kagamitan ng kapwa residente tulad ng meryenda, damit o ibang gamit',
    interventions: {
      '1st': ['2 days household chores + Laundry of bedsheets and towels + psychosocial activity'],
      '2nd': ['3 days household chores + Laundry of bedsheets and towels + psychosocial activity'],
      '3rd': ['4 days household + Laundry of bedsheets and towels + privilege suspension + psychosocial activity'],
    },
  },
  {
    id: 'VG012',
    name: 'Kawalang Respeto sa Kapwa Residente/Staff/Bisita (Pagmumura/Panlalait)',
    category: 'Major',
    description: 'Pagmumura, panlalait at pambabastos',
    interventions: {
      '1st': ['1 day household chores + 1 week privilege suspension + character building + counseling'],
      '2nd': ['2 days household chores + 2 weeks privilege suspension + character building + counseling'],
      '3rd': ['3 days household chores + 1 month privilege suspension + character building + counseling + 1 day isolation'],
    },
  },
  {
    id: 'VG013',
    name: 'Sexually Deviant Behavior',
    category: 'Major',
    description: 'Pagmamasturbate in public, pagpapakita ng ari, pakikiapid, oral and anal contact',
    interventions: {
      '1st': ['Subject for medical and/or psychological check-up / treatment; Subject for case conference; The offended party might seek legal advice or take legal action against the offender. (*Referral to psychologist or social worker)'],
      '2nd': ['Subject for medical and/or psychological check-up / treatment; Subject for case conference; The offended party might seek legal advice or take legal action against the offender. (*Referral to psychologist or social worker)'],
      '3rd': ['Subject for medical and/or psychological check-up / treatment; Subject for case conference; The offended party might seek legal advice or take legal action against the offender. (*Referral to psychologist or social worker)'],
    },
  },
  {
    id: 'VG014',
    name: 'Pagtanggi na Pumirma at Gawin ang Intervention',
    category: 'Major',
    description: 'Pagtanggi na gumawa ng itinakdang intervention',
    interventions: {
      '1st': ['Verbal warning (still required to do the intervention) + psychosocial activity'],
      '2nd': ['1 week no video call/visitation (still required to do the intervention)'],
      '3rd': ['2 weeks no video call/visitation (still required to do the intervention)'],
    },
  },
  {
    id: 'VG015',
    name: 'Pagsuwway sa Schedule at di Pagsali sa Activities',
    category: 'Minor',
    description: 'Pagsuwway sa schedule ng mga activities tulad ng tutorials, exercise at psychosocial activities',
    interventions: {
      '1st': ['2 days no watching tv (no involvement in music activity) + psychosocial activity'],
      '2nd': ['4 days no watching tv (no involvement in music activity) + 3 mins video call/phone call + psychosocial activity'],
      '3rd': ['1 week privilege suspension + psychosocial activity'],
    },
  },
  {
    id: 'VG016',
    name: 'Pagbubukas ng Appliances sa mga Kwarto (Walang Pahintulot)',
    category: 'Minor',
    description: 'Pagpasok sa storage room at office walang pahintulot; pagpasok sa CR habang may tao',
    interventions: {
      '1st': ['1 day CR cleaning (down) + psychosocial activity'],
      '2nd': ['2 days CR cleaning (up and down) + psychosocial activity'],
      '3rd': ['3 days CR cleaning (up and down) + psychosocial activity'],
    },
  },
  {
    id: 'VG017',
    name: 'Pagsusuot ng Anumang Uri ng Alahas/Palamuti',
    category: 'Minor',
    description: 'Pagsusuot ng relo, kwintas, anklet, singsing, sombrero at iba pa',
    interventions: {
      '1st': ['Confiscate at ipapauwi sa magulang + psychosocial activity'],
      '2nd': ['Confiscate and safe keeping + psychosocial activity'],
      '3rd': ['Confiscate and safe keeping + laundry of bedsheets and towels + psychosocial activity'],
    },
  },
  {
    id: 'VG018',
    name: 'Paghingi ng Pansariling Interest sa Kapwa Residente / Pakikipagpalit ng Gamit',
    category: 'Minor',
    description: 'Hindi ito pwedeng dalhan ng nagirang gamit',
    interventions: {
      '1st': ['Pawiin sa pamilitan o in-arbor sa kapwa residente. (*Referral to psychologist or social worker)'],
      '2nd': ['Pawiin sa pamilitan o in-arbor sa kapwa residente. (*Referral to psychologist or social worker)'],
      '3rd': ['Pawiin sa pamilitan o in-arbor sa kapwa residente. (*Referral to psychologist or social worker)'],
    },
  },
  {
    id: 'VG019',
    name: 'Pag-iingay sa Oras ng Pag-aaral',
    category: 'Minor',
    description: 'Pag-aaral',
    interventions: {
      '1st': ['1 day no using of tablet during study time + psychosocial activity + 1 day household chores'],
      '2nd': ['2 days no using of tablet during study time + psychosocial activity + 2 days household chores'],
      '3rd': ['3 days no using of tablet during study time + psychosocial activity + 3 days household chores'],
    },
  },
  {
    id: 'VG020',
    name: 'Pag-iingay sa Oras ng Panonood ng TV',
    category: 'Minor',
    description: 'Panonood ng tv',
    interventions: {
      '1st': ['1 day no watching tv (no involvement in music activity) + psychosocial activity'],
      '2nd': ['2 days no watching tv (no involvement in music activity) + psychosocial activity'],
      '3rd': ['3 days no watching tv (no involvement in music activity) + privilege suspension + psychosocial activity'],
    },
  },
  {
    id: 'VG021',
    name: 'Pag-iingay sa Oras ng Pagtulog',
    category: 'Minor',
    description: 'Pagtulog',
    interventions: {
      '1st': ['1 day no nap time + psychosocial activity'],
      '2nd': ['2 days no nap time + psychosocial activity'],
      '3rd': ['3 days no nap time + privilege suspension + psychosocial activity'],
    },
  },
  {
    id: 'VG022',
    name: 'Pagtago ng Pagkain sa Kwarto',
    category: 'Minor',
    description: 'Pagtago ng pagkain sa kwarto',
    interventions: {
      '1st': ['No merienda sa susunod na araw at huling kakain'],
      '2nd': ['1 week no merienda + privilege suspension'],
      '3rd': ['1 month privilege suspension during last Wednesday'],
    },
  },
  {
    id: 'VG023',
    name: 'Late Gumising / Pagligo ng Sabay at Pagligo ng Wala sa Oras',
    category: 'Minor',
    description: 'Late gumising, pagligo ng sabay o wala sa oras',
    interventions: {
      '1st': ['Huling kalain at 1 day household chores'],
      '2nd': ['Huling kalain at 1 day household chores'],
      '3rd': ['Huling kalain at 1 day household chores'],
    },
  },
  {
    id: 'VG024',
    name: 'Hindi Pagkain sa Takdang Oras (not unless sick)',
    category: 'Minor',
    description: 'Hindi pagkain sa takdang oras maliban sa sakit',
    interventions: {
      '1st': ['Ipakainin ang kanyang pagkain sa mga kapwa residente'],
      '2nd': ['Ipakainin ang kanyang pagkain sa mga kapwa residente'],
      '3rd': ['Ipakainin ang kanyang pagkain sa mga kapwa residente'],
    },
  },
  {
    id: 'VG025',
    name: 'Kawalang Respeto sa Hapag-Kainan',
    category: 'Minor',
    description: 'Pag-aayos ng hapag-kainan, paglalaro habang nag-aalmusal, pag-aaksa sa Pagkatapon ng Pagkain',
    interventions: {
      '1st': ['Half rice and half ulam on a current meal and on the following meals, huling kakain at cleaning of dining area'],
      '2nd': ['Half rice and half ulam on the following meals, huling kakain at cleaning of dining area'],
      '3rd': ['Half rice and half ulam on the following meals, huling kakain at 2days household chores'],
    },
  },
  {
    id: 'VG026',
    name: 'Vandalism',
    category: 'Minor',
    description: 'Pagsulat/pagkuha ng mga sulat sa pader at pagbili ng 1 litro ng puting pintura',
    interventions: {
      '1st': ['Pagsulat/pagkuha ng mga sulat sa pader at pagbili ng 1 Litro ng puting pintura'],
      '2nd': ['Pagsulat/pagkuha ng mga sulat sa pader at pagbili ng 1 Litro ng puting pintura'],
      '3rd': ['Pagsulat/pagkuha ng mga sulat sa pader at pagbili ng 1 Litro ng puting pintura'],
    },
  },
  {
    id: 'VG027',
    name: 'Paglalagi sa Baba ng Hindi Naman Toka sa Paglalaba / Hindi Naman Oras ng Panonood',
    category: 'Minor',
    description: 'Paglalagi sa viewing area ng hindi naman oras ng panonood',
    interventions: {
      '1st': ['Verbal warning + dialogue'],
      '2nd': ['1 day cleaning of receiving area + psychosocial activity'],
      '3rd': ['3 days cleaning of receiving area + psychosocial activity'],
    },
  },
  {
    id: 'VG028',
    name: 'Walang Pantaas na Damit / Pag Hubo at Nakaboxer Shorts (except nap time or bed time at washing dishes)',
    category: 'Minor',
    description: 'Maliban sa nap time, bed time at washing dishes at laundry area',
    interventions: {
      '1st': ['Verbal warning + dialogue'],
      '2nd': ['1 day cleaning of laundry area + psychosocial activity'],
      '3rd': ['3 days cleaning of laundry area + psychosocial activity'],
    },
  },
  {
    id: 'VG029',
    name: 'Hindi Pag-ayos ng Higaan / Pagsalansan ng mga Gamit sa Kusina',
    category: 'Minor',
    description: 'Hindi pag-ayos ng higaan o pagsalansan ng gamit sa kusina pagkatapos ng nap time or bed time (not unless sick)',
    interventions: {
      '1st': ['Pagsamsam ng unan'],
      '2nd': ['Pagsamsam ng kutson'],
      '3rd': ['Pagsamsam ng unan at kutson'],
    },
  },
  {
    id: 'VG030',
    name: 'Pagsabit ng Kung Anu-ano sa Bintana ng Bawat Room',
    category: 'Minor',
    description: 'Pagsabit ng kung anu-ano sa bintana ng bawat room',
    interventions: {
      '1st': ['Pagsamsam ng nagpapauwi kung anumang gamit na nakasabit'],
      '2nd': ['Pagsamsam ng nagpapauwi kung anumang gamit na nakasabit'],
      '3rd': ['Pagsamsam ng nagpapauwi kung anumang gamit na nakasabit'],
    },
  },
  {
    id: 'VG031',
    name: 'Pagsilip at Pakikipag-usap sa Kapwa Residente sa Ibang Silid',
    category: 'Minor',
    description: 'Pagsilip at pakikipag-usap sa kapwa residente sa ibang silid',
    interventions: {
      '1st': ['No phone call / video call'],
      '2nd': ['Psychosocial activity'],
      '3rd': ['Pagsasamom ng unan at kutson'],
    },
  },
];

function normalizeOffenseLabel(label, detail = '') {
  if (!label) return 'Set Intervention';

  const normalized = String(label).trim();
  const lower = normalized.toLowerCase();
  const text = String(detail || '').toLowerCase();

  if (lower.includes('1st')) return '1st';
  if (lower.includes('2nd')) return '2nd';
  if (lower.includes('3rd')) return '3rd';
  if (text.includes('same as')) return '1st';
  if (text.includes('same')) return '1st';
  if (text.includes('no resistance')) return 'No Resistance';
  if (text.includes('with resistance')) return 'With Resistance';
  if (lower.includes('set intervention')) return 'Set Intervention';
  if (lower.includes('no resistance')) return 'No Resistance';
  if (lower.includes('with resistance')) return 'With Resistance';

  return normalized || 'Set Intervention';
}

function normalizeInterventionType(rawText) {
  if (!rawText || typeof rawText !== 'string') return 'Other';

  const text = rawText.toLowerCase().trim();
  if (!text) return 'Other';

  if (text.includes('privilege suspension') || text.includes('privilege')) {
    return 'Privilege Suspension';
  }
  if (text.includes('psychosocial activity') || text.includes('psychosocial') || text.includes('counseling') || text.includes('character building') || text.includes('dialogue') || text.includes('counsel')) {
    return 'Psychosocial Activity';
  }
  if (text.includes('household chores') || text.includes('hhc') || text.includes('kitchen chores') || text.includes('1 day household') || text.includes('2 days household') || text.includes('3 days household') || text.includes('4 days household')) {
    return 'Household Chores';
  }
  if (text.includes('cleaning') || text.includes('cr cleaning') || text.includes('laundry of bedsheets') || text.includes('laundry') || text.includes('washing dishes')) {
    return 'Cleaning';
  }
  if (text.includes('confiscate') || text.includes('safe keeping') || text.includes('safe-keeping') || text.includes('confiscation')) {
    return 'Confiscation';
  }
  if (text.includes('referral') || text.includes('psychologist') || text.includes('social worker')) {
    return 'Referral';
  }
  if (text.includes('court filing') || text.includes('case filing') || text.includes('blotter') || text.includes('guardian notification') || text.includes('court notification')) {
    return 'Other';
  }
  if (text.includes('verbal warning') || text.includes('warning')) {
    return 'Other';
  }
  if (text.includes('same as') || text.includes('same')) {
    return 'Same';
  }
  if (text.includes('no tablet use') || text.includes('no use of tablet') || text.includes('no watching tv') || text.includes('no video call') || text.includes('no merienda') || text.includes('no nap time')) {
    return 'Privilege Suspension';
  }

  return 'Other';
}

function splitOfficialInterventionEntries(detail, previousFirstOffense = []) {
  if (!detail || typeof detail !== 'string') return [];

  const text = detail.trim();
  if (!text) return [];

  if (text.toLowerCase().includes('same')) {
    return [...new Set(previousFirstOffense.map((item) => item))];
  }

  const rawSegments = text
    .split(/[+&;\n]/)
    .map((segment) => segment.trim())
    .filter(Boolean);

  const uniqueEntries = [];
  const seen = new Set();

  for (const segment of rawSegments) {
    const normalized = normalizeInterventionType(segment);
    if (!normalized) continue;
    if (!seen.has(normalized)) {
      uniqueEntries.push(normalized);
      seen.add(normalized);
    }
  }

  if (uniqueEntries.length > 0) {
    return uniqueEntries;
  }

  return ['Other'];
}

async function seedOfficialViolationGuide() {
  try {
    await ensureViolationGuideTables();

    const [existingGuideRows] = await pool.query('SELECT id FROM violation_guide');
    if (existingGuideRows.length > 0) {
      console.log('Refreshing existing official violation guide data...');
      await pool.query('DELETE FROM guide_interventions');
      await pool.query('DELETE FROM violation_guide');
    }

    for (const guide of OFFICIAL_VIOLATION_GUIDE) {
      await pool.query(
        `INSERT INTO violation_guide (id, name, category, description, status, createdBy, updatedBy)
         VALUES (?, ?, ?, ?, 'Active', 'system', 'system')`,
        [guide.id, guide.name, guide.category, guide.description]
      );

      const previousFirstOffense = [];
      const offenseLevels = Object.entries(guide.interventions || {});
      for (const [offenseLevel, items] of offenseLevels) {
        for (const [index, detail] of items.entries()) {
          const normalizedOffenseLevel = normalizeOffenseLabel(offenseLevel, detail);
          const numericIndex = Number(guide.id.replace('VG', '')) * 100;
          const offenseWeight = ['1st', '2nd', '3rd'].includes(normalizedOffenseLevel) ? { '1st': 1, '2nd': 2, '3rd': 3 }[normalizedOffenseLevel] : 1;
          const interventionTypes = splitOfficialInterventionEntries(detail, previousFirstOffense);

          if (normalizedOffenseLevel === '1st' && interventionTypes.length > 0) {
            previousFirstOffense.length = 0;
            previousFirstOffense.push(...interventionTypes);
          }

          for (const [localIndex, interventionType] of interventionTypes.entries()) {
            const interventionId = `GI${Date.now().toString(36).toUpperCase()}${Math.random().toString(36).slice(2, 8).toUpperCase()}${String(localIndex + 1).padStart(3, '0')}`;
            const customType = interventionType === 'Other' ? detail.trim() : null;

            await pool.query(
              `INSERT INTO guide_interventions (id, guideId, offenseLevel, interventionType, duration, unit, metadata)
               VALUES (?, ?, ?, ?, ?, ?, ?)`,
              [
                interventionId,
                guide.id,
                normalizedOffenseLevel,
                interventionType,
                null,
                null,
                JSON.stringify({ officialText: detail, customType }),
              ]
            );
          }
        }
      }
    }

    console.log('✅ Official SCH violation guide seeded successfully');
  } catch (error) {
    console.error('❌ Official SCH violation guide seed failed:', error.message);
  }
}

async function seedDatabase() {
  try {
    console.log('Checking default users...');
    
    for (const user of DEFAULT_USERS) {
      const [existing] = await pool.query('SELECT id FROM users WHERE username = ?', [user.username]);
      
      if (existing.length === 0) {
        const hashedPassword = await bcrypt.hash(user.password, 10);
        await pool.query(
          'INSERT INTO users (id, username, password, role, status, createdDate, accessibleModules) VALUES (?, ?, ?, ?, ?, NOW(), ?)',
          [user.id, user.username, hashedPassword, user.role, user.status, JSON.stringify([])]
        );
        console.log(`✅ Created user: ${user.username}`);
      } else {
        const [row] = await pool.query('SELECT password FROM users WHERE username = ?', [user.username]);
        const stored = row[0]?.password;
        if (stored && !stored.startsWith('$2')) {
          const hashedPassword = await bcrypt.hash(user.password, 10);
          await pool.query('UPDATE users SET password = ? WHERE username = ?', [hashedPassword, user.username]);
          console.log(`🔒 Rehashed legacy password for: ${user.username}`);
        }
        console.log(`✓ User exists: ${user.username}`);
      }
    }

    await seedOfficialViolationGuide();
    console.log('Database seeding complete!');
  } catch (error) {
    console.error('Seeding failed:', error.message);
  }
}

module.exports = { seedDatabase };
