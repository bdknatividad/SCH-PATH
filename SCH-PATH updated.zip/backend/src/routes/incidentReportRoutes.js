/**
 * Incident Report Routes
 * @module routes/incidentReportRoutes
 * @description Digital Form 08 — create, fetch, and verify incident reports
 */

const express = require('express');
const router = express.Router();
const incidentReportController = require('../controllers/incidentReportController');
const { asyncHandler } = require('../middleware/errorHandler');
const { authorize } = require('../middleware/auth');

/**
 * POST /api/incident-reports
 * Social Worker saves a completed digital Incident Report against a violation.
 */
router.post('/', authorize('socialworker', 'centerhead'), asyncHandler(incidentReportController.create));

/**
 * GET /api/incident-reports/violation/:violationId
 * Fetch the incident report tied to a specific violation.
 */
router.get('/violation/:violationId', asyncHandler(incidentReportController.getByViolationId));

/**
 * GET /api/incident-reports/resident/:residentId
 * List incident reports for a resident.
 */
router.get('/resident/:residentId', asyncHandler(incidentReportController.getByResidentId));

/**
 * POST /api/incident-reports/:id/verify
 * Psychologist verifies the report and selects the intervention.
 */
router.post('/:id/verify', authorize('psychologist', 'centerhead'), asyncHandler(incidentReportController.verify));

module.exports = router;
