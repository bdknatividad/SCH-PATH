/**
 * Violation Guide Routes
 * @module routes/violationGuideRoutes
 * @description Routes for managing Violation & Intervention Guide
 */

const express = require('express');
const router = express.Router();
const violationGuideController = require('../controllers/violationGuideController');
const { asyncHandler } = require('../middleware/errorHandler');
const { authorize } = require('../middleware/auth');

/**
 * GET /api/violation-guide
 * Get all violation guides
 */
router.get('/', asyncHandler(violationGuideController.getAll));

/**
 * GET /api/violation-guide/intervention-types
 * Get all intervention types (must be before /:id)
 */
router.get('/intervention-types', asyncHandler(violationGuideController.getInterventionTypes));

/**
 * GET /api/violation-guide/resident/:residentId/interventions
 * Get intervention tracker for a resident (must be before /:id)
 */
router.get(
  '/resident/:residentId/interventions',
  asyncHandler(violationGuideController.getResidentInterventions)
);

/**
 * POST /api/violation-guide/assign-interventions
 * Assign interventions to a resident based on violation (must be before /:id POST)
 * Requires: centerhead, socialworker, psychologist
 */
router.post(
  '/assign-interventions',
  authorize('centerhead', 'socialworker', 'psychologist'),
  asyncHandler(violationGuideController.assignInterventions)
);

/**
 * GET /api/violation-guide/:id
 * Get violation guide by ID with all interventions
 */
router.get('/:id', asyncHandler(violationGuideController.getById));

/**
 * POST /api/violation-guide
 * Create new violation guide
 * Requires: centerhead, socialworker, psychologist
 */
router.post(
  '/',
  authorize('centerhead', 'socialworker', 'psychologist'),
  asyncHandler(violationGuideController.create)
);

/**
 * PUT /api/violation-guide/:id
 * Update violation guide
 * Requires: centerhead, socialworker, psychologist
 */
router.put(
  '/:id',
  authorize('centerhead', 'socialworker', 'psychologist'),
  asyncHandler(violationGuideController.update)
);

/**
 * DELETE /api/violation-guide/:id
 * Delete (mark as inactive) violation guide
 * Requires: centerhead, socialworker, psychologist
 */
router.delete(
  '/:id',
  authorize('centerhead', 'socialworker', 'psychologist'),
  asyncHandler(violationGuideController.delete)
);

/**
 * PUT /api/violation-guide/intervention-tracker/:id
 * Update intervention status
 * Requires: centerhead, socialworker, psychologist
 */
router.put(
  '/intervention-tracker/:id',
  authorize('centerhead', 'socialworker', 'psychologist'),
  asyncHandler(violationGuideController.updateInterventionStatus)
);

module.exports = router;
