/**
 * Violation Guide Controller
 * @module controllers/violationGuideController
 * @description Manages Violation & Intervention Guide configuration
 */

const { pool } = require('../config/database');
const { generateId } = require('../utils/helpers');
const { ApiError } = require('../middleware/errorHandler');

/**
 * Get all violation guides with optional filtering
 */
async function getAll(req, res, next) {
  try {
    const { status } = req.query;
    
    let query = 'SELECT * FROM violation_guide';
    const values = [];
    
    if (status) {
      query += ' WHERE status = ?';
      values.push(status);
    }
    
    query += ' ORDER BY createdAt DESC';
    
    const [guides] = await pool.query(query, values);
    
    // Enrich each guide with its interventions
    const enrichedGuides = await Promise.all(
      guides.map(async (guide) => {
        const [interventions] = await pool.query(
          `SELECT * FROM guide_interventions 
           WHERE guideId = ? 
           ORDER BY offenseLevel`,
          [guide.id]
        );
        
        return {
          ...guide,
          interventions: interventions,
        };
      })
    );
    
    res.json({
      success: true,
      data: enrichedGuides,
      count: enrichedGuides.length,
    });
  } catch (error) {
    next(error);
  }
}

/**
 * Get violation guide by ID with all interventions
 */
async function getById(req, res, next) {
  try {
    const { id } = req.params;
    
    const [guides] = await pool.query(
      'SELECT * FROM violation_guide WHERE id = ?',
      [id]
    );
    
    if (guides.length === 0) {
      throw new ApiError(404, 'Violation guide not found');
    }
    
    const guide = guides[0];
    
    // Get all interventions for this guide
    const [interventions] = await pool.query(
      `SELECT * FROM guide_interventions 
       WHERE guideId = ? 
       ORDER BY offenseLevel`,
      [id]
    );
    
    // Group interventions by offense level
    const grouped = {
      '1st': interventions.filter(i => i.offenseLevel === '1st'),
      '2nd': interventions.filter(i => i.offenseLevel === '2nd'),
      '3rd': interventions.filter(i => i.offenseLevel === '3rd'),
    };
    
    res.json({
      success: true,
      data: {
        ...guide,
        interventions: grouped,
      },
    });
  } catch (error) {
    next(error);
  }
}

/**
 * Create new violation guide with interventions
 * 
 * Expected body:
 * {
 *   name: "Making noise during study time",
 *   category: "Minor",
 *   description: "...",
 *   status: "Active",
 *   interventions: {
 *     "1st": [{ interventionType, duration, unit }, ...],
 *     "2nd": [...],
 *     "3rd": [...]
 *   }
 * }
 */
async function create(req, res, next) {
  const connection = await pool.getConnection();
  
  try {
    const { name, category, description, status, interventions } = req.body;
    const userId = req.user?.id || req.user?.username || 'system';
    
    // Validate required fields
    if (!name) {
      throw new ApiError(400, 'Violation name is required');
    }
    
    const guideId = generateId('VG');
    
    // Start transaction
    await connection.beginTransaction();
    
    // Insert violation guide
    await connection.query(
      `INSERT INTO violation_guide (id, name, category, description, status, createdBy, updatedBy)
       VALUES (?, ?, ?, ?, ?, ?, ?)`,
      [guideId, name, category || 'Minor', description, status || 'Active', userId, userId]
    );
    
    // Insert interventions for each offense level
    if (interventions) {
      for (const [offenseLevel, items] of Object.entries(interventions)) {
        if (Array.isArray(items)) {
          for (const item of items) {
            const interventionId = generateId('GI');
            await connection.query(
              `INSERT INTO guide_interventions 
               (id, guideId, offenseLevel, interventionType, duration, unit, metadata)
               VALUES (?, ?, ?, ?, ?, ?, ?)`,
              [
                interventionId,
                guideId,
                offenseLevel,
                item.interventionType,
                item.duration || null,
                item.unit || null,
                item.metadata ? JSON.stringify(item.metadata) : null,
              ]
            );
          }
        }
      }
    }
    
    await connection.commit();
    
    // Fetch and return the created guide
    const [guides] = await pool.query(
      'SELECT * FROM violation_guide WHERE id = ?',
      [guideId]
    );
    
    const [interventionRows] = await pool.query(
      'SELECT * FROM guide_interventions WHERE guideId = ?',
      [guideId]
    );
    
    const grouped = {
      '1st': interventionRows.filter(i => i.offenseLevel === '1st'),
      '2nd': interventionRows.filter(i => i.offenseLevel === '2nd'),
      '3rd': interventionRows.filter(i => i.offenseLevel === '3rd'),
    };
    
    res.status(201).json({
      success: true,
      data: {
        ...guides[0],
        interventions: grouped,
      },
    });
  } catch (error) {
    await connection.rollback();
    next(error);
  } finally {
    connection.release();
  }
}

/**
 * Update violation guide and its interventions
 */
async function update(req, res, next) {
  const connection = await pool.getConnection();
  
  try {
    const { id } = req.params;
    const { name, category, description, status, interventions } = req.body;
    const userId = req.user?.id || req.user?.username || 'system';
    
    await connection.beginTransaction();
    
    // Update guide
    if (name || category !== undefined || description !== undefined || status) {
      const updates = [];
      const values = [];
      
      if (name !== undefined) {
        updates.push('name = ?');
        values.push(name);
      }
      if (category !== undefined) {
        updates.push('category = ?');
        values.push(category);
      }
      if (description !== undefined) {
        updates.push('description = ?');
        values.push(description);
      }
      if (status !== undefined) {
        updates.push('status = ?');
        values.push(status);
      }
      
      updates.push('updatedBy = ?');
      values.push(userId);
      
      updates.push('updatedAt = NOW()');
      
      values.push(id);
      
      await connection.query(
        `UPDATE violation_guide SET ${updates.join(', ')} WHERE id = ?`,
        values
      );
    }
    
    // Update interventions if provided
    if (interventions) {
      // Delete existing interventions
      await connection.query(
        'DELETE FROM guide_interventions WHERE guideId = ?',
        [id]
      );
      
      // Insert new interventions
      for (const [offenseLevel, items] of Object.entries(interventions)) {
        if (Array.isArray(items)) {
          for (const item of items) {
            const interventionId = generateId('GI');
            await connection.query(
              `INSERT INTO guide_interventions 
               (id, guideId, offenseLevel, interventionType, duration, unit, metadata)
               VALUES (?, ?, ?, ?, ?, ?, ?)`,
              [
                interventionId,
                id,
                offenseLevel,
                item.interventionType,
                item.duration || null,
                item.unit || null,
                item.metadata ? JSON.stringify(item.metadata) : null,
              ]
            );
          }
        }
      }
    }
    
    await connection.commit();
    
    // Fetch and return updated guide
    const [guides] = await pool.query(
      'SELECT * FROM violation_guide WHERE id = ?',
      [id]
    );
    
    const [interventionRows] = await pool.query(
      'SELECT * FROM guide_interventions WHERE guideId = ?',
      [id]
    );
    
    const grouped = {
      '1st': interventionRows.filter(i => i.offenseLevel === '1st'),
      '2nd': interventionRows.filter(i => i.offenseLevel === '2nd'),
      '3rd': interventionRows.filter(i => i.offenseLevel === '3rd'),
    };
    
    res.json({
      success: true,
      data: {
        ...guides[0],
        interventions: grouped,
      },
    });
  } catch (error) {
    await connection.rollback();
    next(error);
  } finally {
    connection.release();
  }
}

/**
 * Delete violation guide (soft delete - mark as inactive)
 * or hard delete if status changes to Inactive
 */
async function delete_(req, res, next) {
  try {
    const { id } = req.params;
    
    // Mark as inactive instead of deleting
    await pool.query(
      'UPDATE violation_guide SET status = ? WHERE id = ?',
      ['Inactive', id]
    );
    
    res.json({
      success: true,
      message: 'Violation guide marked as inactive',
    });
  } catch (error) {
    next(error);
  }
}

/**
 * Get all intervention types
 */
async function getInterventionTypes(req, res, next) {
  try {
    const [types] = await pool.query(
      'SELECT * FROM intervention_types ORDER BY type'
    );
    
    res.json({
      success: true,
      data: types,
      count: types.length,
    });
  } catch (error) {
    next(error);
  }
}

/**
 * Assign interventions to a child based on violation
 * This is called after a violation is logged and verified
 * 
 * Expected body:
 * {
 *   residentId: "...",
 *   violationId: "...",
 *   guideId: "...",
 *   offenseLevel: "1st|2nd|3rd"
 * }
 */
async function assignInterventions(req, res, next) {
  const connection = await pool.getConnection();
  
  try {
    const { residentId, violationId, guideId, offenseLevel } = req.body;
    
    if (!residentId || !violationId || !guideId || !offenseLevel) {
      throw new ApiError(400, 'Missing required fields');
    }
    
    await connection.beginTransaction();
    
    // Get interventions for this guide and offense level
    const [interventions] = await pool.query(
      `SELECT * FROM guide_interventions 
       WHERE guideId = ? AND offenseLevel = ?`,
      [guideId, offenseLevel]
    );
    
    // Create tracker entry for each intervention
    const created = [];
    for (const intervention of interventions) {
      const trackerId = generateId('IT');
      
      await connection.query(
        `INSERT INTO intervention_tracker 
         (id, residentId, violationId, guideId, offenseLevel, interventionType, duration, unit, status)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, 'Pending')`,
        [
          trackerId,
          residentId,
          violationId,
          guideId,
          offenseLevel,
          intervention.interventionType,
          intervention.duration,
          intervention.unit,
        ]
      );
      
      created.push({
        id: trackerId,
        interventionType: intervention.interventionType,
        duration: intervention.duration,
        unit: intervention.unit,
      });
    }
    
    await connection.commit();
    
    res.status(201).json({
      success: true,
      data: created,
      message: 'Interventions assigned to resident',
    });
  } catch (error) {
    await connection.rollback();
    next(error);
  } finally {
    connection.release();
  }
}

/**
 * Get intervention tracker for a resident
 */
async function getResidentInterventions(req, res, next) {
  try {
    const { residentId } = req.params;
    const { status } = req.query;
    
    let query = 'SELECT * FROM intervention_tracker WHERE residentId = ?';
    const values = [residentId];
    
    if (status) {
      query += ' AND status = ?';
      values.push(status);
    }
    
    query += ' ORDER BY createdAt DESC';
    
    const [interventions] = await pool.query(query, values);
    
    res.json({
      success: true,
      data: interventions,
      count: interventions.length,
    });
  } catch (error) {
    next(error);
  }
}

/**
 * Update intervention status (mark as completed, etc.)
 */
async function updateInterventionStatus(req, res, next) {
  try {
    const { id } = req.params;
    const { status, notes } = req.body;
    const userId = req.user?.id || req.user?.username || 'system';
    
    const updates = [];
    const values = [];
    
    if (status) {
      updates.push('status = ?');
      values.push(status);
    }
    
    if (notes !== undefined) {
      updates.push('notes = ?');
      values.push(notes);
    }
    
    if (status === 'Completed') {
      updates.push('completionDate = NOW()');
      updates.push('completedBy = ?');
      values.push(userId);
    }
    
    values.push(id);
    
    const query = `UPDATE intervention_tracker SET ${updates.join(', ')}, updatedAt = NOW() WHERE id = ?`;
    
    await pool.query(query, values);
    
    // Fetch updated record
    const [records] = await pool.query(
      'SELECT * FROM intervention_tracker WHERE id = ?',
      [id]
    );
    
    res.json({
      success: true,
      data: records[0],
    });
  } catch (error) {
    next(error);
  }
}

module.exports = {
  getAll,
  getById,
  create,
  update,
  delete: delete_,
  getInterventionTypes,
  assignInterventions,
  getResidentInterventions,
  updateInterventionStatus,
};
