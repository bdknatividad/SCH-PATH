/**
 * Incident Report Controller
 * @module controllers/incidentReportController
 * @description Digital version of Form 08 (Second Chance Home Incident Report).
 *              A Social Worker fills this out and saves it against a violation
 *              record; a Psychologist then reviews and verifies it, at which
 *              point they can attach a Psycho-Social Activity intervention and
 *              a schedule date.
 */

const { pool } = require('../config/database');
const { generateId } = require('../utils/helpers');
const { ApiError } = require('../middleware/errorHandler');

/**
 * Map a raw DB row to the API shape, parsing the reportTypes JSON column.
 */
function mapIncidentReport(row) {
  if (!row) return null;
  let reportTypes = [];
  try {
    reportTypes = typeof row.reportTypes === 'string' ? JSON.parse(row.reportTypes) : (row.reportTypes || []);
  } catch {
    reportTypes = [];
  }
  return { ...row, reportTypes };
}

/**
 * POST /api/incident-reports
 * Create the digital incident report for an already-created violation.
 * Body: { violationId, residentId, reportTypes, othersSpecify, incidentDateTime,
 *         summary, actionTaken, result, reportedBy, endorsedTo, checkedBy, notedBy }
 */
async function create(req, res, next) {
  try {
    const {
      violationId, residentId, reportTypes, othersSpecify, incidentDateTime,
      summary, actionTaken, result, reportedBy, endorsedTo, checkedBy, notedBy,
    } = req.body || {};

    if (!violationId) throw new ApiError(400, 'violationId is required');
    if (!residentId) throw new ApiError(400, 'residentId is required');
    if (!incidentDateTime) throw new ApiError(400, 'incidentDateTime is required');

    const [existing] = await pool.query('SELECT id FROM incidentReports');
    const newId = generateId('INC', existing.map(r => ({ id: r.id })));

    await pool.query(
      `INSERT INTO incidentReports
        (id, violationId, residentId, reportTypes, othersSpecify, incidentDateTime,
         summary, actionTaken, result, reportedBy, endorsedTo, checkedBy, notedBy, status)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'Pending Review')`,
      [
        newId, violationId, residentId, JSON.stringify(reportTypes || []), othersSpecify || null,
        incidentDateTime, summary || null, actionTaken || null, result || null,
        reportedBy || null, endorsedTo || null, checkedBy || null, notedBy || null,
      ]
    );

    const [rows] = await pool.query('SELECT * FROM incidentReports WHERE id = ?', [newId]);
    res.status(201).json({ success: true, data: mapIncidentReport(rows[0]), message: 'Incident report saved and sent for review.' });
  } catch (error) {
    next(error);
  }
}

/**
 * GET /api/incident-reports/violation/:violationId
 * Fetch the incident report tied to a specific violation.
 */
async function getByViolationId(req, res, next) {
  try {
    const { violationId } = req.params;
    const [rows] = await pool.query('SELECT * FROM incidentReports WHERE violationId = ? LIMIT 1', [violationId]);
    if (rows.length === 0) {
      return res.json({ success: true, data: null });
    }
    res.json({ success: true, data: mapIncidentReport(rows[0]) });
  } catch (error) {
    next(error);
  }
}

/**
 * GET /api/incident-reports/resident/:residentId
 * List all incident reports for a resident, most recent first.
 */
async function getByResidentId(req, res, next) {
  try {
    const { residentId } = req.params;
    const [rows] = await pool.query(
      'SELECT * FROM incidentReports WHERE residentId = ? ORDER BY incidentDateTime DESC',
      [residentId]
    );
    res.json({ success: true, data: rows.map(mapIncidentReport) });
  } catch (error) {
    next(error);
  }
}

/**
 * POST /api/incident-reports/:id/verify
 * Psychologist verifies the report and (optionally) selects the intervention.
 * Body: { interventionType, interventionScheduleDate, verifiedBy }
 */
async function verify(req, res, next) {
  try {
    const { id } = req.params;
    const { interventionType, interventionScheduleDate, verifiedBy } = req.body || {};

    const [rows] = await pool.query('SELECT * FROM incidentReports WHERE id = ?', [id]);
    if (rows.length === 0) throw new ApiError(404, 'Incident report not found');

    await pool.query(
      `UPDATE incidentReports
       SET status = 'Verified', interventionType = ?, interventionScheduleDate = ?,
           verifiedBy = ?, verifiedAt = NOW()
       WHERE id = ?`,
      [interventionType || null, interventionScheduleDate || null, verifiedBy || req.user?.username || null, id]
    );

    const [updated] = await pool.query('SELECT * FROM incidentReports WHERE id = ?', [id]);
    res.json({ success: true, data: mapIncidentReport(updated[0]), message: 'Incident report verified.' });
  } catch (error) {
    next(error);
  }
}

module.exports = { create, getByViolationId, getByResidentId, verify };
