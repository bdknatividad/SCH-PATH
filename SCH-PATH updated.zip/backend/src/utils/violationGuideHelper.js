/**
 * Violation Guide Helper
 * @module utils/violationGuideHelper
 * @description Helper functions for working with violation guides and interventions
 */

const { pool } = require('../config/database');
const { generateId } = require('./helpers');

/**
 * Find a violation guide by violation name
 * Searches for exact or similar violation names
 */
async function findGuideByViolationType(violationType) {
  try {
    const lowerType = (violationType || '').toLowerCase().trim();
    
    // First try exact match
    const [exactMatch] = await pool.query(
      `SELECT * FROM violation_guide 
       WHERE status = 'Active' AND LOWER(name) = ?
       LIMIT 1`,
      [lowerType]
    );
    
    if (exactMatch.length > 0) {
      return exactMatch[0];
    }
    
    // Try partial match
    const [partialMatch] = await pool.query(
      `SELECT * FROM violation_guide 
       WHERE status = 'Active' AND LOWER(name) LIKE ?
       LIMIT 1`,
      [`%${lowerType}%`]
    );
    
    if (partialMatch.length > 0) {
      return partialMatch[0];
    }
    
    return null;
  } catch (error) {
    console.error('Error finding guide:', error);
    return null;
  }
}

/**
 * Determine offense level based on resident's violation history
 * Returns '1st', '2nd', or '3rd'
 */
async function determineOffenseLevel(residentId, guideId) {
  try {
    // Count previous violations for this guide
    const [result] = await pool.query(
      `SELECT COUNT(*) as count FROM intervention_tracker
       WHERE residentId = ? AND guideId = ?`,
      [residentId, guideId]
    );
    
    const count = result[0]?.count || 0;
    
    if (count === 0) return '1st';
    if (count === 1) return '2nd';
    return '3rd';
  } catch (error) {
    console.error('Error determining offense level:', error);
    return '1st'; // Default to 1st
  }
}

/**
 * Assign interventions to a resident based on violation guide
 */
async function assignInterventions(residentId, violationId, guideId, offenseLevel) {
  const connection = await pool.getConnection();
  
  try {
    await connection.beginTransaction();
    
    // Get interventions for this guide and offense level
    const [interventions] = await pool.query(
      `SELECT * FROM guide_interventions 
       WHERE guideId = ? AND offenseLevel = ?`,
      [guideId, offenseLevel]
    );
    
    // Create tracker entry for each intervention
    const created = [];
    for (const intervention of interventions) {
      const trackerId = generateId('IT');
      
      await connection.query(
        `INSERT INTO intervention_tracker 
         (id, residentId, violationId, guideId, offenseLevel, interventionType, duration, unit, status)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, 'Pending')`,
        [
          trackerId,
          residentId,
          violationId,
          guideId,
          offenseLevel,
          intervention.interventionType,
          intervention.duration,
          intervention.unit,
        ]
      );
      
      created.push({
        id: trackerId,
        interventionType: intervention.interventionType,
        duration: intervention.duration,
        unit: intervention.unit,
      });
    }
    
    await connection.commit();
    return { success: true, data: created };
  } catch (error) {
    await connection.rollback();
    console.error('Error assigning interventions:', error);
    return { success: false, error: error.message };
  } finally {
    connection.release();
  }
}

/**
 * Get resident's intervention tracker
 */
async function getResidentInterventions(residentId, status = null) {
  try {
    let query = 'SELECT * FROM intervention_tracker WHERE residentId = ?';
    const values = [residentId];
    
    if (status) {
      query += ' AND status = ?';
      values.push(status);
    }
    
    query += ' ORDER BY createdAt DESC';
    
    const [interventions] = await pool.query(query, values);
    return interventions;
  } catch (error) {
    console.error('Error getting resident interventions:', error);
    return [];
  }
}

/**
 * Get intervention summary for display
 */
function getInterventionDisplay(intervention) {
  if (intervention.duration && intervention.unit) {
    return `${intervention.interventionType} - ${intervention.duration} ${intervention.unit}`;
  }
  return intervention.interventionType;
}

/**
 * Format interventions by offense level
 */
function formatInterventionsByLevel(interventions) {
  return {
    '1st': interventions.filter(i => i.offenseLevel === '1st'),
    '2nd': interventions.filter(i => i.offenseLevel === '2nd'),
    '3rd': interventions.filter(i => i.offenseLevel === '3rd'),
  };
}

module.exports = {
  findGuideByViolationType,
  determineOffenseLevel,
  assignInterventions,
  getResidentInterventions,
  getInterventionDisplay,
  formatInterventionsByLevel,
};
