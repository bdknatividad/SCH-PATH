# Violation & Intervention Guide - User Guide

## For Center Head and Social Workers

### Accessing the Violation Guide

1. Log in to SCH-PATH
2. Click **"Violation Guide"** in the left navigation menu
3. You will see a table of all configured violations

### Viewing a Violation

1. Click the **eye icon** in the "Actions" column
2. A panel will open showing:
   - Violation name and category
   - Description
   - All interventions for each offense level
   - Created by, date, and last updated information

### Adding a New Violation

#### Step 1: Click "Add Violation"
- Button is in the top right of the page
- Only visible to authorized users (Center Head, Social Worker, Psychologist)

#### Step 2: Fill in Basic Information
- **Violation Name**: Enter the name of the violation (e.g., "Making noise during study time")
- **Category**: Select "Minor" or "Major"
- **Description**: (Optional) Provide additional context
- **Status**: Default is "Active" - set to "Inactive" only for retired violations

#### Step 3: Add Interventions for 1st Offense
1. Click **"+ Add Intervention"** under "1st Offense" section
2. Select the **intervention type** from dropdown:
   - **Privilege Suspension** - Duration required (e.g., 1 day, 2 weeks)
   - **Psychosocial Activity** - No duration needed
   - **Household Chores** - Duration required (e.g., 3 days)
   - **Cleaning** - Duration required (e.g., 1 hour)
   - **Confiscation** - No duration needed
   - **Dialogue/Counseling** - No duration needed
   - **Referral** - No duration needed
   - **Other** - No duration needed

3. If you selected a type that requires duration:
   - Enter the **duration number** (e.g., 1, 2, 3)
   - Select the **unit** (Day(s), Week(s), Month(s), Hour(s))

4. Click **"Remove"** to delete an intervention

5. Click **"+ Add Intervention"** again if you need multiple interventions for the 1st offense

#### Step 4: Repeat for 2nd Offense
- Follow the same process for the "2nd Offense" section
- This is typically more restrictive than 1st offense

#### Step 5: Repeat for 3rd Offense & Beyond
- Follow the same process for "3rd Offense & Beyond" section
- This is typically the most restrictive

#### Step 6: Save
- Click **"Create Guide"** button at the bottom
- You should see a success message

### Example: Creating "Making Noise During Study Time"

**1st Offense:**
- Privilege Suspension: 1 Day(s)
- Psychosocial Activity

**2nd Offense:**
- Privilege Suspension: 2 Day(s)
- Psychosocial Activity

**3rd Offense & Beyond:**
- Privilege Suspension: 3 Day(s)
- Psychosocial Activity
- Household Chores: 3 Day(s)

### Editing a Violation

1. Click the **pencil icon** in the "Actions" column
2. The form will open with the current data
3. Make your changes
4. Click **"Update Guide"**

### Marking a Violation as Inactive

1. Click the **trash icon** in the "Actions" column
2. A confirmation dialog will appear
3. Click **"Mark as Inactive"** to confirm
4. The violation will no longer appear for new violations
5. Historical records remain intact

### Filtering and Searching

**Search by name:**
- Type in the search box to find violations by name

**Filter by status:**
- Click the status dropdown to show:
  - All violations
  - Active only
  - Inactive only

---

## For Psychologists and Assessors

### Viewing Intervention Requirements

When a resident has logged a violation:

1. Go to **"Intervention Tracker"** module
2. Find the resident in the list
3. You will see all pending interventions

### Understanding the Intervention Tracker

The tracker shows:
- **Violation**: What violation triggered this
- **Intervention Type**: What needs to be done (e.g., Psychosocial Activity)
- **Offense Level**: 1st, 2nd, or 3rd
- **Status**: Pending, In Progress, or Completed
- **Duration**: How long the intervention should last

### Scheduling Psychosocial Activities

When a violation includes "Psychosocial Activity":

1. View the intervention tracker
2. Click on the psychosocial activity intervention
3. Click **"Schedule Activity"**
4. In the Assessments module, create a new assessment:
   - Type: Psychosocial Activity
   - Related Violation: [Select from list]
   - Resident: [Auto-filled]
   - Date and Time: Schedule as appropriate
   - Facilitator: Assign yourself or another facilitator

### Marking Interventions Complete

1. In the Intervention Tracker, find the completed intervention
2. Click **"Update Status"**
3. Select **"Completed"**
4. Add notes if desired (e.g., "Resident was cooperative and engaged")
5. Click **"Save"**
6. The completion date and your name will be recorded

---

## Key Principles

### 1. Interventions Are Structured
- Not free text, but specific types with durations
- System can understand and respond to them
- Ensures consistency across the facility

### 2. Offense Levels Matter
- Same violation has different interventions based on offense count
- 1st offense: educational, less restrictive
- 2nd offense: escalated
- 3rd+: most restrictive

### 3. Soft Delete, Not Hard Delete
- Violations are marked "Inactive" when no longer used
- Historical records are preserved
- Old residents' records remain intact

### 4. Audit Trail
- Every violation guide shows who created it and when
- Shows who last updated it and when
- Supports accountability and policy review

### 5. Master Data
- The Violation Guide is the source of truth
- All other modules reference these definitions
- Changing the guide may affect how new violations are handled

---

## FAQ

**Q: Can I change a violation after it's been used?**
A: Yes. Any changes will apply to new violations logged. Existing violations and their interventions remain unchanged.

**Q: What if I made a mistake when creating a violation?**
A: You can edit it immediately. If it's been used, consider marking it inactive and creating a new one.

**Q: Can interventions be changed for a resident who already has them assigned?**
A: No. Each intervention is independent once created. The guide only affects new assignments.

**Q: How many interventions can I add per offense level?**
A: As many as needed. There's no limit.

**Q: Do I need to fill in duration for every intervention type?**
A: No. Only types that require duration (like Privilege Suspension) need it. Others are optional.

**Q: What happens to interventions when I mark a violation inactive?**
A: Nothing. Existing interventions continue. New violations won't use that guide.

**Q: Can I reactivate an inactive violation?**
A: Edit the violation and change status back to "Active".

**Q: Who can view the Violation Guide?**
A: All staff with system access.

**Q: Who can create/edit/delete violations?**
A: Center Head, Social Worker, and Psychologist.

---

## Support

For technical issues or questions:
1. Check the API documentation: `VIOLATION_GUIDE_API.md`
2. Review implementation details: `VIOLATION_GUIDE_IMPLEMENTATION.md`
3. Contact system administrator
